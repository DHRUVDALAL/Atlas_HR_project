import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link, v as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { B as FileText, D as MapPin, M as LayoutDashboard, bt as ArrowLeft, ct as ChevronDown, ht as Briefcase, i as User, v as Send } from "./_libs/lucide-react.mjs";
import { i as statusMeta, n as HR_DIMENSIONS } from "./_ssr/scorecard-YpVMHDsm.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
import { n as useScorecard, t as ScorecardEditor } from "./_ssr/scorecard-D-ENrYNz.mjs";
import { t as Route } from "./_authenticated.hr.review._id-CQuafpWt.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.hr.review._id-htSj7v6K.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HrReview() {
	const { id } = Route.useParams();
	const nav = useNavigate();
	const qc = useQueryClient();
	const { data: candidate, isLoading } = useQuery({
		queryKey: ["candidate", id],
		queryFn: () => api(`/api/applicants/${id}`).then((r) => r.data)
	});
	const { data: domainsData } = useQuery({
		queryKey: ["interview", "domains"],
		queryFn: () => api("/api/interview/domains").then((r) => r.domains ?? [])
	});
	const { data: bracketsData } = useQuery({
		queryKey: ["interview", "brackets"],
		queryFn: () => api("/api/interview/experience-brackets").then((r) => r.brackets ?? [])
	});
	const { data: usersData } = useQuery({
		queryKey: ["users"],
		queryFn: () => api("/api/users?limit=200").then((r) => r ?? [])
	});
	const { state, update, isComplete } = useScorecard(HR_DIMENSIONS);
	const [domain, setDomain] = (0, import_react.useState)("FI");
	const [experienceBracket, setExperienceBracket] = (0, import_react.useState)("0-3 yrs");
	const [rounds, setRounds] = (0, import_react.useState)(2);
	const [hrStatus, setHrStatus] = (0, import_react.useState)("SELECT");
	const [firstInterviewer, setFirstInterviewer] = (0, import_react.useState)("");
	const submit = useMutation({
		mutationFn: async () => {
			const reviewResult = await api(`/api/workflow/hr/review/${id}`, {
				method: "POST",
				body: {
					domain,
					experience_bracket: experienceBracket,
					number_of_tech_rounds: rounds,
					hr_status: hrStatus,
					first_interviewer_email: firstInterviewer,
					evaluation_data: state
				}
			});
			if (hrStatus === "SELECT" && firstInterviewer) await api("/api/interview/assign", {
				method: "POST",
				body: {
					candidate_id: id,
					domain_code: domain,
					experience_bracket_code: experienceBracket,
					assigned_interviewer: firstInterviewer,
					interview_round: 1
				}
			});
			return reviewResult;
		},
		onSuccess: () => {
			toast.success("HR review submitted successfully");
			qc.invalidateQueries({ queryKey: ["candidate", id] });
			qc.invalidateQueries({ queryKey: ["applicants"] });
			nav({ to: `/candidates/${id}` });
		},
		onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to submit")
	});
	const canSubmit = isComplete && (hrStatus !== "SELECT" || firstInterviewer.trim().length > 0 && firstInterviewer.includes("@"));
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-10 max-w-5xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-32 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-32 bg-gray-100 rounded-full animate-pulse" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid sm:grid-cols-2 gap-4",
					children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-24 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-full bg-gray-100 rounded-xl animate-pulse" })]
					}, i))
				})
			}),
			Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-48 bg-gray-100 rounded-full animate-pulse" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-2",
						children: Array.from({ length: 5 }).map((_, j) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-9 w-9 bg-gray-100 rounded-md animate-pulse" }, j))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 w-full bg-gray-100 rounded-xl animate-pulse" })
				]
			}, i))
		]
	});
	const domains = domainsData ?? [];
	const brackets = bracketsData ?? [];
	const users = usersData ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-5xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/hr/queue",
						className: "flex items-center text-sm font-bold text-[#86868b] hover:text-[#1d1d1f] transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center mr-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" })
						}), "HR Queue"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[#86868b] font-bold",
						children: "/"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: `/candidates/${id}`,
						className: "flex items-center text-sm font-bold text-[#86868b] hover:text-[#1d1d1f] transition-colors bg-[#f5f5f7] px-4 py-1.5 rounded-full",
						children: "Candidate Detail"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-3xl font-bold tracking-tighter text-[#1d1d1f] flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-12 w-12 rounded-2xl bg-indigo-50 flex items-center justify-center shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutDashboard, { className: "h-6 w-6 text-indigo-600" })
				}), "HR Review"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-[#86868b] mt-2 ml-[3.75rem]",
				children: "Complete the evaluation below and assign the candidate to a technical round."
			})] }),
			candidate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col md:flex-row md:items-center gap-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-16 w-16 rounded-full bg-[#f5f5f7] flex items-center justify-center text-xl font-bold text-[#1d1d1f] shrink-0 border-2 border-white shadow-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-6 w-6 text-[#1d1d1f]" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xl font-bold tracking-tight text-[#1d1d1f] flex items-center gap-3",
								children: [
									candidate.first_name,
									" ",
									candidate.last_name,
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold tracking-wide uppercase ${statusMeta(candidate.status).className.replace("border-transparent", "")}`,
										children: statusMeta(candidate.status).label
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm font-medium text-[#86868b] mt-2 flex flex-wrap items-center gap-x-4 gap-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono font-bold bg-[#f5f5f7] px-2 py-0.5 rounded-md text-[#1d1d1f]",
										children: candidate.application_number
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" }),
											" ",
											candidate.position_applied_for ?? "—"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: candidate.email }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: candidate.phone }),
									candidate.applied_from && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["via ", candidate.applied_from] })
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-gray-100 my-8" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 md:grid-cols-3 gap-y-8 gap-x-4 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[10px] font-bold uppercase tracking-widest text-[#86868b] flex items-center gap-1.5 mb-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-3 w-3" }), " Experience"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-[#1d1d1f]",
								children: candidate.professional_details?.total_experience ? `${candidate.professional_details.total_experience} years` : "Fresher"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-bold uppercase tracking-widest text-[#86868b] mb-1.5",
								children: "Current Company"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-[#1d1d1f]",
								children: candidate.professional_details?.current_company ?? "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-bold uppercase tracking-widest text-[#86868b] mb-1.5",
								children: "Expected CTC"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-[#1d1d1f]",
								children: candidate.professional_details?.expected_ctc ? `₹${candidate.professional_details.expected_ctc} LPA` : "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-bold uppercase tracking-widest text-[#86868b] mb-1.5",
								children: "Current Designation"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-[#1d1d1f]",
								children: candidate.professional_details?.current_designation ?? "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-bold uppercase tracking-widest text-[#86868b] mb-1.5",
								children: "Notice Period"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-[#1d1d1f]",
								children: candidate.professional_details?.notice_period ?? "—"
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-[10px] font-bold uppercase tracking-widest text-[#86868b] flex items-center gap-1.5 mb-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3 w-3" }), " Location"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-[#1d1d1f]",
								children: candidate.professional_details?.preferred_location ?? candidate.city ?? "—"
							})] })
						]
					}),
					(candidate.documents?.length ?? 0) > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-px bg-gray-100 my-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2",
						children: candidate.documents?.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "inline-flex items-center gap-1.5 bg-[#fbfbfd] border border-gray-200 px-3 py-1.5 rounded-full text-xs font-bold text-[#1d1d1f]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-3.5 w-3.5 text-[#86868b]" }), d.document_type.replace(/_/g, " ")]
						}, d.document_id))
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-2",
					children: "Assignment Configuration"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid sm:grid-cols-2 gap-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
								children: "Domain Assignment"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: domain,
									onChange: (e) => setDomain(e.target.value),
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl py-3.5 pl-4 pr-10 text-sm font-bold text-[#1d1d1f] transition-all outline-none appearance-none",
									children: domains.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: d.code,
										children: [
											d.name,
											" (",
											d.code,
											")"
										]
									}, d.code))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "absolute right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
								children: "Experience Bracket"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: experienceBracket,
									onChange: (e) => setExperienceBracket(e.target.value),
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl py-3.5 pl-4 pr-10 text-sm font-bold text-[#1d1d1f] transition-all outline-none appearance-none",
									children: brackets.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: b.code,
										children: b.label
									}, b.code))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "absolute right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
								children: "Total technical rounds"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 1,
								max: 5,
								value: rounds,
								onChange: (e) => setRounds(Number(e.target.value)),
								className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl py-3.5 px-4 text-sm font-bold text-[#1d1d1f] transition-all outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
								children: "HR decision"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: hrStatus,
									onChange: (e) => setHrStatus(e.target.value),
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl py-3.5 pl-4 pr-10 text-sm font-bold text-[#1d1d1f] transition-all outline-none appearance-none",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "SELECT",
											children: "Select — proceed to technical"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "HOLD",
											children: "Hold"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "REJECT",
											children: "Reject"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "absolute right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" })]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
								children: ["First interviewer email", hrStatus === "SELECT" && !firstInterviewer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-red-500 ml-1",
									children: "*"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									value: firstInterviewer,
									onChange: (e) => setFirstInterviewer(e.target.value),
									disabled: hrStatus !== "SELECT",
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl py-3.5 pl-4 pr-10 text-sm font-bold text-[#1d1d1f] transition-all outline-none appearance-none disabled:opacity-50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "",
										disabled: true,
										children: "Select an interviewer"
									}), users.filter((u) => u.role?.role_name === "L1_PANEL").map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
										value: u.email,
										children: [
											u.first_name,
											" ",
											u.last_name,
											" (",
											u.email,
											")"
										]
									}, u.email))]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: "absolute right-4 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400 pointer-events-none" })]
							})]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-1",
						children: "Behavioral evaluation"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-medium text-[#86868b] mb-6",
						children: [
							"Rate all ",
							HR_DIMENSIONS.length,
							" dimensions to complete the scorecard."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScorecardEditor, {
						dimensions: HR_DIMENSIONS,
						scorecard: state,
						onUpdate: update
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col-reverse sm:flex-row justify-end gap-3 pb-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: `/candidates/${id}`,
					className: "inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-white border border-gray-200 text-[#1d1d1f] text-sm font-bold shadow-sm hover:bg-gray-50 transition-colors",
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => submit.mutate(),
					disabled: !canSubmit || submit.isPending,
					className: "inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4 mr-2" }), submit.isPending ? "Submitting..." : "Submit HR review"]
				})]
			})
		]
	});
}
//#endregion
export { HrReview as component };
