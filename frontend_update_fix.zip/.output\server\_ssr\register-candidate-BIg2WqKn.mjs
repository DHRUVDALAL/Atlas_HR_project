import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/register-candidate-BIg2WqKn.js
var $$splitComponentImporter = () => import("./register-candidate-C5bBhAV6.mjs");
var Route = createFileRoute("/register-candidate")({
	validateSearch: (search) => {
		return { edit: search.edit };
	},
	head: () => ({ meta: [{ title: "Candidate Application — Atlas HR" }, {
		name: "description",
		content: "Apply to open positions at Atlas HR. Complete the multi-step application."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
