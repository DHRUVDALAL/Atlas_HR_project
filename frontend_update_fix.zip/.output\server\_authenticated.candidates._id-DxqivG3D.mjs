import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.candidates._id-DxqivG3D.js
var $$splitComponentImporter = () => import("./_authenticated.candidates._id-IvNT0iIY.mjs");
var Route = createFileRoute("/_authenticated/candidates/$id")({
	head: () => ({ meta: [{ title: "Candidate — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
