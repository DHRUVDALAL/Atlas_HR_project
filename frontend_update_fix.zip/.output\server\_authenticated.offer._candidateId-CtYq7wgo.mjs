import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { $ as CircleX, B as FileText, V as FileCheck, Y as Clock, bt as ArrowLeft, ht as Briefcase, i as User, pt as Calendar, rt as CircleCheckBig, v as Send } from "./_libs/lucide-react.mjs";
import { n as AnimatePresence, t as motion } from "./_libs/framer-motion+[...].mjs";
import { t as Route } from "./_authenticated.offer._candidateId-DHSIt-Ws.mjs";
import { r as useOffer } from "./_ssr/hooks-D8-WUitX.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.offer._candidateId-CtYq7wgo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function OfferDetail() {
	const { candidateId } = Route.useParams();
	const [activeTab, setActiveTab] = (0, import_react.useState)("overview");
	const { data: candidate, isLoading } = useQuery({
		queryKey: ["candidate", candidateId],
		queryFn: () => api(`/api/applicants/${candidateId}`)
	});
	const { data: offer } = useOffer(candidateId);
	const formatDate = (dateStr) => {
		return new Date(dateStr).toLocaleDateString("en-IN", {
			day: "numeric",
			month: "short",
			year: "numeric"
		});
	};
	const tabs = [
		{
			key: "overview",
			label: "Overview",
			icon: User
		},
		{
			key: "offer",
			label: "Offer Letter",
			icon: FileText
		},
		{
			key: "status",
			label: "Status",
			icon: Clock
		},
		{
			key: "documents",
			label: "Documents",
			icon: FileCheck
		},
		{
			key: "timeline",
			label: "Timeline",
			icon: Calendar
		}
	];
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-10 max-w-6xl mx-auto space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-48 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 w-32 bg-gray-100 rounded-full animate-pulse" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-full bg-gray-100 rounded-full animate-pulse" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-full bg-gray-100 rounded-full animate-pulse" })
			]
		})]
	});
	if (!candidate) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6 lg:p-10 max-w-6xl mx-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white p-12 rounded-[2.5rem] border border-gray-100 text-center shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xl font-bold text-[#1d1d1f]",
				children: "Candidate not found"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/offer/queue",
				className: "inline-flex items-center justify-center px-6 py-2.5 rounded-full bg-[#f5f5f7] text-[#1d1d1f] text-sm font-bold hover:bg-gray-200 transition-colors mt-6",
				children: "Back to Queue"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-6xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/offer/queue",
						className: "h-10 w-10 rounded-full bg-[#f5f5f7] flex items-center justify-center text-[#86868b] hover:text-[#1d1d1f] hover:bg-gray-200 transition-colors shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-5 w-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "text-2xl font-bold tracking-tight text-[#1d1d1f]",
							children: [
								candidate.first_name,
								" ",
								candidate.last_name
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-medium text-[#86868b] mt-1 flex flex-wrap items-center gap-x-4 gap-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono font-bold bg-[#f5f5f7] px-2 py-0.5 rounded-md text-[#1d1d1f]",
								children: candidate.application_number
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" }),
									" ",
									candidate.position_applied_for ?? "—"
								]
							})]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-3 ml-[4rem] md:ml-0",
					children: offer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/offer/preview/$candidateId",
						params: { candidateId },
						className: "inline-flex items-center justify-center px-6 py-2.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-4 w-4 mr-2" }), " View Offer"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/offer/builder/$candidateId",
						params: { candidateId },
						className: "inline-flex items-center justify-center px-6 py-2.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-4 w-4 mr-2" }), " Build Offer"]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex overflow-x-auto gap-2 p-1.5 bg-[#f5f5f7] rounded-full w-fit scrollbar-none",
				children: tabs.map((tab) => {
					const Icon = tab.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setActiveTab(tab.key),
						className: `flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-all whitespace-nowrap ${activeTab === tab.key ? "bg-white text-[#1d1d1f] shadow-sm" : "text-[#86868b] hover:text-[#1d1d1f] hover:bg-gray-200/50"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }), tab.label]
					}, tab.key);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
				mode: "wait",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 10
					},
					animate: {
						opacity: 1,
						y: 0
					},
					exit: {
						opacity: 0,
						y: -10
					},
					transition: { duration: .2 },
					children: [
						activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "text-xl font-bold text-[#1d1d1f] mb-6 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4 text-[#86868b]" })
										}), "Personal Information"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Full Name",
												value: `${candidate.first_name} ${candidate.last_name}`
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Email",
												value: candidate.email
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Phone",
												value: candidate.phone
											}),
											candidate.gender && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Gender",
												value: candidate.gender
											}),
											candidate.city && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Location",
												value: `${candidate.city}, ${candidate.state}`
											}),
											candidate.applied_from && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Applied From",
												value: candidate.applied_from
											}),
											candidate.applied_from === "REFERRAL" && candidate.source_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Referred By",
												value: candidate.source_name
											}),
											candidate.applied_from === "VENDOR" && candidate.source_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Vendor Name",
												value: candidate.source_name
											})
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "text-xl font-bold text-[#1d1d1f] mb-6 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4 text-[#86868b]" })
										}), "Professional Details"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-4",
										children: [
											candidate.professional_details?.current_company && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Current Company",
												value: candidate.professional_details.current_company
											}),
											candidate.professional_details?.current_designation && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Current Designation",
												value: candidate.professional_details.current_designation
											}),
											candidate.professional_details?.total_experience && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Total Experience",
												value: `${candidate.professional_details.total_experience} years`
											}),
											candidate.professional_details?.current_ctc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Current CTC",
												value: `₹${candidate.professional_details.current_ctc} LPA`
											}),
											candidate.professional_details?.expected_ctc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Expected CTC",
												value: `₹${candidate.professional_details.expected_ctc} LPA`
											}),
											candidate.professional_details?.notice_period && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
												label: "Notice Period",
												value: candidate.professional_details.notice_period
											})
										]
									})]
								}),
								offer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] lg:col-span-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
										className: "text-xl font-bold text-[#1d1d1f] mb-6 flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-4 w-4 text-[#86868b]" })
										}), "Offer Summary"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 md:grid-cols-4 gap-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mb-1",
												children: "Offered CTC"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xl font-bold text-[#1d1d1f]",
												children: offer.offered_ctc ? `₹${offer.offered_ctc} LPA` : "—"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mb-1",
												children: "Joining Date"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-xl font-bold text-[#1d1d1f]",
												children: offer.joining_date ? formatDate(offer.joining_date) : "—"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mb-1",
												children: "Approved By"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-lg font-medium text-[#1d1d1f]",
												children: offer.approved_by ?? "—"
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mb-2",
												children: "Status"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: `inline-flex items-center justify-center rounded-full px-4 py-1.5 text-xs font-bold uppercase tracking-wide ${offer.status === "ACCEPTED" ? "bg-emerald-50 text-emerald-700" : offer.status === "SENT" ? "bg-[#0066cc]/10 text-[#0066cc]" : offer.status === "DECLINED" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`,
												children: offer.status === "ACCEPTED" ? "Accepted" : offer.status === "SENT" ? "Sent" : offer.status === "DECLINED" ? "Declined" : "Draft"
											})] })
										]
									})]
								})
							]
						}),
						activeTab === "offer" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-white p-12 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
							children: offer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mx-auto w-20 h-20 bg-[#f5f5f7] rounded-full flex items-center justify-center mb-6",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-10 w-10 text-[#86868b]" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-2xl font-bold text-[#1d1d1f] mb-2",
										children: "Offer Letter Ready"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#86868b] mb-8 max-w-md mx-auto",
										children: "View the full offer letter in the preview page to review or send to the candidate."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/offer/preview/$candidateId",
										params: { candidateId },
										className: "inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98]",
										children: "View Offer Letter"
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-8",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mx-auto w-20 h-20 bg-[#f5f5f7] rounded-full flex items-center justify-center mb-6",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-10 w-10 text-[#86868b]" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-2xl font-bold text-[#1d1d1f] mb-2",
										children: "No offer created"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#86868b] mb-8 max-w-md mx-auto",
										children: "Build an offer to generate the offer letter for this candidate."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/offer/builder/$candidateId",
										params: { candidateId },
										className: "inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98]",
										children: "Build Offer"
									})
								]
							})
						}),
						activeTab === "status" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
							children: !offer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-12",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mx-auto w-20 h-20 bg-[#f5f5f7] rounded-full flex items-center justify-center mb-6",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-10 w-10 text-[#86868b]" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-2xl font-bold text-[#1d1d1f] mb-2",
										children: "No offer status"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#86868b]",
										children: "Build an offer to start tracking status."
									})
								]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-xl font-bold text-[#1d1d1f] flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-[#86868b]" })
									}), "Status Tracker"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "grid grid-cols-1 md:grid-cols-3 gap-6 relative",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hidden md:block absolute top-10 left-10 right-10 h-0.5 bg-gray-100 z-0" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-center relative z-10",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "w-20 h-20 mx-auto rounded-full bg-white border-[4px] border-emerald-500 flex items-center justify-center mb-4 shadow-sm",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-8 w-8 text-emerald-500" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-base font-bold text-[#1d1d1f] mb-1",
													children: "Draft Created"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs font-bold text-[#86868b] uppercase tracking-wider",
													children: "Completed"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-center relative z-10",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `w-20 h-20 mx-auto rounded-full bg-white border-[4px] flex items-center justify-center mb-4 shadow-sm transition-colors duration-500 ${offer.status === "SENT" || offer.status === "ACCEPTED" || offer.status === "DECLINED" ? "border-[#0066cc]" : "border-gray-200"}`,
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: `h-8 w-8 ${offer.status === "SENT" || offer.status === "ACCEPTED" || offer.status === "DECLINED" ? "text-[#0066cc]" : "text-gray-300"}` })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-base font-bold text-[#1d1d1f] mb-1",
													children: "Offer Sent"
												}),
												offer.sent_at ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs font-bold text-[#86868b] uppercase tracking-wider",
													children: formatDate(offer.sent_at)
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs font-bold text-gray-400 uppercase tracking-wider",
													children: "Pending"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-center relative z-10",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `w-20 h-20 mx-auto rounded-full bg-white border-[4px] flex items-center justify-center mb-4 shadow-sm transition-colors duration-500 ${offer.status === "ACCEPTED" ? "border-emerald-500" : offer.status === "DECLINED" ? "border-red-500" : "border-gray-200"}`,
													children: offer.status === "DECLINED" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: `h-8 w-8 ${offer.status === "DECLINED" ? "text-red-500" : "text-gray-300"}` }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: `h-8 w-8 ${offer.status === "ACCEPTED" ? "text-emerald-500" : "text-gray-300"}` })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-base font-bold text-[#1d1d1f] mb-1",
													children: offer.status === "DECLINED" ? "Offer Declined" : "Offer Accepted"
												}),
												offer.responded_at ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs font-bold text-[#86868b] uppercase tracking-wider",
													children: formatDate(offer.responded_at)
												}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs font-bold text-gray-400 uppercase tracking-wider",
													children: "Awaiting Response"
												})
											]
										})
									]
								})]
							})
						}),
						activeTab === "documents" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
							children: candidate.documents && candidate.documents.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-xl font-bold text-[#1d1d1f] mb-6 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-4 w-4 text-[#86868b]" })
									}), "Candidate Documents"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid gap-4 md:grid-cols-2",
									children: candidate.documents.map((doc) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-4 p-5 rounded-[2rem] border border-gray-100 hover:border-gray-200 transition-colors bg-[#fbfbfd]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-12 w-12 rounded-2xl bg-white border border-gray-100 flex items-center justify-center shrink-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-6 w-6 text-[#86868b]" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex-1 min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-sm font-bold text-[#1d1d1f] truncate mb-0.5",
													children: doc.file_name
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider",
													children: doc.document_type
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
												href: `http://localhost:8001/api/documents/${doc.document_id}/download`,
												target: "_blank",
												rel: "noopener noreferrer",
												className: "inline-flex items-center justify-center h-10 w-10 rounded-full bg-white border border-gray-200 text-[#1d1d1f] hover:bg-gray-50 transition-colors shrink-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
													xmlns: "http://www.w3.org/2000/svg",
													width: "16",
													height: "16",
													viewBox: "0 0 24 24",
													fill: "none",
													stroke: "currentColor",
													strokeWidth: "2.5",
													strokeLinecap: "round",
													strokeLinejoin: "round",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", { points: "7 10 12 15 17 10" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
															x1: "12",
															x2: "12",
															y1: "15",
															y2: "3"
														})
													]
												})
											})
										]
									}, doc.document_id))
								})]
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-12",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mx-auto w-20 h-20 bg-[#f5f5f7] rounded-full flex items-center justify-center mb-6",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-10 w-10 text-[#86868b]" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-2xl font-bold text-[#1d1d1f] mb-2",
										children: "No documents"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#86868b]",
										children: "No documents uploaded for this candidate."
									})
								]
							})
						}),
						activeTab === "timeline" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
							children: candidate.interview_rounds && candidate.interview_rounds.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-xl font-bold text-[#1d1d1f] mb-8 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4 text-[#86868b]" })
								}), "Interview Timeline"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-6 top-6 bottom-6 w-px bg-gray-100" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-8",
									children: candidate.interview_rounds.map((round, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex items-start gap-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `relative z-10 h-12 w-12 rounded-full grid place-items-center border-[4px] shadow-sm shrink-0 ${round.status === "COMPLETED" ? "bg-white border-[#1d1d1f] text-[#1d1d1f]" : "bg-white border-gray-200 text-gray-400"}`,
											children: round.status === "COMPLETED" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-5 w-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-5 w-5" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex-1 bg-[#fbfbfd] p-6 rounded-[2rem] border border-gray-50",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-wrap items-center gap-3 mb-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
															className: "text-lg font-bold text-[#1d1d1f]",
															children: ["Round ", round.round_number]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider bg-gray-100 text-gray-700",
															children: round.round_type
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${round.status === "COMPLETED" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`,
															children: round.status
														})
													]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-sm font-medium text-[#1d1d1f] mb-1",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#86868b] mr-1",
															children: "Interviewer:"
														}),
														" ",
														round.interviewer_email
													]
												}),
												round.completed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider",
													children: ["Completed ", formatDate(round.completed_at)]
												})
											]
										})]
									}, round.round_id))
								})]
							})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center py-12",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mx-auto w-20 h-20 bg-[#f5f5f7] rounded-full flex items-center justify-center mb-6",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-10 w-10 text-[#86868b]" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-2xl font-bold text-[#1d1d1f] mb-2",
										children: "No interview rounds"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#86868b]",
										children: "Interview timeline will appear here."
									})
								]
							})
						})
					]
				}, activeTab)
			})
		]
	});
}
function InfoRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col sm:flex-row sm:items-center sm:justify-between py-2 border-b border-gray-50 last:border-0 gap-1 sm:gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider shrink-0",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-bold text-[#1d1d1f] text-left sm:text-right",
			children: value
		})]
	});
}
//#endregion
export { OfferDetail as component };
