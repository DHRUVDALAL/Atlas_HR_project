import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { $ as CircleX, O as Mail, V as FileCheck, Y as Clock, bt as ArrowLeft, ht as Briefcase, i as User, rt as CircleCheckBig, v as Send, w as Phone } from "./_libs/lucide-react.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
import { r as useOffer } from "./_ssr/hooks-D8-WUitX.mjs";
import { t as Route } from "./_authenticated.offer.status._candidateId-Dg_YY84G.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.offer.status._candidateId-TZpIuVvT.js
var import_jsx_runtime = require_jsx_runtime();
function OfferStatus() {
	const { candidateId } = Route.useParams();
	const { data: candidate, isLoading: candidateLoading } = useQuery({
		queryKey: ["candidate", candidateId],
		queryFn: () => api(`/api/applicants/${candidateId}`)
	});
	const { data: offer, isLoading: offerLoading } = useOffer(candidateId);
	const isLoading = candidateLoading || offerLoading;
	const formatDate = (dateStr) => {
		return new Date(dateStr).toLocaleDateString("en-IN", {
			day: "numeric",
			month: "short",
			year: "numeric",
			hour: "2-digit",
			minute: "2-digit"
		});
	};
	const statusSteps = [
		{
			key: "draft",
			label: "Draft Created",
			icon: FileCheck
		},
		{
			key: "sent",
			label: "Offer Sent",
			icon: Send
		},
		{
			key: "accepted",
			label: "Offer Accepted",
			icon: CircleCheckBig
		}
	];
	const currentStepIndex = offer ? statusSteps.findIndex((s) => s.key === offer.status) : -1;
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-10 max-w-4xl mx-auto space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-48 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 w-32 bg-gray-100 rounded-full animate-pulse" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-full bg-gray-100 rounded-full animate-pulse" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-full bg-gray-100 rounded-full animate-pulse" })
			]
		})]
	});
	if (!candidate) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6 lg:p-10 max-w-4xl mx-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white p-12 rounded-[2.5rem] border border-gray-100 text-center shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xl font-bold text-[#1d1d1f]",
				children: "Candidate not found"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/offer/queue",
				className: "inline-flex items-center justify-center px-6 py-2.5 rounded-full bg-[#f5f5f7] text-[#1d1d1f] text-sm font-bold hover:bg-gray-200 transition-colors mt-6",
				children: "Back to Queue"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-4xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-col md:flex-row md:items-center justify-between gap-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/offer/queue",
						className: "h-10 w-10 rounded-full bg-white border border-gray-200 flex items-center justify-center text-[#86868b] hover:text-[#1d1d1f] hover:bg-gray-50 transition-colors shrink-0 shadow-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-5 w-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl font-bold tracking-tight text-[#1d1d1f]",
						children: "Offer Status"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-[#86868b] mt-1",
						children: "Track the offer lifecycle for this candidate"
					})] })]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] relative overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-gray-50 to-white rounded-bl-full -z-10 opacity-50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row sm:items-center gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-16 w-16 rounded-full bg-[#f5f5f7] text-[#1d1d1f] grid place-items-center font-bold text-2xl shrink-0",
						children: [candidate.first_name[0], candidate.last_name[0]]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-xl font-bold text-[#1d1d1f] truncate",
								children: [
									candidate.first_name,
									" ",
									candidate.last_name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono font-bold bg-gray-100 text-gray-700 px-2 py-0.5 rounded-md text-xs",
								children: candidate.application_number
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap gap-x-6 gap-y-2 text-sm font-medium text-[#86868b]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-4 w-4" }),
										" ",
										candidate.email
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-4 w-4" }),
										" ",
										candidate.phone
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" }),
										" ",
										candidate.position_applied_for ?? "—"
									]
								})
							]
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 sm:p-12 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-xl font-bold text-[#1d1d1f] mb-10 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-[#86868b]" })
					}), "Status Timeline"]
				}), !offer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center py-12 bg-[#fbfbfd] rounded-[2rem] border border-gray-50",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "w-20 h-20 mx-auto rounded-full bg-white border border-gray-100 flex items-center justify-center mb-6 shadow-sm",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-10 w-10 text-[#86868b]" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-2xl font-bold text-[#1d1d1f] mb-2",
							children: "No offer created"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-[#86868b] mb-8",
							children: "Build an offer to start tracking its status here."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/offer/builder/$candidateId",
							params: { candidateId },
							className: "inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98]",
							children: "Build Offer"
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative max-w-2xl mx-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-[2.25rem] top-6 bottom-6 w-0.5 bg-gray-100" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "space-y-12",
						children: statusSteps.map((step, index) => {
							const Icon = step.icon;
							const isCompleted = index <= currentStepIndex || offer.status === "DECLINED" && index === 0;
							const isCurrent = index === currentStepIndex;
							const isDeclined = offer.status === "DECLINED" && index === 1;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative flex items-start gap-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `relative z-10 h-[4.5rem] w-[4.5rem] rounded-full grid place-items-center border-[4px] shadow-sm shrink-0 transition-colors duration-500 bg-white ${isDeclined ? "border-red-500 text-red-500" : isCompleted ? step.key === "accepted" ? "border-emerald-500 text-emerald-500" : "border-[#1d1d1f] text-[#1d1d1f]" : "border-gray-200 text-gray-300"}`,
									children: isDeclined ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-7 w-7" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-7 w-7" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 pt-2 pb-6 border-b border-gray-50 last:border-0 last:pb-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-3 mb-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: `text-xl font-bold ${isCompleted ? "text-[#1d1d1f]" : "text-gray-400"}`,
													children: step.label
												}),
												isCurrent && !isDeclined && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider bg-gray-100 text-[#1d1d1f]",
													children: "Current Stage"
												}),
												isDeclined && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider bg-red-50 text-red-700",
													children: "Offer Declined"
												})
											]
										}),
										step.key === "draft" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: `text-sm font-medium mt-1 ${isCompleted ? "text-[#86868b]" : "text-gray-400"}`,
											children: "Offer draft has been generated and saved."
										}),
										step.key === "sent" && offer.sent_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: `text-sm font-medium mt-1 ${isCompleted ? "text-[#86868b]" : "text-gray-400"}`,
											children: [
												"Offer was officially sent to the candidate on ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-[#1d1d1f]",
													children: formatDate(offer.sent_at)
												}),
												"."
											]
										}),
										step.key === "accepted" && offer.responded_at && offer.status === "ACCEPTED" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: `text-sm font-medium mt-1 ${isCompleted ? "text-[#86868b]" : "text-gray-400"}`,
											children: [
												"Candidate officially accepted the offer on ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-[#1d1d1f]",
													children: formatDate(offer.responded_at)
												}),
												"."
											]
										}),
										isDeclined && offer.responded_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm font-medium mt-1 text-red-600/80",
											children: [
												"Candidate declined the offer on ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "font-bold text-red-600",
													children: formatDate(offer.responded_at)
												}),
												"."
											]
										}),
										step.key === "draft" && offer.offered_ctc && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-4 flex flex-wrap gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center justify-center rounded-full px-4 py-1.5 text-xs font-bold bg-[#f5f5f7] text-[#1d1d1f]",
												children: [
													"CTC: ₹",
													offer.offered_ctc,
													" LPA"
												]
											}), offer.joining_date && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "inline-flex items-center justify-center rounded-full px-4 py-1.5 text-xs font-bold bg-[#f5f5f7] text-[#1d1d1f]",
												children: ["Joining: ", offer.joining_date]
											})]
										})
									]
								})]
							}, step.key);
						})
					})]
				})]
			}),
			offer && offer.history.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
					className: "text-xl font-bold text-[#1d1d1f] mb-6 flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4 text-[#86868b]" })
					}), "Activity History"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: offer.history.slice().reverse().map((entry, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-4 p-4 rounded-[1.5rem] hover:bg-[#fbfbfd] transition-colors border border-transparent hover:border-gray-50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `h-10 w-10 rounded-full flex items-center justify-center text-sm font-bold shrink-0 ${entry.action === "offer_accepted" ? "bg-emerald-50 text-emerald-600" : entry.action === "offer_declined" ? "bg-red-50 text-red-600" : "bg-[#f5f5f7] text-[#1d1d1f]"}`,
								children: entry.action === "offer_sent" ? "S" : entry.action === "offer_accepted" ? "A" : entry.action === "offer_declined" ? "D" : "D"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-bold text-[#1d1d1f]",
									children: entry.action === "draft_saved" ? "Draft Saved" : entry.action === "offer_submitted" ? "Offer Submitted" : entry.action === "offer_sent" ? "Offer Sent" : entry.action === "offer_accepted" ? "Offer Accepted" : entry.action === "offer_declined" ? "Offer Declined" : entry.action
								}), entry.details && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
									children: entry.details
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider whitespace-nowrap",
								children: formatDate(entry.timestamp)
							})
						]
					}, i))
				})]
			}),
			offer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/offer/preview/$candidateId",
						params: { candidateId },
						className: "inline-flex items-center justify-center px-6 py-3 rounded-full bg-white border border-gray-200 text-[#1d1d1f] text-sm font-bold shadow-sm hover:bg-gray-50 transition-all active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-4 w-4 mr-2" }), " View Offer Letter"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/offer/builder/$candidateId",
						params: { candidateId },
						className: "inline-flex items-center justify-center px-6 py-3 rounded-full bg-white border border-gray-200 text-[#1d1d1f] text-sm font-bold shadow-sm hover:bg-gray-50 transition-all active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-4 w-4 mr-2" }), " Edit Offer"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/candidates/$id",
						params: { id: candidateId },
						className: "inline-flex items-center justify-center px-6 py-3 rounded-full bg-white border border-gray-200 text-[#1d1d1f] text-sm font-bold shadow-sm hover:bg-gray-50 transition-all active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4 mr-2" }), " View Profile"]
					})
				]
			})
		]
	});
}
//#endregion
export { OfferStatus as component };
