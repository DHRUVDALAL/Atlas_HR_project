import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./_ssr/button-B_S4Wnqd.mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { F as Inbox, _t as ArrowUp, ot as ChevronRight, rt as CircleCheckBig, st as ChevronLeft, v as Send, vt as ArrowUpDown, xt as ArrowDown, y as Search } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { i as statusMeta } from "./_ssr/scorecard-YpVMHDsm.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-CAzbakW8.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.hr.queue-DzuW-e-9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var PAGE_SIZE = 10;
function HrReviewQueue() {
	const [status, setStatus] = (0, import_react.useState)("RECEPTION_FORWARDED");
	const [search, setSearch] = (0, import_react.useState)("");
	const [debouncedSearch, setDebouncedSearch] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const [sortBy, setSortBy] = (0, import_react.useState)("created_at");
	const [sortOrder, setSortOrder] = (0, import_react.useState)("desc");
	const [debounceTimer, setDebounceTimer] = (0, import_react.useState)(null);
	const handleSearchChange = (value) => {
		setSearch(value);
		if (debounceTimer) clearTimeout(debounceTimer);
		const timer = setTimeout(() => {
			setDebouncedSearch(value);
			setPage(1);
		}, 300);
		setDebounceTimer(timer);
	};
	const skip = (page - 1) * PAGE_SIZE;
	const params = new URLSearchParams();
	params.set("limit", String(PAGE_SIZE));
	params.set("skip", String(skip));
	if (status !== "ALL") params.set("status", status);
	if (debouncedSearch) params.set("search", debouncedSearch);
	params.set("sort_by", sortBy);
	params.set("sort_order", sortOrder);
	const { data, isLoading } = useQuery({
		queryKey: [
			"applicants",
			"hr-queue",
			status,
			debouncedSearch,
			page,
			sortBy,
			sortOrder
		],
		queryFn: () => api(`/api/applicants?${params.toString()}`)
	});
	const rows = data?.applicants ?? [];
	const total = data?.total ?? 0;
	const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
	const toggleSort = (field) => {
		if (sortBy === field) setSortOrder((o) => o === "asc" ? "desc" : "asc");
		else {
			setSortBy(field);
			setSortOrder("desc");
		}
		setPage(1);
	};
	const SortIcon = ({ field }) => {
		if (sortBy !== field) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpDown, { className: "h-3 w-3 ml-1 opacity-40" });
		return sortOrder === "asc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "h-3 w-3 ml-1 text-primary" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "h-3 w-3 ml-1 text-primary" });
	};
	const { data: allData } = useQuery({
		queryKey: ["applicants", "hr-kpis"],
		queryFn: () => api("/api/applicants?limit=500").then((r) => r.applicants ?? [])
	});
	const allList = allData ?? [];
	const countAwaitingHr = allList.filter((c) => c.status === "RECEPTION_FORWARDED").length;
	const countHrCompleted = allList.filter((c) => c.status.startsWith("TECHNICAL_") || c.status === "CEO_ROUND").length;
	const countTechnical = allList.filter((c) => c.status.startsWith("TECHNICAL_")).length;
	const countSelected = allList.filter((c) => c.status === "SELECTED").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
				children: "HR Review Queue"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-[#86868b] mt-1",
				children: "Manage candidate screenings and route profiles to technical assessment pipelines."
			})] }),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-4",
				children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-20 mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-12" })]
				}, i))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 lg:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "Awaiting HR Review"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: countAwaitingHr
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-violet-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Inbox, { className: "h-5 w-5 text-violet-600" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "HR Completed"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: countHrCompleted
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-emerald-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-5 w-5 text-emerald-600" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "In Technical"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: countTechnical
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-purple-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-5 w-5 text-purple-600" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "Selected"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: countSelected
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-green-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-5 w-5 text-green-600" })
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-4 md:p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1 min-w-[240px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-[#86868b]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: search,
							onChange: (e) => handleSearchChange(e.target.value),
							placeholder: "Search name, email, application #",
							className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl pl-11 pr-5 py-3 text-sm text-[#1d1d1f] placeholder:text-[#86868b] transition-all outline-none"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: status,
								onValueChange: (v) => {
									setStatus(v);
									setPage(1);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "w-[200px] bg-[#f5f5f7] border-transparent rounded-2xl h-11 px-4 text-sm font-medium",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
									className: "rounded-2xl border-gray-100 shadow-xl",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "ALL",
											className: "rounded-xl cursor-pointer",
											children: "All statuses"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "RECEPTION_FORWARDED",
											className: "rounded-xl cursor-pointer",
											children: "Awaiting HR Review"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "TECHNICAL_PENDING",
											className: "rounded-xl cursor-pointer",
											children: "Technical Round 1"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "CEO_ROUND",
											className: "rounded-xl cursor-pointer",
											children: "CEO Round"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "FINAL_DISCUSSION_PENDING",
											className: "rounded-xl cursor-pointer",
											children: "Final Discussion"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "SELECTED",
											className: "rounded-xl cursor-pointer",
											children: "Selected"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "REJECTED",
											className: "rounded-xl cursor-pointer",
											children: "Rejected"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
											value: "ON_HOLD",
											className: "rounded-xl cursor-pointer",
											children: "On Hold"
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: sortBy,
								onValueChange: (v) => {
									setSortBy(v);
									setPage(1);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "w-[180px] bg-[#f5f5f7] border-transparent rounded-2xl h-11 px-4 text-sm font-medium",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
									className: "rounded-2xl border-gray-100 shadow-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "created_at",
										className: "rounded-xl cursor-pointer",
										children: "Sort by Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "experience",
										className: "rounded-xl cursor-pointer",
										children: "Sort by Experience"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "h-11 w-11 flex items-center justify-center bg-[#f5f5f7] hover:bg-gray-200 text-[#1d1d1f] rounded-2xl transition-colors",
								onClick: () => {
									setSortOrder((o) => o === "asc" ? "desc" : "asc");
									setPage(1);
								},
								children: sortOrder === "asc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "h-4 w-4" })
							}),
							(status !== "RECEPTION_FORWARDED" || debouncedSearch) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "h-11 px-5 flex items-center justify-center bg-transparent hover:bg-gray-50 text-[#86868b] border border-gray-200 rounded-2xl text-sm font-medium transition-colors",
								onClick: () => {
									setStatus("RECEPTION_FORWARDED");
									setSearch("");
									setDebouncedSearch("");
									setPage(1);
								},
								children: "Clear filters"
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs font-medium text-[#86868b] px-2",
					children: [
						total,
						" candidate",
						total !== 1 ? "s" : "",
						" found",
						totalPages > 1 && ` · Page ${page} of ${totalPages}`
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-[2rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[2fr_1.5fr_2fr_1fr_1.5fr_auto] gap-4 bg-[#fbfbfd] px-8 py-5 border-b border-gray-100 items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b]",
							children: "Applicant"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b]",
							children: "Application #"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b]",
							children: "Position"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b]",
							children: "Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b] flex items-center cursor-pointer hover:text-[#1d1d1f] transition-colors",
							onClick: () => toggleSort("created_at"),
							children: ["Applied ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortIcon, { field: "created_at" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b] text-right w-24",
							children: "Actions"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: isLoading ? Array.from({ length: PAGE_SIZE }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[2fr_1.5fr_2fr_1fr_1.5fr_auto] gap-4 px-8 py-6 border-b border-gray-50/50 items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-32" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-20" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-24" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-20 rounded-full" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-24" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-16 ml-auto" })
						]
					}, i)) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "py-16 text-center text-sm font-medium text-[#86868b]",
						children: "No candidates found matching your criteria."
					}) : rows.map((c) => {
						const s = statusMeta(c.status);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[2fr_1.5fr_2fr_1fr_1.5fr_auto] gap-4 px-8 py-5 border-b border-gray-50/50 hover:bg-[#f5f5f7]/60 transition-colors items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 pr-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-sm font-bold text-[#1d1d1f] truncate",
										children: [
											c.first_name,
											" ",
											c.last_name
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
										children: c.email
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xs font-semibold text-[#1d1d1f] truncate",
									children: c.application_number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium text-[#1d1d1f] truncate pr-4",
									children: c.position_applied_for ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-semibold tracking-wide ${s.className}`,
									children: s.label
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-medium text-[#86868b]",
									children: new Date(c.created_at).toLocaleDateString()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-end w-24",
									children: c.status === "RECEPTION_FORWARDED" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: `/hr/review/${c.candidate_id}`,
										className: "bg-[#0066cc] hover:bg-[#005bb5] text-white rounded-full px-5 py-1.5 text-xs font-bold transition-all shadow-sm active:scale-[0.98]",
										children: "Review"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: `/candidates/${c.candidate_id}`,
										className: "bg-transparent hover:bg-gray-100 border border-gray-200 text-[#1d1d1f] rounded-full px-5 py-1.5 text-xs font-bold transition-all shadow-sm active:scale-[0.98]",
										children: "View"
									})
								})
							]
						}, c.candidate_id);
					})
				})]
			}),
			totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm text-muted-foreground",
					children: [
						"Showing ",
						(page - 1) * PAGE_SIZE + 1,
						"–",
						Math.min(page * PAGE_SIZE, total),
						" of ",
						total
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							disabled: page <= 1,
							onClick: () => setPage((p) => p - 1),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" }), " Previous"]
						}),
						Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
							const pageNum = Math.max(1, Math.min(page - 2, totalPages - 4)) + i;
							if (pageNum > totalPages) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: pageNum === page ? "default" : "outline",
								size: "sm",
								className: "w-9",
								onClick: () => setPage(pageNum),
								children: pageNum
							}, pageNum);
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							disabled: page >= totalPages,
							onClick: () => setPage((p) => p + 1),
							children: ["Next ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { HrReviewQueue as component };
