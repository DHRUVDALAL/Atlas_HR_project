//#region node_modules/.nitro/vite/services/ssr/assets/scorecard-YpVMHDsm.js
var HR_DIMENSIONS = [
	"Communication & Articulation",
	"Confidence & Poise",
	"Technical / Domain Knowledge",
	"Attitude & Ownership Mindset",
	"Empathy & Team Orientation",
	"Problem-Solving Approach",
	"Cultural Fit & Values Alignment"
];
var CEO_DIMENSIONS = [
	"Leadership Aptitude",
	"Strategic Thinking",
	"Cultural Alignment",
	"Business Acumen",
	"Overall Fit"
];
var STATUS_META = {
	DRAFT: {
		label: "Draft",
		className: "bg-muted text-muted-foreground"
	},
	SUBMITTED: {
		label: "Submitted",
		className: "bg-info/15 text-info"
	},
	"Submitted — awaiting reception": {
		label: "Awaiting Reception",
		className: "bg-info/15 text-info"
	},
	RECEPTION_FORWARDED: {
		label: "Reception Forwarded",
		className: "bg-accent text-accent-foreground"
	},
	TECHNICAL_PENDING: {
		label: "Technical Round 1 Pending",
		className: "bg-primary/15 text-primary"
	},
	TECHNICAL_ROUND_2_PENDING: {
		label: "Technical Round 2 Pending",
		className: "bg-primary/15 text-primary"
	},
	TECH_ROUND_1: {
		label: "Technical Round 1",
		className: "bg-primary/15 text-primary"
	},
	TECH_ROUND_2: {
		label: "Technical Round 2",
		className: "bg-primary/15 text-primary"
	},
	TECH_ROUND_3: {
		label: "Technical Round 3",
		className: "bg-primary/15 text-primary"
	},
	TECH_ROUND_4: {
		label: "Technical Round 4",
		className: "bg-primary/15 text-primary"
	},
	TECH_ROUND_5: {
		label: "Technical Round 5",
		className: "bg-primary/15 text-primary"
	},
	CEO_ROUND: {
		label: "CEO Round",
		className: "bg-warning/20 text-warning-foreground"
	},
	FINAL_DISCUSSION_PENDING: {
		label: "Final Discussion",
		className: "bg-warning/20 text-warning-foreground"
	},
	SELECTED: {
		label: "Selected",
		className: "bg-success/15 text-success"
	},
	REJECTED: {
		label: "Rejected",
		className: "bg-destructive/15 text-destructive"
	},
	ON_HOLD: {
		label: "On Hold",
		className: "bg-muted text-muted-foreground"
	}
};
function statusMeta(s) {
	return STATUS_META[s ?? ""] ?? {
		label: s ?? "Unknown",
		className: "bg-muted text-muted-foreground"
	};
}
//#endregion
export { statusMeta as i, HR_DIMENSIONS as n, STATUS_META as r, CEO_DIMENSIONS as t };
