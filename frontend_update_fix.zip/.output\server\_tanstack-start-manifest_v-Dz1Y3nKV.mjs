//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dz1Y3nKV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/__root.tsx",
		children: [
			"/",
			"/_authenticated",
			"/login",
			"/register-candidate",
			"/candidate-portal/$candidateId"
		],
		preloads: [
			"/assets/index-x8XQAZy-.js",
			"/assets/rolldown-runtime-Bh1tDfsg.js",
			"/assets/jsx-runtime-BHz_hoGM.js",
			"/assets/react-dom-BYiiqlYf.js",
			"/assets/link-CijhLZW4.js",
			"/assets/Match-Ch2UEn26.js",
			"/assets/useMatch-_xG0YN4k.js",
			"/assets/utils-Cpyd4CBY.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-x8XQAZy-.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DJk4gxCy.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/createLucideIcon-Dku9ohrO.js",
			"/assets/arrow-right-CyuPCeks.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/building-DbkVhoCU.js",
			"/assets/circle-check-CvCZVo8U.js",
			"/assets/mail-D8xS4ALm.js",
			"/assets/map-pin-aj-cXMGE.js",
			"/assets/phone-DBFNibc3.js",
			"/assets/shield-Dippm1XK.js",
			"/assets/users-BY_mpPzo.js"
		]
	},
	"/_authenticated": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.tsx",
		children: [
			"/_authenticated/candidates",
			"/_authenticated/dashboard",
			"/_authenticated/email-management",
			"/_authenticated/reports",
			"/_authenticated/scheduler",
			"/_authenticated/settings",
			"/_authenticated/users",
			"/_authenticated/ceo/queue",
			"/_authenticated/final-decision/$id",
			"/_authenticated/final-discussion/$id",
			"/_authenticated/hr/queue",
			"/_authenticated/interviewer/queue",
			"/_authenticated/offer/$candidateId",
			"/_authenticated/offer/dashboard",
			"/_authenticated/offer/queue",
			"/_authenticated/onboarding/$candidateId",
			"/_authenticated/onboarding/dashboard",
			"/_authenticated/onboarding/queue",
			"/_authenticated/ceo/evaluate/$id",
			"/_authenticated/hr/review/$id",
			"/_authenticated/interviewer/evaluate/$id",
			"/_authenticated/interviewer/review/$id",
			"/_authenticated/offer/builder/$candidateId",
			"/_authenticated/offer/preview/$candidateId",
			"/_authenticated/offer/status/$candidateId"
		],
		preloads: [
			"/assets/_authenticated-BdezOlaR.js",
			"/assets/useRouterState-Bax7vE7J.js",
			"/assets/useQuery-BCFD6U90.js",
			"/assets/useMutation-DC9oiduA.js",
			"/assets/es2015-BAcWSZZF.js",
			"/assets/dist-DsTK1sfA.js",
			"/assets/x-Cx10Qgrm.js",
			"/assets/createLucideIcon-Dku9ohrO.js",
			"/assets/dist-CgpDlu_d.js",
			"/assets/clipboard-check-CW2-4Zt1.js",
			"/assets/crown-CeBxryYt.js",
			"/assets/file-check-uoUR1bst.js",
			"/assets/file-text-DW_bZC04.js",
			"/assets/layout-dashboard-myHS8Af0.js",
			"/assets/list-checks-CPEBz6Zi.js",
			"/assets/mail-D8xS4ALm.js",
			"/assets/user-plus-BsMtIRQ9.js",
			"/assets/users-BY_mpPzo.js",
			"/assets/badge-R8WvEM8g.js"
		]
	},
	"/login": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DQbO9TO6.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/createLucideIcon-Dku9ohrO.js",
			"/assets/file-text-DW_bZC04.js",
			"/assets/users-BY_mpPzo.js",
			"/assets/label-DMynU3vy.js",
			"/assets/input-CF9GJUmM.js"
		]
	},
	"/register-candidate": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/register-candidate.tsx",
		children: void 0,
		preloads: [
			"/assets/register-candidate-C15-abJj.js",
			"/assets/typeof-B5XbjTb1.js",
			"/assets/toPropertyKey-1ZER28ru.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/AnimatePresence-BB5m5-XL.js",
			"/assets/es2015-BAcWSZZF.js",
			"/assets/dist-DsTK1sfA.js",
			"/assets/triangle-alert-CIYVyeSQ.js",
			"/assets/createLucideIcon-Dku9ohrO.js",
			"/assets/dist-CgpDlu_d.js",
			"/assets/chevron-left-DVknXlPc.js",
			"/assets/chevron-right-B8rRkKve.js",
			"/assets/select-CoC66s71.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/circle-check-CvCZVo8U.js",
			"/assets/file-text-DW_bZC04.js",
			"/assets/map-pin-aj-cXMGE.js",
			"/assets/trash-2-ClYE2gZU.js",
			"/assets/card-BRC5zETd.js",
			"/assets/label-DMynU3vy.js",
			"/assets/textarea-CojIHEkg.js",
			"/assets/input-CF9GJUmM.js"
		]
	},
	"/_authenticated/candidates": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.candidates.tsx",
		children: ["/_authenticated/candidates/$id"],
		preloads: [
			"/assets/_authenticated.candidates-BkQLNqyR.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-up-HlacCdT7.js",
			"/assets/arrow-up-down-B32_xCXo.js",
			"/assets/chevron-left-DVknXlPc.js",
			"/assets/chevron-right-B8rRkKve.js",
			"/assets/select-CoC66s71.js",
			"/assets/search-Dm14doRi.js",
			"/assets/scorecard-YJeC1y9O.js"
		]
	},
	"/_authenticated/dashboard": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.dashboard-D4Jlqaww.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-right-CyuPCeks.js",
			"/assets/calendar-UpsXhG0C.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/circle-pause-BgPu_ZZG.js",
			"/assets/gavel-B-xkZuXy.js",
			"/assets/inbox-B1Cp8Xfa.js",
			"/assets/send-DHANv9AT.js",
			"/assets/user-check-OFHh_HoS.js",
			"/assets/scorecard-YJeC1y9O.js",
			"/assets/card-BRC5zETd.js"
		]
	},
	"/_authenticated/email-management": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.email-management.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.email-management-BqR15qHr.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/circle-alert-BBaM1Bnj.js",
			"/assets/circle-play-jgGhl-IL.js",
			"/assets/clock-qf84njfM.js",
			"/assets/send-DHANv9AT.js"
		]
	},
	"/_authenticated/reports": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.reports.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.reports-dx2Ir9dA.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/download-CRwij_be.js"
		]
	},
	"/_authenticated/scheduler": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.scheduler.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.scheduler-C6_w2gFo.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/circle-check-CvCZVo8U.js",
			"/assets/circle-play-jgGhl-IL.js",
			"/assets/clock-qf84njfM.js"
		]
	},
	"/_authenticated/settings": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.settings.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.settings-TqdSsWLh.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/label-DMynU3vy.js"
		]
	},
	"/_authenticated/users": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.users.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.users-7UicAkjr.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/select-CoC66s71.js",
			"/assets/trash-2-ClYE2gZU.js",
			"/assets/search-Dm14doRi.js",
			"/assets/dialog-CI_iCI2L.js",
			"/assets/label-DMynU3vy.js"
		]
	},
	"/candidate-portal/$candidateId": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/candidate-portal.$candidateId.tsx",
		children: void 0,
		preloads: [
			"/assets/candidate-portal._candidateId-C3TmWiAb.js",
			"/assets/useQuery-BCFD6U90.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/building-DbkVhoCU.js",
			"/assets/calendar-UpsXhG0C.js",
			"/assets/clock-qf84njfM.js",
			"/assets/file-check-uoUR1bst.js",
			"/assets/mail-D8xS4ALm.js",
			"/assets/phone-DBFNibc3.js",
			"/assets/user-C7M_r1VX.js",
			"/assets/card-BRC5zETd.js",
			"/assets/hooks-DOUJz_mf.js",
			"/assets/badge-R8WvEM8g.js"
		]
	},
	"/_authenticated/candidates/$id": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.candidates.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.candidates._id-ChdlIMyS.js",
			"/assets/triangle-alert-CIYVyeSQ.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/calendar-UpsXhG0C.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/circle-x-A8LJwENZ.js",
			"/assets/clock-qf84njfM.js",
			"/assets/download-CRwij_be.js",
			"/assets/external-link-xDgeNPSR.js",
			"/assets/gavel-B-xkZuXy.js",
			"/assets/graduation-cap-D6mm9tEu.js",
			"/assets/map-pin-aj-cXMGE.js",
			"/assets/user-check-OFHh_HoS.js",
			"/assets/user-C7M_r1VX.js",
			"/assets/dialog-CI_iCI2L.js"
		]
	},
	"/_authenticated/ceo/queue": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.ceo.queue.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.ceo.queue-S3TLHDFo.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-right-CyuPCeks.js",
			"/assets/arrow-up-down-B32_xCXo.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/clock-qf84njfM.js",
			"/assets/gavel-B-xkZuXy.js",
			"/assets/search-Dm14doRi.js",
			"/assets/scorecard-YJeC1y9O.js"
		]
	},
	"/_authenticated/final-decision/$id": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.final-decision.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.final-decision._id-Bz5gC5A7.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/AnimatePresence-BB5m5-XL.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/building-DbkVhoCU.js",
			"/assets/calendar-UpsXhG0C.js",
			"/assets/circle-check-CvCZVo8U.js",
			"/assets/circle-pause-BgPu_ZZG.js",
			"/assets/circle-x-A8LJwENZ.js",
			"/assets/clock-qf84njfM.js",
			"/assets/dollar-sign-DOXYG9Li.js",
			"/assets/gavel-B-xkZuXy.js",
			"/assets/map-pin-aj-cXMGE.js",
			"/assets/save-BIH1nRYn.js",
			"/assets/send-DHANv9AT.js",
			"/assets/star-QvD3ADdz.js",
			"/assets/user-C7M_r1VX.js"
		]
	},
	"/_authenticated/final-discussion/$id": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.final-discussion.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.final-discussion._id-pL2IZD75.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/AnimatePresence-BB5m5-XL.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/building-DbkVhoCU.js",
			"/assets/calendar-UpsXhG0C.js",
			"/assets/circle-check-CvCZVo8U.js",
			"/assets/circle-pause-BgPu_ZZG.js",
			"/assets/circle-x-A8LJwENZ.js",
			"/assets/clock-qf84njfM.js",
			"/assets/dollar-sign-DOXYG9Li.js",
			"/assets/gavel-B-xkZuXy.js",
			"/assets/map-pin-aj-cXMGE.js",
			"/assets/save-BIH1nRYn.js",
			"/assets/send-DHANv9AT.js",
			"/assets/star-QvD3ADdz.js",
			"/assets/user-C7M_r1VX.js"
		]
	},
	"/_authenticated/hr/queue": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.hr.queue.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.hr.queue-DzYXrC07.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-up-HlacCdT7.js",
			"/assets/arrow-up-down-B32_xCXo.js",
			"/assets/chevron-left-DVknXlPc.js",
			"/assets/chevron-right-B8rRkKve.js",
			"/assets/select-CoC66s71.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/inbox-B1Cp8Xfa.js",
			"/assets/search-Dm14doRi.js",
			"/assets/send-DHANv9AT.js",
			"/assets/scorecard-YJeC1y9O.js"
		]
	},
	"/_authenticated/interviewer/queue": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.interviewer.queue.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.interviewer.queue-DHo8UCPB.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-right-CyuPCeks.js",
			"/assets/arrow-up-down-B32_xCXo.js",
			"/assets/select-CoC66s71.js",
			"/assets/clock-qf84njfM.js",
			"/assets/search-Dm14doRi.js",
			"/assets/user-check-OFHh_HoS.js",
			"/assets/scorecard-YJeC1y9O.js"
		]
	},
	"/_authenticated/offer/$candidateId": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.offer.$candidateId.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.offer._candidateId-Gx2oGTbr.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/AnimatePresence-BB5m5-XL.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/calendar-UpsXhG0C.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/circle-x-A8LJwENZ.js",
			"/assets/clock-qf84njfM.js",
			"/assets/send-DHANv9AT.js",
			"/assets/user-C7M_r1VX.js",
			"/assets/hooks-DOUJz_mf.js"
		]
	},
	"/_authenticated/offer/dashboard": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.offer.dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.offer.dashboard-BsFy_K0j.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-right-CyuPCeks.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/clock-qf84njfM.js",
			"/assets/send-DHANv9AT.js",
			"/assets/trending-up-DbMOp-dM.js"
		]
	},
	"/_authenticated/offer/queue": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.offer.queue.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.offer.queue-DClZTC0I.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-right-CyuPCeks.js",
			"/assets/chevron-left-DVknXlPc.js",
			"/assets/chevron-right-B8rRkKve.js",
			"/assets/clock-qf84njfM.js",
			"/assets/search-Dm14doRi.js"
		]
	},
	"/_authenticated/onboarding/$candidateId": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.onboarding.$candidateId.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.onboarding._candidateId-BjLagh4G.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/AnimatePresence-BB5m5-XL.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/calendar-UpsXhG0C.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/circle-x-A8LJwENZ.js",
			"/assets/laptop-M7BERZhb.js",
			"/assets/shield-Dippm1XK.js",
			"/assets/user-C7M_r1VX.js"
		]
	},
	"/_authenticated/onboarding/dashboard": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.onboarding.dashboard.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.onboarding.dashboard-tvnQH67_.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-right-CyuPCeks.js",
			"/assets/calendar-UpsXhG0C.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/clock-qf84njfM.js",
			"/assets/laptop-M7BERZhb.js",
			"/assets/shield-Dippm1XK.js",
			"/assets/trending-up-DbMOp-dM.js"
		]
	},
	"/_authenticated/onboarding/queue": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.onboarding.queue.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.onboarding.queue-CjBO73vm.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-right-CyuPCeks.js",
			"/assets/chevron-left-DVknXlPc.js",
			"/assets/chevron-right-B8rRkKve.js",
			"/assets/search-Dm14doRi.js"
		]
	},
	"/_authenticated/ceo/evaluate/$id": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.ceo.evaluate.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.ceo.evaluate._id-51fqiBI5.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/save-BIH1nRYn.js",
			"/assets/send-DHANv9AT.js",
			"/assets/star-QvD3ADdz.js",
			"/assets/trending-up-DbMOp-dM.js",
			"/assets/user-C7M_r1VX.js",
			"/assets/scorecard-YJeC1y9O.js",
			"/assets/scorecard-Bp2RjhUH.js"
		]
	},
	"/_authenticated/hr/review/$id": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.hr.review.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.hr.review._id-CPbS0njx.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/chevron-down-Dpcjx79R.js",
			"/assets/map-pin-aj-cXMGE.js",
			"/assets/send-DHANv9AT.js",
			"/assets/user-C7M_r1VX.js",
			"/assets/scorecard-YJeC1y9O.js",
			"/assets/scorecard-Bp2RjhUH.js"
		]
	},
	"/_authenticated/interviewer/evaluate/$id": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.interviewer.evaluate.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.interviewer.evaluate._id-B111DLMf.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/AnimatePresence-BB5m5-XL.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/chevron-down-Dpcjx79R.js",
			"/assets/circle-alert-BBaM1Bnj.js",
			"/assets/circle-check-CvCZVo8U.js",
			"/assets/circle-pause-BgPu_ZZG.js",
			"/assets/circle-x-A8LJwENZ.js",
			"/assets/send-DHANv9AT.js",
			"/assets/user-C7M_r1VX.js"
		]
	},
	"/_authenticated/interviewer/review/$id": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.interviewer.review.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.interviewer.review._id-B5INLjPx.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/AnimatePresence-BB5m5-XL.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/calendar-UpsXhG0C.js",
			"/assets/clock-qf84njfM.js",
			"/assets/download-CRwij_be.js",
			"/assets/external-link-xDgeNPSR.js",
			"/assets/graduation-cap-D6mm9tEu.js",
			"/assets/map-pin-aj-cXMGE.js",
			"/assets/star-QvD3ADdz.js",
			"/assets/user-C7M_r1VX.js",
			"/assets/scorecard-YJeC1y9O.js"
		]
	},
	"/_authenticated/offer/builder/$candidateId": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.offer.builder.$candidateId.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.offer.builder._candidateId-BH_G1BMz.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/graduation-cap-D6mm9tEu.js",
			"/assets/phone-DBFNibc3.js",
			"/assets/save-BIH1nRYn.js",
			"/assets/send-DHANv9AT.js",
			"/assets/card-BRC5zETd.js"
		]
	},
	"/_authenticated/offer/preview/$candidateId": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.offer.preview.$candidateId.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.offer.preview._candidateId-N-5UzgJc.js",
			"/assets/skeleton-CUXnEPUs.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/circle-x-A8LJwENZ.js",
			"/assets/clock-qf84njfM.js",
			"/assets/send-DHANv9AT.js",
			"/assets/card-BRC5zETd.js",
			"/assets/hooks-DOUJz_mf.js"
		]
	},
	"/_authenticated/offer/status/$candidateId": {
		filePath: "C:/Users/dhruv/Desktop/Atlas_HR_project-main/frontend-new/src/routes/_authenticated.offer.status.$candidateId.tsx",
		children: void 0,
		preloads: [
			"/assets/_authenticated.offer.status._candidateId-BDA8ZgK_.js",
			"/assets/proxy-qVDlFJ9U.js",
			"/assets/arrow-left-CPpVFeJX.js",
			"/assets/briefcase-C7r-ypJM.js",
			"/assets/circle-check-big-CduxdhAn.js",
			"/assets/circle-x-A8LJwENZ.js",
			"/assets/clock-qf84njfM.js",
			"/assets/phone-DBFNibc3.js",
			"/assets/send-DHANv9AT.js",
			"/assets/user-C7M_r1VX.js",
			"/assets/hooks-DOUJz_mf.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
