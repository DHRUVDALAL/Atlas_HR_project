import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.interviewer.evaluate._id-CZEBw3EA.js
var $$splitComponentImporter = () => import("./_authenticated.interviewer.evaluate._id-BFl4jY4S.mjs");
var Route = createFileRoute("/_authenticated/interviewer/evaluate/$id")({
	head: () => ({ meta: [{ title: "Technical Evaluation — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
