import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.final-discussion._id-yQbVexvX.js
var $$splitComponentImporter = () => import("./_authenticated2.final-discussion._id-Lbm3X4Dn.mjs");
var Route = createFileRoute("/_authenticated/final-discussion/$id")({
	head: () => ({ meta: [{ title: "Final Discussion — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
