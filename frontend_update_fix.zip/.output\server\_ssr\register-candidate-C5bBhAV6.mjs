import { o as __toESM } from "../_runtime.mjs";
import { n as api } from "./api-85Rra_o2.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as cn } from "./utils-BjLc2HNT.mjs";
import { t as Button } from "./button-B_S4Wnqd.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as CheckboxIndicator, t as Checkbox$1 } from "../_libs/@radix-ui/react-checkbox+[...].mjs";
import { B as FileText, C as Plus, D as MapPin, Q as Circle, c as TriangleAlert, d as Trash2, lt as Check, nt as CircleCheck, ot as ChevronRight, rt as CircleCheckBig, st as ChevronLeft } from "../_libs/lucide-react.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-CAzbakW8.mjs";
import { n as AnimatePresence, t as motion } from "../_libs/framer-motion+[...].mjs";
import { n as RadioGroupIndicator, r as RadioGroupItem$1, t as RadioGroup$1 } from "../_libs/@radix-ui/react-radio-group+[...].mjs";
import { t as Card } from "./card-CIRKiXmB.mjs";
import { t as Label } from "./label-BgXw8JJ9.mjs";
import { t as Textarea } from "./textarea-DrnUOz5f.mjs";
import { t as Input } from "./input-yj8bgoN5.mjs";
import { t as Route } from "./register-candidate-BIg2WqKn.mjs";
import { n as country_default, t as state_default } from "../_libs/country-state-city.mjs";
import { t as SignatureCanvas } from "../_libs/react-signature-canvas+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/register-candidate-C5bBhAV6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Checkbox = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox$1, {
	ref,
	className: cn("grid place-content-center peer h-4 w-4 shrink-0 rounded-sm border border-primary shadow cursor-pointer focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=checked]:text-primary-foreground", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckboxIndicator, {
		className: cn("grid place-content-center text-current"),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-4 w-4" })
	})
}));
Checkbox.displayName = Checkbox$1.displayName;
var RadioGroup = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup$1, {
		className: cn("grid gap-2", className),
		...props,
		ref
	});
});
RadioGroup.displayName = RadioGroup$1.displayName;
var RadioGroupItem = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem$1, {
		ref,
		className: cn("aspect-square h-4 w-4 rounded-full border border-primary text-primary shadow cursor-pointer focus:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupIndicator, {
			className: "flex items-center justify-center",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Circle, { className: "h-3.5 w-3.5 fill-primary" })
		})
	});
});
RadioGroupItem.displayName = RadioGroupItem$1.displayName;
var PHONE_COUNTRIES = [
	{
		code: "IN",
		name: "India",
		dialCode: "+91",
		flag: "🇮🇳",
		phoneLength: 10
	},
	{
		code: "US",
		name: "United States",
		dialCode: "+1",
		flag: "🇺🇸",
		phoneLength: 10
	},
	{
		code: "AE",
		name: "United Arab Emirates",
		dialCode: "+971",
		flag: "🇦🇪",
		phoneLength: 9
	},
	{
		code: "GB",
		name: "United Kingdom",
		dialCode: "+44",
		flag: "🇬🇧",
		phoneLength: 10
	},
	{
		code: "CA",
		name: "Canada",
		dialCode: "+1",
		flag: "🇨🇦",
		phoneLength: 10
	},
	{
		code: "AU",
		name: "Australia",
		dialCode: "+61",
		flag: "🇦🇺",
		phoneLength: 9
	},
	{
		code: "DE",
		name: "Germany",
		dialCode: "+49",
		flag: "🇩🇪",
		phoneLength: 11
	},
	{
		code: "FR",
		name: "France",
		dialCode: "+33",
		flag: "🇫🇷",
		phoneLength: 9
	},
	{
		code: "SG",
		name: "Singapore",
		dialCode: "+65",
		flag: "🇸🇬",
		phoneLength: 8
	},
	{
		code: "JP",
		name: "Japan",
		dialCode: "+81",
		flag: "🇯🇵",
		phoneLength: 10
	},
	{
		code: "BR",
		name: "Brazil",
		dialCode: "+55",
		flag: "🇧🇷",
		phoneLength: 11
	},
	{
		code: "ZA",
		name: "South Africa",
		dialCode: "+27",
		flag: "🇿🇦",
		phoneLength: 9
	},
	{
		code: "SA",
		name: "Saudi Arabia",
		dialCode: "+966",
		flag: "🇸🇦",
		phoneLength: 9
	},
	{
		code: "NG",
		name: "Nigeria",
		dialCode: "+234",
		flag: "🇳🇬",
		phoneLength: 10
	},
	{
		code: "PK",
		name: "Pakistan",
		dialCode: "+92",
		flag: "🇵🇰",
		phoneLength: 10
	},
	{
		code: "BD",
		name: "Bangladesh",
		dialCode: "+880",
		flag: "🇧🇩",
		phoneLength: 10
	},
	{
		code: "PH",
		name: "Philippines",
		dialCode: "+63",
		flag: "🇵🇭",
		phoneLength: 10
	},
	{
		code: "MY",
		name: "Malaysia",
		dialCode: "+60",
		flag: "🇲🇾",
		phoneLength: 9
	},
	{
		code: "NZ",
		name: "New Zealand",
		dialCode: "+64",
		flag: "🇳🇿",
		phoneLength: 9
	},
	{
		code: "IT",
		name: "Italy",
		dialCode: "+39",
		flag: "🇮🇹",
		phoneLength: 10
	}
];
function PhoneInput({ label, value, onChange, countryCode, onCountryCodeChange, disabled = false, required = false, error, placeholder = "Enter phone number" }) {
	const [search, setSearch] = (0, import_react.useState)("");
	const inputRef = (0, import_react.useRef)(null);
	const selectedCountry = (0, import_react.useMemo)(() => PHONE_COUNTRIES.find((c) => c.dialCode === countryCode) ?? PHONE_COUNTRIES[0], [countryCode]);
	const filteredCountries = (0, import_react.useMemo)(() => {
		if (!search) return PHONE_COUNTRIES;
		const q = search.toLowerCase();
		return PHONE_COUNTRIES.filter((c) => c.name.toLowerCase().includes(q) || c.dialCode.includes(q) || c.code.toLowerCase().includes(q));
	}, [search]);
	(0, import_react.useEffect)(() => {
		setSearch("");
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
				className: "text-sm font-semibold",
				children: [
					label,
					" ",
					required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-destructive",
						children: "*"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "w-[140px] shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: countryCode,
						onValueChange: (val) => {
							onCountryCodeChange(val);
							setSearch("");
						},
						disabled,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: cn("h-9 rounded-lg", error && "border-destructive"),
							"aria-label": "Select country code",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: selectedCountry.flag }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs",
									children: selectedCountry.dialCode
								})]
							}) })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
							className: "max-h-[300px] p-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sticky top-0 z-10 bg-popover p-2 border-b",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									placeholder: "Search country...",
									value: search,
									onChange: (e) => setSearch(e.target.value),
									className: "h-8 text-sm",
									onKeyDown: (e) => {
										if (e.key === "Escape") setSearch("");
									},
									autoFocus: true
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-y-auto max-h-[250px]",
								children: filteredCountries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "px-3 py-2 text-sm text-muted-foreground",
									children: "No countries found"
								}) : filteredCountries.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: c.dialCode,
									className: "cursor-pointer",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.flag }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-sm",
												children: c.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-xs text-muted-foreground",
												children: c.dialCode
											})
										]
									})
								}, c.code))
							})]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex-1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						ref: inputRef,
						type: "tel",
						value,
						onChange: (e) => {
							const raw = e.target.value;
							if (/^[\d\s\-+()]*$/.test(raw)) onChange(raw);
						},
						placeholder,
						disabled,
						className: cn("h-9 rounded-lg", error && "border-destructive"),
						"aria-label": "Phone number",
						autoComplete: "tel"
					})
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
function SearchableSelect({ label, value, onValueChange, options, placeholder, disabled = false, required = false, error, loading = false }) {
	const [search, setSearch] = (0, import_react.useState)("");
	const filtered = (0, import_react.useMemo)(() => {
		let result = options;
		if (search) {
			const q = search.toLowerCase();
			result = options.filter((o) => o.label.toLowerCase().includes(q));
		}
		return result.slice(0, 50);
	}, [search, options]);
	(0, import_react.useEffect)(() => {
		setSearch("");
	}, [value]);
	const displayLabel = options.find((o) => o.value === value)?.label;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
				className: "text-sm font-semibold",
				children: [
					label,
					" ",
					required && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-destructive",
						children: "*"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
				value,
				onValueChange: (val) => {
					onValueChange(val);
					setSearch("");
				},
				disabled: disabled || loading,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
					className: cn("h-9 rounded-lg", error && "border-destructive"),
					"aria-label": `Select ${label.toLowerCase()}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {
						placeholder: loading ? "Loading..." : placeholder,
						children: displayLabel
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
					className: "max-h-[300px] p-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sticky top-0 z-10 bg-popover p-2 border-b",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							placeholder: `Search ${label.toLowerCase()}...`,
							value: search,
							onChange: (e) => setSearch(e.target.value),
							className: "h-8 text-sm",
							onKeyDown: (e) => {
								if (e.key === "Escape") setSearch("");
							},
							autoFocus: true
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-y-auto max-h-[250px]",
						children: filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-3 py-2 text-sm text-muted-foreground",
							children: "No options found"
						}) : filtered.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
							value: opt.value,
							className: "cursor-pointer",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-sm",
								children: opt.label
							})
						}, opt.value))
					})]
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-destructive",
				children: error
			})
		]
	});
}
function LocationSelect({ country, state, city, pincode, onCountryChange, onStateChange, onCityChange, onPincodeChange, disabled = false, errors }) {
	const [countries] = (0, import_react.useState)(() => country_default.getAllCountries());
	const [states, setStates] = (0, import_react.useState)([]);
	const [loadingStates, setLoadingStates] = (0, import_react.useState)(false);
	const countryOptions = (0, import_react.useMemo)(() => countries.sort((a, b) => a.name.localeCompare(b.name)).map((c) => ({
		value: c.name,
		label: `${c.flag} ${c.name}`
	})), [countries]);
	const stateOptions = (0, import_react.useMemo)(() => states.sort((a, b) => a.name.localeCompare(b.name)).map((s) => ({
		value: s.name,
		label: s.name
	})), [states]);
	const selectedCountryObj = (0, import_react.useMemo)(() => countries.find((c) => c.name === country), [countries, country]);
	const loadStates = (0, import_react.useCallback)(async (countryCode) => {
		setLoadingStates(true);
		try {
			const result = state_default.getStatesOfCountry(countryCode) || [];
			setStates(result);
		} catch {
			setStates([]);
		} finally {
			setLoadingStates(false);
		}
	}, []);
	(0, import_react.useEffect)(() => {
		if (selectedCountryObj) loadStates(selectedCountryObj.isoCode);
		else setStates([]);
	}, [selectedCountryObj, loadStates]);
	const handleCountryChange = (val) => {
		onCountryChange(val);
		onStateChange("");
	};
	const handleStateChange = (val) => {
		onStateChange(val);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid sm:grid-cols-2 gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
				label: "Country",
				value: country,
				onValueChange: handleCountryChange,
				options: countryOptions,
				placeholder: "Select Country",
				disabled,
				required: true,
				error: errors?.country
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SearchableSelect, {
				label: "State",
				value: state,
				onValueChange: handleStateChange,
				options: stateOptions,
				placeholder: country ? "Select State" : "Select country first",
				disabled: disabled || !country,
				required: true,
				loading: loadingStates,
				error: errors?.state
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
						className: "text-sm font-semibold",
						children: ["City ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-destructive",
							children: "*"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: city,
						onChange: (e) => onCityChange(e.target.value),
						placeholder: state ? "Enter city" : "Select state first",
						disabled: disabled || !state,
						className: cn("h-9 rounded-lg", errors?.city && "border-destructive")
					}),
					errors?.city && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-destructive",
						children: errors.city
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
						className: "text-sm font-semibold",
						children: ["Pincode ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-destructive",
							children: "*"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: pincode,
						onChange: (e) => onPincodeChange(e.target.value),
						placeholder: city ? "Enter pincode" : "Enter city first",
						disabled: disabled || !city,
						className: cn("h-9 rounded-lg", errors?.pincode && "border-destructive")
					}),
					errors?.pincode && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-destructive",
						children: errors.pincode
					})
				]
			})
		]
	});
}
var DRAFT_KEY = "candidate_form_draft";
var PERSONALITY_QUESTIONS = [
	"I am comfortable presenting my point of view to people senior to me.",
	"I can usually tell when someone around me is having a difficult day, even if they haven’t said anything.",
	"When something goes wrong, my first instinct is to look for what I can fix rather than who is responsible.",
	"I am at ease making decisions when the available information is incomplete.",
	"I naturally adjust the way I speak depending on whether I’m talking to a peer, a client, or a junior colleague.",
	"I often volunteer for tasks that are outside my formal job description.",
	"If I don’t know something, I’d rather say so than risk giving an incorrect answer.",
	"During disagreements, I try to fully understand the other person’s reasoning before responding.",
	"I find it energising to receive constructive criticism because it helps me improve.",
	"I trust my ability to quickly get up to speed in unfamiliar areas.",
	"I genuinely enjoy understanding what drives the people I work with.",
	"When I face a setback, I tend to recover quickly and look for an alternative path.",
	"I am comfortable leading a group even when I am not the most experienced person in the room.",
	"I listen without interrupting, even when I strongly disagree with what is being said.",
	"I prefer to solve problems on my own before seeking help.",
	"I can work productively even when clear instructions or guidelines are not available.",
	"In a team conflict, I make it a point to hear everyone’s side before forming my opinion.",
	"I actively seek feedback rather than waiting for it to come to me."
];
var SITUATIONAL_QUESTIONS = [
	{
		prompt: "Your team is behind on a critical deadline. A colleague responsible for a key deliverable has been struggling. When you ask about progress, they seem stressed and defensive.",
		options: [
			"Escalate the delay to your manager immediately to protect the timeline.",
			"Sit down privately with the colleague, acknowledge the pressure, and ask if there’s anything blocking them that you can help with.",
			"Take over their work yourself to make sure the deadline is met.",
			"Send a detailed status email to the team lead documenting the delay."
		]
	},
	{
		prompt: "During a client presentation, the client challenges your recommendation sharply and in front of the entire room. You believe the criticism is only partially valid.",
		options: [
			"Stay composed, acknowledge the valid parts of their concern, and suggest reviewing the specific points together after the meeting.",
			"Defend your recommendation immediately with supporting data.",
			"Apologise and offer to rework the entire recommendation.",
			"Stay quiet during the meeting and raise it with your manager later."
		]
	},
	{
		prompt: "You have been assigned a project in a domain you have little prior experience in. It starts next week and expectations are high.",
		options: [
			"Tell your manager upfront that you may not be the right person for this.",
			"Dive into research, map out your knowledge gaps, and set up conversations with people who know the domain.",
			"Accept confidently and figure things out as they come, without asking for help.",
			"Ask the project sponsor for a detailed brief and propose a short ramp-up plan before committing to deliverables."
		]
	},
	{
		prompt: "A junior colleague tells you privately that they feel ignored during team discussions. They are visibly upset but ask you not to tell anyone.",
		options: [
			"Respect their wish completely and take no further action.",
			"Listen carefully, reassure them, and gently encourage them to bring it up with the team lead — offering to go with them if it helps.",
			"Report the matter to HR immediately since it could indicate a broader culture issue.",
			"Speak to the other team members yourself about being more inclusive, without naming the person."
		]
	},
	{
		prompt: "You strongly believe a decision made by leadership will cause problems down the line, but the rest of the team has accepted it without objection.",
		options: [
			"Go along with the decision — leadership probably has information you don’t.",
			"Raise your concern constructively in the next appropriate forum, presenting your reasoning clearly while remaining open to being wrong.",
			"Discuss your concerns informally with a few trusted colleagues to test whether they share your view.",
			"Document your objection in writing so that your position is on record if things go wrong."
		]
	}
];
var WRITTEN_QUESTIONS = [
	"Tell us about a time someone gave you feedback that was hard to hear. How did you respond, and what did you take away from it?",
	"What does “taking responsibility” look like in practice? Share an example from your experience.",
	"Describe a moment when you went out of your way to help a colleague without being asked. What prompted you to act?",
	"Think of a time when your view was clearly in the minority within a group. What did you do?",
	"When you encounter someone whose working style is very different from yours, how do you typically handle it?"
];
function RegisterCandidate() {
	const navigate = useNavigate();
	const { edit: editId } = Route.useSearch();
	const isEditMode = !!editId;
	const [step, setStep] = (0, import_react.useState)(0);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	const [isReadOnly, setIsReadOnly] = (0, import_react.useState)(false);
	const [submitted, setSubmitted] = (0, import_react.useState)(null);
	const [file, setFile] = (0, import_react.useState)(null);
	const [existingSignatureName, setExistingSignatureName] = (0, import_react.useState)("");
	const sigCanvas = (0, import_react.useRef)(null);
	const [showSignaturePad, setShowSignaturePad] = (0, import_react.useState)(false);
	const [personal, setPersonal] = (0, import_react.useState)({
		first_name: "",
		middle_name: "",
		last_name: "",
		email: "",
		phone: "",
		alternate_phone: "",
		gender: "",
		date_of_birth: "",
		current_address: "",
		permanent_address: "",
		city: "",
		state: "",
		country: "India",
		pincode: "",
		position_applied_for: "",
		applied_from: "",
		source_name: "",
		reference_number: ""
	});
	const [phoneCountryCode, setPhoneCountryCode] = (0, import_react.useState)("+91");
	const [altPhoneCountryCode, setAltPhoneCountryCode] = (0, import_react.useState)("+91");
	const [sameAsCurrent, setSameAsCurrent] = (0, import_react.useState)(false);
	const [prof, setProf] = (0, import_react.useState)({
		total_experience: "",
		relevant_experience: "",
		current_company: "",
		current_designation: "",
		current_ctc: "",
		expected_ctc: "",
		notice_period: "",
		joining_availability: "",
		preferred_location: "",
		employment_type: "FULL_TIME"
	});
	const [employment, setEmployment] = (0, import_react.useState)([blankEmployment()]);
	const [education, setEducation] = (0, import_react.useState)([blankEducation()]);
	const [personality, setPersonality] = (0, import_react.useState)(Array(PERSONALITY_QUESTIONS.length).fill(0));
	const [situational, setSituational] = (0, import_react.useState)(Array(SITUATIONAL_QUESTIONS.length).fill(""));
	const [written, setWritten] = (0, import_react.useState)(Array(WRITTEN_QUESTIONS.length).fill(""));
	const [declaration, setDeclaration] = (0, import_react.useState)(false);
	const [consent, setConsent] = (0, import_react.useState)(false);
	const steps = [
		"Personal Information",
		"Professional Details",
		"Employment History",
		"Education",
		"Perspective Assessment",
		"Workplace Scenarios",
		"Descriptive Questions",
		"Declaration & Submit"
	];
	(0, import_react.useEffect)(() => {
		if (isEditMode) return;
		try {
			const raw = localStorage.getItem(DRAFT_KEY);
			if (raw) {
				const draft = JSON.parse(raw);
				if (draft.step !== void 0) setStep(draft.step);
				if (draft.personal) setPersonal(draft.personal);
				if (draft.prof) setProf(draft.prof);
				if (draft.employment) setEmployment(draft.employment);
				if (draft.education) setEducation(draft.education);
				if (draft.personality) setPersonality(draft.personality);
				if (draft.situational) setSituational(draft.situational);
				if (draft.written) setWritten(draft.written);
				if (draft.declaration !== void 0) setDeclaration(draft.declaration);
				if (draft.consent !== void 0) setConsent(draft.consent);
				if (draft.phoneCountryCode) setPhoneCountryCode(draft.phoneCountryCode);
				if (draft.altPhoneCountryCode) setAltPhoneCountryCode(draft.altPhoneCountryCode);
				if (draft.sameAsCurrent !== void 0) setSameAsCurrent(draft.sameAsCurrent);
			}
		} catch (e) {
			console.warn("Failed to load form draft", e);
		}
	}, [isEditMode]);
	(0, import_react.useEffect)(() => {
		if (sameAsCurrent) setPersonal((prev) => ({
			...prev,
			permanent_address: prev.current_address
		}));
	}, [sameAsCurrent, personal.current_address]);
	(0, import_react.useEffect)(() => {
		if (isEditMode) return;
		try {
			const draft = {
				step,
				personal,
				prof,
				employment,
				education,
				personality,
				situational,
				written,
				declaration,
				consent,
				phoneCountryCode,
				altPhoneCountryCode,
				sameAsCurrent
			};
			localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
		} catch (e) {}
	}, [
		step,
		personal,
		prof,
		employment,
		education,
		personality,
		situational,
		written,
		declaration,
		consent,
		phoneCountryCode,
		altPhoneCountryCode,
		sameAsCurrent,
		isEditMode
	]);
	(0, import_react.useEffect)(() => {
		if (!editId) return;
		async function loadCandidateData() {
			try {
				const res = await api(`/api/applicants/${editId}`);
				if (res && res.success && res.data) {
					const c = res.data;
					if (![
						"DRAFT",
						"SUBMITTED",
						"Submitted — awaiting reception"
					].includes(c.status)) {
						setIsReadOnly(true);
						toast.error("This application is past the pre-arrival stage and is read-only.");
					}
					setPersonal({
						first_name: c.first_name || "",
						middle_name: c.middle_name || "",
						last_name: c.last_name || "",
						email: c.email || "",
						phone: c.phone || "",
						alternate_phone: c.alternate_phone || "",
						gender: c.gender || "",
						date_of_birth: c.date_of_birth || "",
						current_address: c.current_address || "",
						permanent_address: c.permanent_address || "",
						city: c.city || "",
						state: c.state || "",
						country: c.country || "India",
						pincode: c.pincode || "",
						position_applied_for: c.position_applied_for || "",
						applied_from: c.applied_from || "",
						source_name: c.source_name || "",
						reference_number: c.reference_number || ""
					});
					if (c.permanent_address && c.current_address && c.permanent_address === c.current_address) setSameAsCurrent(true);
					if (c.professional_details) setProf({
						total_experience: c.professional_details.total_experience?.toString() || "",
						relevant_experience: c.professional_details.relevant_experience?.toString() || "",
						current_company: c.professional_details.current_company || "",
						current_designation: c.professional_details.current_designation || "",
						current_ctc: c.professional_details.current_ctc?.toString() || "",
						expected_ctc: c.professional_details.expected_ctc?.toString() || "",
						notice_period: c.professional_details.notice_period || "",
						joining_availability: c.professional_details.joining_availability || "",
						preferred_location: c.professional_details.preferred_location || "",
						employment_type: c.professional_details.employment_type || "FULL_TIME"
					});
					if (c.employment_history && c.employment_history.length > 0) setEmployment(c.employment_history);
					if (c.education && c.education.length > 0) setEducation(c.education.map((e) => ({
						qualification: e.qualification || "",
						specialization: e.specialization || "",
						institution_name: e.institution_name || "",
						university: e.university || "",
						passing_year: e.passing_year?.toString() || "",
						percentage: e.percentage?.toString() || "",
						grade: e.grade || ""
					})));
					if (c.personality_assessment) {
						const arr = Array(PERSONALITY_QUESTIONS.length).fill(0);
						c.personality_assessment.forEach((pa) => {
							if (pa.question_number >= 1 && pa.question_number <= arr.length) arr[pa.question_number - 1] = pa.rating;
						});
						setPersonality(arr);
					}
					if (c.situational_responses) {
						const arr = Array(SITUATIONAL_QUESTIONS.length).fill("");
						c.situational_responses.forEach((sr) => {
							if (sr.question_number >= 1 && sr.question_number <= arr.length) arr[sr.question_number - 1] = sr.selected_option;
						});
						setSituational(arr);
					}
					if (c.written_responses) {
						const arr = Array(WRITTEN_QUESTIONS.length).fill("");
						c.written_responses.forEach((wr) => {
							if (wr.question_number >= 1 && wr.question_number <= arr.length) arr[wr.question_number - 1] = wr.answer_text;
						});
						setWritten(arr);
					}
					setDeclaration(c.declaration?.declaration_accepted ?? false);
					setConsent(c.declaration?.consent_accepted ?? false);
					const sigDoc = (c.documents || []).find((d) => d.document_type === "SIGNATURE_PDF");
					if (sigDoc) setExistingSignatureName(sigDoc.file_name || "Uploaded Signature PDF");
				}
			} catch (e) {
				toast.error("Failed to load candidate details for editing");
			}
		}
		loadCandidateData();
	}, [editId]);
	const validateStep = (s) => {
		if (s === 0) {
			if (!personal.first_name) return "First name is required.";
			if (!personal.last_name) return "Last name is required.";
			if (!personal.email) return "Email address is required.";
			if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(personal.email)) return "Invalid email address format.";
			if (!personal.phone) return "Phone number is required.";
			if (personal.phone.replace(/[^\d]/g, "").length !== 10) return "Please enter a valid phone number. Phone number must be exactly 10 digits.";
			if (personal.alternate_phone) {
				if (personal.alternate_phone.replace(/[^\d]/g, "").length !== 10) return "Please enter a valid alternate phone number. Phone number must be exactly 10 digits.";
			}
			if (!personal.gender) return "Select a gender.";
			if (!personal.date_of_birth) return "Date of birth is required.";
			if (new Date(personal.date_of_birth) > /* @__PURE__ */ new Date()) return "Date of birth cannot be a future date.";
			if (!personal.current_address) return "Current address is required.";
			if (personal.current_address.length < 5) return "Current address must be at least 5 characters.";
			if (!personal.country) return "Please select your country.";
			if (!personal.state) return "Please select your state.";
			if (!personal.city) return "Please select your city.";
			if (!personal.pincode) return "Please select your pincode.";
			if (personal.pincode.length < 4 || personal.pincode.length > 10) return "Pincode must be between 4 and 10 characters.";
			if (!personal.position_applied_for) return "Position applied for is required.";
			if (!personal.applied_from) return "Please select how you applied.";
		}
		if (s === 1) {
			if (prof.total_experience === "") return "Total experience is required.";
			if (isNaN(Number(prof.total_experience)) || Number(prof.total_experience) < 0) return "Total experience must be a non-negative number.";
			if (prof.relevant_experience === "") return "Relevant experience is required.";
			if (isNaN(Number(prof.relevant_experience)) || Number(prof.relevant_experience) < 0) return "Relevant experience must be a non-negative number.";
			if (prof.current_ctc !== "" && (isNaN(Number(prof.current_ctc)) || Number(prof.current_ctc) < 0)) return "Current CTC must be a non-negative number.";
			if (prof.expected_ctc !== "" && (isNaN(Number(prof.expected_ctc)) || Number(prof.expected_ctc) < 0)) return "Expected CTC must be a non-negative number.";
			if (!prof.employment_type) return "Employment type is required.";
		}
		if (s === 2) for (let i = 0; i < employment.length; i++) {
			const item = employment[i];
			if (item.company_name || item.designation || item.start_date || item.end_date || item.responsibilities || item.reason_for_leaving) {
				if (!item.company_name || !item.designation || !item.start_date) return `Please fill out all required fields (Company, Designation, Start Date) for Employment #${i + 1}.`;
				if (item.end_date && new Date(item.end_date) < new Date(item.start_date)) return `End date cannot be before start date for Employment #${i + 1}.`;
			}
		}
		if (s === 3) {
			if (education.length === 0) return "Please add at least one Educational Qualification.";
			for (let i = 0; i < education.length; i++) {
				const item = education[i];
				if (!item.qualification || !item.institution_name || !item.passing_year) return `Please fill out all required fields (Qualification, Institution, Passing Year) for Education #${i + 1}.`;
				const pYear = Number(item.passing_year);
				const curYear = (/* @__PURE__ */ new Date()).getFullYear();
				if (isNaN(pYear) || pYear < 1900 || pYear > curYear) return `Passing year must be between 1900 and ${curYear} for Education #${i + 1}.`;
				if (item.percentage !== "") {
					const pct = Number(item.percentage);
					if (isNaN(pct) || pct < 0 || pct > 100) return `Percentage must be between 0 and 100 for Education #${i + 1}.`;
				}
			}
		}
		if (s === 4) {
			if (personality.filter((v) => v > 0).length < PERSONALITY_QUESTIONS.length) return `Please rate all ${PERSONALITY_QUESTIONS.length} perspective statements.`;
		}
		if (s === 5) {
			if (situational.filter((v) => v !== "").length < SITUATIONAL_QUESTIONS.length) return `Please answer all ${SITUATIONAL_QUESTIONS.length} workplace scenarios.`;
		}
		if (s === 6) {
			for (let i = 0; i < written.length; i++) if (!written[i] || written[i].trim().length < 20) return `Descriptive Question #${i + 1} must be at least 20 characters long.`;
		}
		if (s === 7) {
			if (!declaration || !consent) return "You must accept both the declaration and consent terms.";
			if (!file && !existingSignatureName) return "You must upload your signature PDF before submitting.";
		}
		return null;
	};
	const handleNext = () => {
		const error = validateStep(step);
		if (error) {
			toast.error(error);
			return;
		}
		setStep(step + 1);
	};
	const handleStepJump = (target) => {
		if (target === step) return;
		if (target < step) {
			setStep(target);
			return;
		}
		for (let i = step; i < target; i++) {
			const err = validateStep(i);
			if (err) {
				toast.error(`Please complete previous steps first: ${err}`);
				return;
			}
		}
		setStep(target);
	};
	const buildPayload = () => ({
		personal_details: {
			first_name: personal.first_name,
			middle_name: personal.middle_name || null,
			last_name: personal.last_name,
			email: personal.email,
			phone: personal.phone.replace(/[^\d]/g, ""),
			alternate_phone: personal.alternate_phone ? personal.alternate_phone.replace(/[^\d]/g, "") : null,
			gender: personal.gender,
			date_of_birth: personal.date_of_birth,
			current_address: personal.current_address,
			permanent_address: sameAsCurrent ? personal.current_address : personal.permanent_address || personal.current_address,
			city: personal.city,
			state: personal.state,
			country: personal.country,
			pincode: personal.pincode,
			position_applied_for: personal.position_applied_for || null,
			applied_from: personal.applied_from || null,
			source_name: personal.source_name || null,
			reference_number: personal.reference_number || null
		},
		professional_details: {
			current_company: prof.current_company || null,
			current_designation: prof.current_designation || null,
			total_experience: prof.total_experience ? parseFloat(prof.total_experience) : 0,
			relevant_experience: prof.relevant_experience ? parseFloat(prof.relevant_experience) : 0,
			current_ctc: prof.current_ctc ? parseFloat(prof.current_ctc) : null,
			expected_ctc: prof.expected_ctc ? parseFloat(prof.expected_ctc) : null,
			notice_period: prof.notice_period || null,
			joining_availability: prof.joining_availability || null,
			preferred_location: prof.preferred_location || null,
			employment_type: prof.employment_type || "FULL_TIME"
		},
		employment_history: employment.filter((e) => e.company_name).map((e) => ({
			company_name: e.company_name,
			designation: e.designation,
			start_date: e.start_date,
			end_date: e.end_date || null,
			responsibilities: e.responsibilities || null,
			reason_for_leaving: e.reason_for_leaving || null
		})),
		education: education.filter((e) => e.qualification).map((e) => ({
			qualification: e.qualification,
			institution_name: e.institution_name,
			university: e.university || null,
			passing_year: parseInt(e.passing_year),
			percentage: e.percentage ? parseFloat(e.percentage) : null,
			grade: e.grade || null,
			specialization: e.specialization || null
		})),
		personality_assessment: personality.map((rating, i) => ({
			question_number: i + 1,
			rating
		})),
		situational_responses: situational.map((selected_option, i) => ({
			question_number: i + 1,
			selected_option
		})),
		written_responses: written.map((answer_text, i) => ({
			question_number: i + 1,
			answer_text
		})),
		declaration: {
			declaration_accepted: !!declaration,
			consent_accepted: !!consent,
			signed_date: (/* @__PURE__ */ new Date()).toISOString().split("T")[0]
		}
	});
	const handleSaveSignature = async () => {
		if (!sigCanvas.current || sigCanvas.current.isEmpty()) {
			toast.error("Please provide a signature first.");
			return;
		}
		try {
			const rawCanvas = sigCanvas.current.getCanvas();
			if (!rawCanvas) {
				toast.error("Failed to process signature.");
				return;
			}
			const dataUrl = rawCanvas.toDataURL("image/png");
			if (!dataUrl) return;
			const { jsPDF } = await import("../_libs/jspdf.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			const pdf = new jsPDF({
				orientation: "landscape",
				unit: "mm",
				format: [100, 50]
			});
			pdf.addImage(dataUrl, "PNG", 5, 5, 90, 40);
			const pdfBlob = pdf.output("blob");
			const sigFile = new File([pdfBlob], "signature.pdf", { type: "application/pdf" });
			setFile(sigFile);
			setShowSignaturePad(false);
			toast.success("Signature saved successfully!");
		} catch (err) {
			console.error("Signature save error:", err);
			toast.error(`Failed: ${err?.message || "Unknown error"}`);
		}
	};
	async function submit() {
		const error = validateStep(step);
		if (error) {
			toast.error(error);
			return;
		}
		setSubmitting(true);
		try {
			const payload = buildPayload();
			if (isEditMode) {
				await api(`/api/applicant/${editId}`, {
					method: "PUT",
					body: payload
				});
				toast.success("Application updated successfully");
				navigate({ to: "/candidates" });
				return;
			}
			if (!file) {
				toast.error("Signature file is required for new submissions");
				setSubmitting(false);
				return;
			}
			const fd = new FormData();
			fd.append("payload", JSON.stringify(payload));
			fd.append("signature", file);
			const res = await api("/api/applicant", {
				method: "POST",
				body: fd,
				raw: true,
				auth: false
			});
			setSubmitted({
				application_number: res.data.application_number,
				candidate_id: res.data.candidate_id
			});
			localStorage.removeItem(DRAFT_KEY);
			toast.success("Application submitted successfully!");
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Submission failed");
		} finally {
			setSubmitting(false);
		}
	}
	if (submitted) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen grid place-items-center p-6 bg-[#fbfbfd]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
			initial: {
				opacity: 0,
				y: 20
			},
			animate: {
				opacity: 1,
				y: 0
			},
			transition: {
				duration: .5,
				ease: [
					.16,
					1,
					.3,
					1
				]
			},
			className: "max-w-md w-full bg-white p-10 text-center shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-gray-100 rounded-[2rem]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto h-16 w-16 rounded-full bg-green-50 grid place-items-center text-green-600 mb-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-8 w-8" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
					children: "Application Submitted"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-[#86868b] mt-3",
					children: "Thank you for applying to Atlas HR. Please save your application reference number below:"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 rounded-2xl bg-[#f5f5f7] py-5 px-6 font-mono text-2xl font-semibold tracking-widest text-[#1d1d1f]",
					children: submitted.application_number
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-[#86868b] mt-6 leading-relaxed",
					children: "Please carry a printout or digital copy of this reference number on your interview day."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 pt-8 border-t border-gray-100",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						className: "w-full rounded-full h-12 bg-[#1d1d1f] hover:bg-black text-white text-base font-medium shadow-sm transition-all active:scale-[0.98]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							children: "Return to Home"
						})
					})
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#fbfbfd] font-sans text-[#1d1d1f]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "bg-white/70 text-[#1d1d1f] border-b border-gray-100 sticky top-0 z-50 backdrop-blur-md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-5xl mx-auto px-6 py-4 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/logo.png",
						alt: "Atlas Logo",
						className: "h-8 w-auto"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-bold text-lg tracking-tight",
						children: "Atlas HR Portal"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs text-[#86868b]",
						children: "Recruitment Candidate Application Wizard"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					asChild: true,
					size: "sm",
					className: "rounded-full font-medium hover:bg-gray-100",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/login",
						className: "text-sm",
						children: "Staff Portal"
					})
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "max-w-5xl mx-auto px-6 py-10 grid lg:grid-cols-4 gap-10",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-1 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-transparent p-0 space-y-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-bold text-[#86868b] uppercase tracking-wider px-3 mb-4",
						children: "Application Steps"
					}), steps.map((label, idx) => {
						const isCurrent = step === idx;
						const isPast = step > idx;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => handleStepJump(idx),
							className: `w-full text-left px-4 py-2.5 rounded-xl text-sm font-medium transition flex items-center justify-between ${isCurrent ? "bg-gray-100 text-[#1d1d1f] font-semibold" : isPast ? "text-[#0066cc] hover:bg-blue-50/50" : "text-[#86868b] hover:bg-gray-50"}`,
							disabled: isReadOnly,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "truncate",
								children: [
									idx + 1,
									". ",
									label
								]
							}), isPast && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-4 w-4 shrink-0 ml-2" })]
						}, idx);
					})]
				}), isReadOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-4 rounded-xl border bg-orange-50 border-orange-100 text-orange-600 flex items-start gap-2 text-xs mt-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-4 w-4 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "This record is read-only and cannot be modified." })]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:col-span-3 space-y-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-xs text-[#86868b] mb-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"Step ",
							step + 1,
							" of ",
							steps.length,
							": ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
								className: "text-[#1d1d1f]",
								children: steps[step]
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "font-medium",
							children: [Math.round((step + 1) / steps.length * 100), "%"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1.5 w-full bg-gray-100 rounded-full overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-[#0066cc] transition-all duration-500 ease-out",
							style: { width: `${(step + 1) / steps.length * 100}%` }
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-8 md:p-10 rounded-[2rem] shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-gray-100 overflow-hidden relative",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
							mode: "wait",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									x: 20
								},
								animate: {
									opacity: 1,
									x: 0
								},
								exit: {
									opacity: 0,
									x: -20
								},
								transition: {
									duration: .4,
									ease: [
										.16,
										1,
										.3,
										1
									]
								},
								children: [
									step === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-bold tracking-tight mb-1",
											children: "Personal Details"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground",
											children: "Provide your contact details and application headers."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid sm:grid-cols-2 gap-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "First name *",
													value: personal.first_name,
													onChange: (v) => setPersonal({
														...personal,
														first_name: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Middle name",
													value: personal.middle_name,
													onChange: (v) => setPersonal({
														...personal,
														middle_name: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Last name *",
													value: personal.last_name,
													onChange: (v) => setPersonal({
														...personal,
														last_name: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Email address *",
													type: "email",
													value: personal.email,
													onChange: (v) => setPersonal({
														...personal,
														email: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "sm:col-span-2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneInput, {
														label: "Primary contact number",
														value: personal.phone,
														onChange: (v) => setPersonal({
															...personal,
															phone: v
														}),
														countryCode: phoneCountryCode,
														onCountryCodeChange: setPhoneCountryCode,
														disabled: isReadOnly,
														required: true,
														placeholder: "Enter phone number"
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "sm:col-span-2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneInput, {
														label: "Alternate contact number",
														value: personal.alternate_phone,
														onChange: (v) => setPersonal({
															...personal,
															alternate_phone: v
														}),
														countryCode: altPhoneCountryCode,
														onCountryCodeChange: setAltPhoneCountryCode,
														disabled: isReadOnly,
														placeholder: "Enter alternate phone number"
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Gender *" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
														value: personal.gender,
														onValueChange: (v) => setPersonal({
															...personal,
															gender: v
														}),
														disabled: isReadOnly,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "MALE",
																children: "Male"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "FEMALE",
																children: "Female"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "OTHERS",
																children: "Others"
															})
														] })]
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Date of birth *",
													type: "date",
													value: personal.date_of_birth,
													onChange: (v) => setPersonal({
														...personal,
														date_of_birth: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Position applied for *",
													value: personal.position_applied_for,
													onChange: (v) => setPersonal({
														...personal,
														position_applied_for: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
														className: "text-sm font-semibold",
														children: ["Applied From ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-destructive",
															children: "*"
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
														value: personal.applied_from,
														onValueChange: (v) => setPersonal((prev) => ({
															...prev,
															applied_from: v
														})),
														disabled: isReadOnly,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
															className: "h-9 rounded-lg",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select source" })
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "LINKEDIN",
																children: "LinkedIn"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "NAUKRI",
																children: "Naukri"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "VENDOR",
																children: "Vendor"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "REFERRAL",
																children: "Referral"
															})
														] })]
													})]
												}),
												personal.applied_from === "VENDOR" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Vendor Name",
													value: personal.source_name,
													onChange: (v) => setPersonal((prev) => ({
														...prev,
														source_name: v
													})),
													disabled: isReadOnly
												}),
												personal.applied_from === "REFERRAL" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Referred By",
													value: personal.source_name,
													onChange: (v) => setPersonal((prev) => ({
														...prev,
														source_name: v
													})),
													disabled: isReadOnly
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Reference Number",
													value: personal.reference_number,
													onChange: (v) => setPersonal((prev) => ({
														...prev,
														reference_number: v
													})),
													disabled: isReadOnly
												})] }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "sm:col-span-2 space-y-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Current address *" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
														value: personal.current_address,
														onChange: (e) => setPersonal({
															...personal,
															current_address: e.target.value
														}),
														disabled: isReadOnly
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "sm:col-span-2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocationSelect, {
														country: personal.country,
														state: personal.state,
														city: personal.city,
														pincode: personal.pincode,
														onCountryChange: (v) => setPersonal((prev) => ({
															...prev,
															country: v
														})),
														onStateChange: (v) => setPersonal((prev) => ({
															...prev,
															state: v
														})),
														onCityChange: (v) => setPersonal((prev) => ({
															...prev,
															city: v
														})),
														onPincodeChange: (v) => setPersonal((prev) => ({
															...prev,
															pincode: v
														})),
														disabled: isReadOnly
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "sm:col-span-2 pt-4",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-3 pb-3",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
															id: "sameAddress",
															checked: sameAsCurrent,
															onCheckedChange: (v) => {
																if (isReadOnly) return;
																const checked = !!v;
																setSameAsCurrent(checked);
																if (checked) setPersonal({
																	...personal,
																	permanent_address: personal.current_address
																});
															},
															disabled: isReadOnly
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
															htmlFor: "sameAddress",
															className: "font-semibold text-sm cursor-pointer flex items-center gap-1.5",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-3.5 w-3.5 text-muted-foreground" }), "Same as Current Address"]
														})]
													})
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "sm:col-span-2 space-y-2",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Permanent address" }),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
															value: sameAsCurrent ? personal.current_address : personal.permanent_address,
															onChange: (e) => setPersonal({
																...personal,
																permanent_address: e.target.value
															}),
															disabled: isReadOnly || sameAsCurrent,
															placeholder: sameAsCurrent ? "Auto-copied from current address" : "Enter permanent address (if different)",
															className: sameAsCurrent ? "bg-muted/50" : ""
														}),
														sameAsCurrent && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
															className: "text-xs text-muted-foreground",
															children: "Permanent address mirrors current address. Uncheck to edit separately."
														})
													]
												})
											]
										})]
									}),
									step === 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-bold tracking-tight mb-1",
											children: "Professional Details"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground",
											children: "Provide summary CTC, notices, and location choices."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid sm:grid-cols-2 gap-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Total experience (yrs) *",
													type: "number",
													value: prof.total_experience,
													onChange: (v) => setProf({
														...prof,
														total_experience: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Relevant experience (yrs) *",
													type: "number",
													value: prof.relevant_experience,
													onChange: (v) => setProf({
														...prof,
														relevant_experience: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Current company name",
													value: prof.current_company,
													onChange: (v) => setProf({
														...prof,
														current_company: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Current designation",
													value: prof.current_designation,
													onChange: (v) => setProf({
														...prof,
														current_designation: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Current CTC (LPA)",
													type: "number",
													value: prof.current_ctc,
													onChange: (v) => setProf({
														...prof,
														current_ctc: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Expected CTC (LPA)",
													type: "number",
													value: prof.expected_ctc,
													onChange: (v) => setProf({
														...prof,
														expected_ctc: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Notice period (e.g. 30 days)",
													value: prof.notice_period,
													onChange: (v) => setProf({
														...prof,
														notice_period: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Joining availability",
													value: prof.joining_availability,
													onChange: (v) => setProf({
														...prof,
														joining_availability: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
													label: "Preferred job location",
													value: prof.preferred_location,
													onChange: (v) => setProf({
														...prof,
														preferred_location: v
													}),
													disabled: isReadOnly
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Employment type *" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
														value: prof.employment_type,
														onValueChange: (v) => setProf({
															...prof,
															employment_type: v
														}),
														disabled: isReadOnly,
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "FULL_TIME",
																children: "Full time"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "PART_TIME",
																children: "Part time"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "CONTRACT",
																children: "Contract"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
																value: "INTERN",
																children: "Intern"
															})
														] })]
													})]
												})
											]
										})]
									}),
									step === 2 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-bold tracking-tight mb-1",
											children: "Employment History"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground mb-4",
											children: "List previous employment records chronologically."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-4",
											children: [employment.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
												className: "p-5 space-y-3 bg-muted/10 border relative",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex justify-between items-center mb-1",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "font-semibold text-sm text-primary",
															children: ["Position #", i + 1]
														}), employment.length > 1 && !isReadOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
															variant: "ghost",
															size: "sm",
															onClick: () => setEmployment(employment.filter((_, x) => x !== i)),
															className: "text-error hover:text-error/95",
															children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "grid sm:grid-cols-2 gap-3",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
																label: "Company name",
																value: row.company_name,
																onChange: (v) => patchArr(setEmployment, employment, i, { company_name: v }),
																disabled: isReadOnly
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
																label: "Designation",
																value: row.designation,
																onChange: (v) => patchArr(setEmployment, employment, i, { designation: v }),
																disabled: isReadOnly
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
																label: "Start date",
																type: "date",
																value: row.start_date,
																onChange: (v) => patchArr(setEmployment, employment, i, { start_date: v }),
																disabled: isReadOnly
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
																label: "End date",
																type: "date",
																value: row.end_date,
																onChange: (v) => patchArr(setEmployment, employment, i, { end_date: v }),
																disabled: isReadOnly
															})
														]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "space-y-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Key responsibilities" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
															value: row.responsibilities,
															onChange: (e) => patchArr(setEmployment, employment, i, { responsibilities: e.target.value }),
															disabled: isReadOnly
														})]
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "space-y-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Reason for leaving" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
															value: row.reason_for_leaving,
															onChange: (e) => patchArr(setEmployment, employment, i, { reason_for_leaving: e.target.value }),
															disabled: isReadOnly
														})]
													})
												]
											}, i)), !isReadOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "outline",
												onClick: () => setEmployment([...employment, blankEmployment()]),
												className: "w-full border-dashed",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4 mr-2" }), " Add employment row"]
											})]
										})]
									}),
									step === 3 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-bold tracking-tight mb-1",
											children: "Educational Qualifications"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground mb-4",
											children: "Provide details of your degrees and institution credentials."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-4",
											children: [education.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
												className: "p-5 space-y-3 bg-muted/10 border",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex justify-between items-center mb-1",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "font-semibold text-sm text-primary",
														children: ["Qualification #", i + 1]
													}), education.length > 1 && !isReadOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
														variant: "ghost",
														size: "sm",
														onClick: () => setEducation(education.filter((_, x) => x !== i)),
														className: "text-error hover:text-error/95",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "grid sm:grid-cols-2 gap-3",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
															label: "Qualification (e.g. B.Tech, SSC)",
															value: row.qualification,
															onChange: (v) => patchArr(setEducation, education, i, { qualification: v }),
															disabled: isReadOnly
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
															label: "Specialization (e.g. CSE)",
															value: row.specialization,
															onChange: (v) => patchArr(setEducation, education, i, { specialization: v }),
															disabled: isReadOnly
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
															label: "Institution name",
															value: row.institution_name,
															onChange: (v) => patchArr(setEducation, education, i, { institution_name: v }),
															disabled: isReadOnly
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
															label: "University / Board",
															value: row.university,
															onChange: (v) => patchArr(setEducation, education, i, { university: v }),
															disabled: isReadOnly
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
															label: "Passing year",
															type: "number",
															value: row.passing_year,
															onChange: (v) => patchArr(setEducation, education, i, { passing_year: v }),
															disabled: isReadOnly
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
															label: "Percentage / CGPA",
															type: "number",
															value: row.percentage,
															onChange: (v) => patchArr(setEducation, education, i, { percentage: v }),
															disabled: isReadOnly
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, {
															label: "Grade / Class (e.g. Distinction)",
															value: row.grade,
															onChange: (v) => patchArr(setEducation, education, i, { grade: v }),
															disabled: isReadOnly
														})
													]
												})]
											}, i)), !isReadOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
												variant: "outline",
												onClick: () => setEducation([...education, blankEducation()]),
												className: "w-full border-dashed",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4 mr-2" }), " Add education row"]
											})]
										})]
									}),
									step === 4 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-bold tracking-tight mb-1",
											children: "Your Perspective"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground",
											children: "Rate how much each statement describes you: 1 = Disagree, 5 = Agree."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "space-y-4",
											children: PERSONALITY_QUESTIONS.map((q, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "p-4 rounded-xl border bg-muted/5 flex items-center justify-between gap-4 flex-wrap hover:bg-muted/10 transition",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-sm font-medium flex-1 min-w-[200px]",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "text-muted-foreground mr-2 font-mono",
															children: [i + 1, "."]
														}),
														" ",
														q
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "flex gap-1.5",
													children: [
														1,
														2,
														3,
														4,
														5
													].map((n) => {
														return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
															type: "button",
															onClick: () => {
																if (isReadOnly) return;
																setPersonality(personality.map((v, x) => x === i ? n : v));
															},
															className: `h-9 w-9 rounded-lg border text-sm font-semibold transition ${personality[i] === n ? "bg-primary text-primary-foreground border-primary shadow-sm" : "bg-card text-foreground hover:bg-accent border-muted-foreground/20"}`,
															disabled: isReadOnly,
															children: n
														}, n);
													})
												})]
											}, i))
										})]
									}),
									step === 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-bold tracking-tight mb-1",
											children: "Workplace Scenarios"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground",
											children: "Select the option that matches how you would resolve the following scenarios."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "space-y-6",
											children: SITUATIONAL_QUESTIONS.map((q, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
												className: "p-5 space-y-4 border-l-4 border-l-primary",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-sm font-bold leading-relaxed",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
														className: "text-primary font-mono mr-2",
														children: [
															"Scenario ",
															i + 1,
															":"
														]
													}), q.prompt]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroup, {
													value: situational[i],
													onValueChange: (v) => {
														if (isReadOnly) return;
														setSituational(situational.map((x, idx) => idx === i ? v : x));
													},
													disabled: isReadOnly,
													className: "space-y-2.5",
													children: q.options.map((opt, oi) => {
														const letter = String.fromCharCode(65 + oi);
														return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: `flex items-start gap-3 p-3 rounded-lg border cursor-pointer hover:bg-muted/10 transition ${situational[i] === letter ? "bg-primary/5 border-primary" : "border-muted/40"}`,
															onClick: () => {
																if (isReadOnly) return;
																setSituational(situational.map((x, idx) => idx === i ? letter : x));
															},
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RadioGroupItem, {
																value: letter,
																id: `q${i}-${letter}`,
																className: "mt-0.5"
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
																htmlFor: `q${i}-${letter}`,
																className: "font-medium text-sm leading-normal flex-1 cursor-pointer",
																children: [
																	/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("b", {
																		className: "font-mono text-primary mr-1",
																		children: [letter, "."]
																	}),
																	" ",
																	opt
																]
															})]
														}, letter);
													})
												})]
											}, i))
										})]
									}),
									step === 6 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
											className: "text-xl font-bold tracking-tight mb-1",
											children: "Descriptive Questions"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-muted-foreground",
											children: "Provide descriptive answers (minimum 20 characters required)."
										})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "space-y-6",
											children: WRITTEN_QUESTIONS.map((q, i) => {
												const currentLength = (written[i] || "").trim().length;
												const isLengthOk = currentLength >= 20;
												return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "space-y-2.5",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Label, {
															className: "text-sm font-bold leading-relaxed",
															children: [
																"Q",
																i + 1,
																". ",
																q
															]
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
															className: "min-h-[120px] rounded-xl",
															value: written[i],
															onChange: (e) => {
																if (isReadOnly) return;
																setWritten(written.map((v, x) => x === i ? e.target.value : v));
															},
															placeholder: "Provide your response here (minimum 20 characters)...",
															disabled: isReadOnly
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "flex justify-between items-center text-xs mt-1",
															children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-muted-foreground",
																children: "Please write a concise answer."
															}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
																className: `font-bold ${isLengthOk ? "text-success" : "text-destructive"}`,
																children: [
																	currentLength,
																	" / 20+ characters ",
																	isLengthOk ? "✓" : "⚠"
																]
															})]
														})
													]
												}, i);
											})
										})]
									}),
									step === 7 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
												className: "text-xl font-bold tracking-tight mb-1",
												children: "Review & Declaration"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm text-muted-foreground",
												children: "Sign your consent terms and submit the application."
											})] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-3",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														className: "text-sm font-bold",
														children: "Digital Signature Verification Document *"
													}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
														className: "text-xs text-muted-foreground",
														children: "Please upload a PDF document containing your signed signature image or written digital signature (Max 5 MB)."
													}),
													!file && !existingSignatureName ? showSignaturePad ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "border rounded-2xl p-6 bg-[#fbfbfd] flex flex-col items-center",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
																className: "text-sm text-[#86868b] mb-4 font-medium",
																children: "Draw your signature inside the box below:"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																className: "bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm w-full max-w-sm",
																children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignatureCanvas, {
																	ref: sigCanvas,
																	penColor: "black",
																	canvasProps: { className: "w-full h-48 cursor-crosshair" }
																})
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex gap-3 mt-6 w-full max-w-sm",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																	variant: "outline",
																	type: "button",
																	onClick: () => sigCanvas.current?.clear(),
																	className: "flex-1 rounded-full h-10 font-medium",
																	children: "Clear"
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																	type: "button",
																	onClick: handleSaveSignature,
																	className: "flex-1 rounded-full h-10 bg-[#0066cc] text-white hover:bg-[#005bb5] font-medium",
																	children: "Save Signature"
																})]
															})
														]
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														onClick: () => !isReadOnly && setShowSignaturePad(true),
														className: `flex flex-col items-center justify-center border-2 border-dashed rounded-[2rem] p-10 transition ${isReadOnly ? "opacity-50 cursor-not-allowed" : "cursor-pointer hover:bg-gray-50 hover:border-[#0066cc]/50"}`,
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-10 w-10 text-[#0066cc] mb-3 opacity-80" }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-base font-semibold text-[#1d1d1f]",
																children: "Click to draw your signature"
															}),
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-xs text-[#86868b] mt-2",
																children: "A digital PDF signature will be generated automatically and attached to your application."
															})
														]
													}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-3 border rounded-xl p-4 bg-success/5 border-success/20",
														children: [
															/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-8 w-8 text-success" }),
															/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
																className: "flex-1 min-w-0",
																children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "text-sm font-semibold truncate text-success-foreground",
																	children: file ? file.name : existingSignatureName
																}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
																	className: "text-xs text-muted-foreground",
																	children: file ? `${(file.size / (1024 * 1024)).toFixed(2)} MB • PDF Signature Ready` : "Pre-uploaded signature PDF"
																})]
															}),
															!isReadOnly && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
																variant: "ghost",
																size: "sm",
																onClick: () => {
																	setFile(null);
																	setExistingSignatureName("");
																},
																className: "text-destructive hover:bg-destructive/5",
																children: "Remove"
															})
														]
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "rounded-xl border p-4 text-xs leading-relaxed text-muted-foreground bg-muted/20",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("b", {
														className: "text-foreground block mb-2",
														children: "Declaration terms statement:"
													}),
													"1. I hereby declare that all information provided in this form is true, complete, and accurate to the best of my knowledge. I understand that any misrepresentation may result in disqualification from the selection process or termination of employment if discovered subsequently.",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
													"2. I consent to Abhiyanta India Solutions Pvt. Ltd. using this information solely for the purpose of evaluating my candidature."
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "space-y-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start gap-2.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
														id: "decl",
														checked: declaration,
														onCheckedChange: (v) => {
															if (isReadOnly) return;
															setDeclaration(!!v);
														},
														disabled: isReadOnly
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														htmlFor: "decl",
														className: "font-semibold text-sm cursor-pointer leading-normal",
														children: "I accept the declaration terms statement (1)."
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-start gap-2.5",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Checkbox, {
														id: "consent",
														checked: consent,
														onCheckedChange: (v) => {
															if (isReadOnly) return;
															setConsent(!!v);
														},
														disabled: isReadOnly
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
														htmlFor: "consent",
														className: "font-semibold text-sm cursor-pointer leading-normal",
														children: "I accept the consent terms statement (2)."
													})]
												})]
											})
										]
									})
								]
							}, step)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between pt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => setStep(Math.max(0, step - 1)),
							disabled: step === 0,
							className: "rounded-full px-6 h-11",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4 mr-1" }), " Back"]
						}), step < steps.length - 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: handleNext,
							className: "rounded-full px-6 h-11 bg-[#0066cc] hover:bg-[#005bb5] text-white",
							children: ["Next ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4 ml-1" })]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: submit,
							disabled: submitting || isReadOnly,
							className: "rounded-full px-8 h-11 bg-[#1d1d1f] hover:bg-black text-white",
							children: submitting ? "Submitting…" : "Submit Application"
						})]
					})
				]
			})]
		})]
	});
}
function TextField({ label, value, onChange, type = "text", disabled = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			className: "text-sm font-semibold",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			type,
			value,
			onChange: (e) => onChange(e.target.value),
			disabled,
			className: "rounded-lg"
		})]
	});
}
function blankEmployment() {
	return {
		company_name: "",
		designation: "",
		start_date: "",
		end_date: "",
		responsibilities: "",
		reason_for_leaving: ""
	};
}
function blankEducation() {
	return {
		qualification: "",
		specialization: "",
		institution_name: "",
		university: "",
		passing_year: "",
		percentage: "",
		grade: ""
	};
}
function patchArr(setter, arr, i, patch) {
	setter(arr.map((row, x) => x === i ? {
		...row,
		...patch
	} : row));
}
//#endregion
export { RegisterCandidate as component };
