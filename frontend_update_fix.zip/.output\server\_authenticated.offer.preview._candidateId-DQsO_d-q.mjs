import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./_ssr/button-B_S4Wnqd.mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { $ as CircleX, S as Printer, V as FileCheck, Y as Clock, bt as ArrowLeft, rt as CircleCheckBig, v as Send } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { t as Card } from "./_ssr/card-CIRKiXmB.mjs";
import { i as useSendOffer, n as useDeclineOffer, r as useOffer, t as useAcceptOffer } from "./_ssr/hooks-D8-WUitX.mjs";
import { t as Route } from "./_authenticated.offer.preview._candidateId-DNTJHrTN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.offer.preview._candidateId-DQsO_d-q.js
var import_jsx_runtime = require_jsx_runtime();
function OfferPreview() {
	const { candidateId } = Route.useParams();
	const { data: candidate, isLoading: candidateLoading } = useQuery({
		queryKey: ["candidate", candidateId],
		queryFn: () => api(`/api/applicants/${candidateId}`)
	});
	const { data: offer } = useOffer(candidateId);
	const sendOffer = useSendOffer();
	const acceptOffer = useAcceptOffer();
	const declineOffer = useDeclineOffer();
	const handlePrint = () => {
		window.print();
	};
	const handleMarkSent = () => {
		if (!offer) return;
		sendOffer.mutate({ offerId: offer.id }, {
			onSuccess: () => toast.success("Offer sent successfully"),
			onError: (e) => toast.error(e.message)
		});
	};
	const handleMarkAccepted = () => {
		if (!offer) return;
		acceptOffer.mutate({ offerId: offer.id }, {
			onSuccess: () => toast.success("Offer accepted"),
			onError: (e) => toast.error(e.message)
		});
	};
	const handleMarkDeclined = () => {
		if (!offer) return;
		declineOffer.mutate({ offerId: offer.id }, {
			onSuccess: () => toast.success("Offer declined"),
			onError: (e) => toast.error(e.message)
		});
	};
	if (candidateLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-8 max-w-4xl mx-auto space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-48" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-8 space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-32" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-full" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-full" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-3/4" })
			]
		})]
	});
	if (!candidate || !offer) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6 lg:p-8 max-w-4xl mx-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-12 text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-12 w-12 text-muted-foreground/30 mx-auto mb-4" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-lg font-semibold",
					children: "No offer found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mt-1",
					children: "Please build an offer first before previewing."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/offer/builder/$candidateId",
						params: { candidateId },
						children: "Build Offer"
					})
				})
			]
		})
	});
	const formatDate = (dateStr) => {
		return new Date(dateStr).toLocaleDateString("en-IN", {
			day: "numeric",
			month: "long",
			year: "numeric"
		});
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-8 max-w-4xl mx-auto space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between no-print",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/offer/queue",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4 mr-1" }), " Back"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-2xl font-bold tracking-tight",
						children: "Offer Letter Preview"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted-foreground mt-1",
						children: "Review and send the offer letter."
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: handlePrint,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "h-4 w-4 mr-2" }), " Print"]
					}), offer.status === "DRAFT" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: handleMarkSent,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4 mr-2" }), " Mark as Sent"]
					})]
				})]
			}),
			offer.status !== "draft" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: `p-4 no-print ${offer.status === "ACCEPTED" ? "bg-emerald-50 border-emerald-200" : offer.status === "DECLINED" ? "bg-red-50 border-red-200" : "bg-blue-50 border-blue-200"}`,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [
						offer.status === "ACCEPTED" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-5 w-5 text-emerald-600" }) : offer.status === "DECLINED" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-5 w-5 text-red-600" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-5 w-5 text-blue-600" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-medium",
							children: offer.status === "ACCEPTED" ? "Offer Accepted" : offer.status === "DECLINED" ? "Offer Declined" : "Offer Sent"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-sm text-muted-foreground",
							children: offer.status === "ACCEPTED" ? `Accepted on ${offer.responded_at ? formatDate(offer.responded_at) : "—"}` : offer.status === "DECLINED" ? `Declined on ${offer.responded_at ? formatDate(offer.responded_at) : "—"}` : `Sent on ${offer.sent_at ? formatDate(offer.sent_at) : "—"}`
						})] }),
						offer.status === "SENT" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ml-auto flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: handleMarkAccepted,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-4 w-4 mr-1" }), " Accept"]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								size: "sm",
								variant: "outline",
								onClick: handleMarkDeclined,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-4 w-4 mr-1" }), " Decline"]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-8 print:shadow-none print:border-none",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-2xl mx-auto",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-center border-b pb-6 mb-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-center gap-3 mb-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/logo.png",
									alt: "Atlas Logo",
									className: "h-10 w-auto"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-left",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-xl tracking-tight",
										children: "Abhiyanta India Solutions"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: "ATLAS HR — Talent Acquisition"
									})]
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-between mb-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm text-muted-foreground",
								children: "Date:"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-medium",
								children: (/* @__PURE__ */ new Date()).toLocaleDateString("en-IN", {
									day: "numeric",
									month: "long",
									year: "numeric"
								})
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm text-muted-foreground",
									children: "Ref:"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium",
									children: candidate.application_number
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm font-medium",
									children: [
										candidate.first_name,
										" ",
										candidate.last_name
									]
								}),
								candidate.current_address && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm text-muted-foreground",
									children: candidate.current_address
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm text-muted-foreground",
									children: candidate.email
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm text-muted-foreground",
									children: candidate.phone
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mb-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-semibold uppercase tracking-wide",
								children: "Subject: Offer of Employment"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4 text-sm leading-relaxed",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"Dear ",
									candidate.first_name,
									","
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"We are pleased to extend this offer of employment for the position of",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: candidate.position_applied_for ?? "the advertised position" }),
									" at Abhiyanta India Solutions. We were impressed with your skills and experience, and believe you will be a valuable addition to our team."
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "border rounded-lg p-4 my-6 bg-muted/30",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-semibold mb-3",
										children: "Offer Details"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid grid-cols-2 gap-3 text-sm",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground",
													children: "Position:"
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: candidate.position_applied_for ?? "—" })
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground",
													children: "Domain:"
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: candidate.domain ?? "—" })
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground",
													children: "Offered CTC:"
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [
													"₹",
													offer.offered_ctc ?? "—",
													" LPA"
												] })
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground",
													children: "Joining Date:"
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: offer.joining_date ? formatDate(offer.joining_date) : "—" })
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground",
													children: "Employment Type:"
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: candidate.professional_details?.employment_type ?? "Full-time" })
											] }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-muted-foreground",
													children: "Approved By:"
												}),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: offer.approved_by ?? "—" })
											] })
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This offer is subject to the following terms and conditions:" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
									className: "list-decimal list-inside space-y-2 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your employment will commence on the joining date mentioned above, subject to successful completion of pre-employment verification." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Your compensation package includes the CTC mentioned above, which includes basic salary, allowances, and benefits as per company policy." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "You will be entitled to benefits including health insurance, paid time off, and other benefits as per company policy." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "You will be required to sign a confidentiality agreement and any other agreements required by company policy." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "This offer is contingent upon satisfactory background verification and submission of required documents." }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Either party may terminate the employment with appropriate notice as per company policy." })
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"Please confirm your acceptance of this offer by signing and returning this letter by",
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: new Date(Date.now() + 10080 * 60 * 1e3).toLocaleDateString("en-IN", {
										day: "numeric",
										month: "long",
										year: "numeric"
									}) }),
									"."
								] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We look forward to welcoming you to the team. If you have any questions, please don't hesitate to reach out." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6",
									children: "Warm regards,"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 pt-4 border-t",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium",
										children: offer.approved_by ?? "Authorised Signatory"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs text-muted-foreground",
										children: "Abhiyanta India Solutions"
									})]
								})
							]
						})
					]
				})
			}),
			offer.status === "SENT" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-4 no-print",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm text-muted-foreground",
						children: "Has the candidate responded?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: handleMarkAccepted,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-4 w-4 mr-1" }), " Accepted"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "outline",
							onClick: handleMarkDeclined,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-4 w-4 mr-1" }), " Declined"]
						})]
					})]
				})
			})
		]
	});
}
//#endregion
export { OfferPreview as component };
