globalThis.__nitro_main__ = import.meta.url;
import { a as toEventHandler, c as serve, i as defineLazyEventHandler, n as HTTPError, r as defineHandler, s as NodeResponse, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { i as withoutTrailingSlash, n as joinURL, r as withLeadingSlash, t as decodePath } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/logo.png": {
		"type": "image/png",
		"etag": "\"aa7a-0xSoynAJkSodolPrCjRiymEUTK4\"",
		"mtime": "2026-08-20T05:47:07.204Z",
		"size": 43642,
		"path": "../public/logo.png"
	},
	"/assets/AnimatePresence-BB5m5-XL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10bb-wU9VcPng05EMIoKDPrZlD+UvJB8\"",
		"mtime": "2026-08-22T10:59:13.841Z",
		"size": 4283,
		"path": "../public/assets/AnimatePresence-BB5m5-XL.js"
	},
	"/assets/arrow-right-CyuPCeks.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-1QnPQtL5UKAlnx3OyW4MIEAa5W0\"",
		"mtime": "2026-08-22T10:59:13.999Z",
		"size": 165,
		"path": "../public/assets/arrow-right-CyuPCeks.js"
	},
	"/assets/arrow-left-CPpVFeJX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a5-h/psI3uy71oBTl8Vq5JczH5b0nk\"",
		"mtime": "2026-08-22T10:59:13.994Z",
		"size": 165,
		"path": "../public/assets/arrow-left-CPpVFeJX.js"
	},
	"/assets/arrow-up-down-B32_xCXo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f5-TztAYD+BQZb1gL5mdI70qn/AL4c\"",
		"mtime": "2026-08-22T10:59:14.010Z",
		"size": 245,
		"path": "../public/assets/arrow-up-down-B32_xCXo.js"
	},
	"/assets/arrow-up-HlacCdT7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"112-vM8nSEOv+GXFjQWVQCeSJGR503M\"",
		"mtime": "2026-08-22T10:59:14.004Z",
		"size": 274,
		"path": "../public/assets/arrow-up-HlacCdT7.js"
	},
	"/assets/calendar-UpsXhG0C.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"101-RaQ9E6/ln9sDqKHGI2xJCqB+i2I\"",
		"mtime": "2026-08-22T10:59:14.023Z",
		"size": 257,
		"path": "../public/assets/calendar-UpsXhG0C.js"
	},
	"/assets/building-DbkVhoCU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"233-LRC8ijVBJM5qMRDijQxcJLabO9E\"",
		"mtime": "2026-08-22T10:59:14.021Z",
		"size": 563,
		"path": "../public/assets/building-DbkVhoCU.js"
	},
	"/assets/candidate-portal._candidateId-C3TmWiAb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2145-OJBmik2156Yy0TzDyTZFTgQeeHo\"",
		"mtime": "2026-08-22T10:59:14.028Z",
		"size": 8517,
		"path": "../public/assets/candidate-portal._candidateId-C3TmWiAb.js"
	},
	"/assets/card-BRC5zETd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"433-s+ooVofl9VMIPwiiL+Mh71n5+NI\"",
		"mtime": "2026-08-22T10:59:14.033Z",
		"size": 1075,
		"path": "../public/assets/card-BRC5zETd.js"
	},
	"/assets/badge-R8WvEM8g.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34c-m/jxT28opaCtlg60BUqf8vYlFrI\"",
		"mtime": "2026-08-22T10:59:14.014Z",
		"size": 844,
		"path": "../public/assets/badge-R8WvEM8g.js"
	},
	"/assets/chevron-right-B8rRkKve.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82-6YBFTjXW6mewvmkik9e56HdWHFw\"",
		"mtime": "2026-08-22T10:59:14.049Z",
		"size": 130,
		"path": "../public/assets/chevron-right-B8rRkKve.js"
	},
	"/assets/chevron-down-Dpcjx79R.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"80-GlYFbH6Q0nWG6qfO9zeZtUDAJJM\"",
		"mtime": "2026-08-22T10:59:14.040Z",
		"size": 128,
		"path": "../public/assets/chevron-down-Dpcjx79R.js"
	},
	"/assets/chevron-left-DVknXlPc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"82-CKNF+HIuicdw/pDvx3HQg2SjgD8\"",
		"mtime": "2026-08-22T10:59:14.044Z",
		"size": 130,
		"path": "../public/assets/chevron-left-DVknXlPc.js"
	},
	"/assets/briefcase-C7r-ypJM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"dc-XePPCuc0nSU3p80Fvcp7tvqzFi8\"",
		"mtime": "2026-08-22T10:59:14.017Z",
		"size": 220,
		"path": "../public/assets/briefcase-C7r-ypJM.js"
	},
	"/assets/circle-check-big-CduxdhAn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c2-J0uE/BmGnlzVmEyjGYW/WnDY0dU\"",
		"mtime": "2026-08-22T10:59:14.060Z",
		"size": 194,
		"path": "../public/assets/circle-check-big-CduxdhAn.js"
	},
	"/assets/circle-check-CvCZVo8U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b2-T0CQm3DdESv4kSjJdygXW6GSF2Y\"",
		"mtime": "2026-08-22T10:59:14.057Z",
		"size": 178,
		"path": "../public/assets/circle-check-CvCZVo8U.js"
	},
	"/assets/circle-alert-BBaM1Bnj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fa-9J9hJ/g35g4Q1mygWTcWrUv9PYo\"",
		"mtime": "2026-08-22T10:59:14.053Z",
		"size": 250,
		"path": "../public/assets/circle-alert-BBaM1Bnj.js"
	},
	"/assets/clock-qf84njfM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a9-LkPepdLMDl1Bdfzfljc8TWvsVoE\"",
		"mtime": "2026-08-22T10:59:14.079Z",
		"size": 169,
		"path": "../public/assets/clock-qf84njfM.js"
	},
	"/assets/circle-play-jgGhl-IL.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"100-tHhnGX2NAUk4GGV0YndAESdKGqE\"",
		"mtime": "2026-08-22T10:59:14.068Z",
		"size": 256,
		"path": "../public/assets/circle-play-jgGhl-IL.js"
	},
	"/assets/circle-x-A8LJwENZ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"cf-5Yu8/cJ4X2StbsX5VDDcLPYxdAo\"",
		"mtime": "2026-08-22T10:59:14.072Z",
		"size": 207,
		"path": "../public/assets/circle-x-A8LJwENZ.js"
	},
	"/assets/circle-pause-BgPu_ZZG.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f6-yU7dTIXQP7zmp1fiTgMKj7sSEeg\"",
		"mtime": "2026-08-22T10:59:14.064Z",
		"size": 246,
		"path": "../public/assets/circle-pause-BgPu_ZZG.js"
	},
	"/assets/clipboard-check-CW2-4Zt1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"130-t+pEVGySO+218EUEXvkZV6falSw\"",
		"mtime": "2026-08-22T10:59:14.076Z",
		"size": 304,
		"path": "../public/assets/clipboard-check-CW2-4Zt1.js"
	},
	"/assets/dist-CgpDlu_d.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bd-iFxzxA/uDLxSYb19hWIbDjGWvO0\"",
		"mtime": "2026-08-22T10:59:14.094Z",
		"size": 189,
		"path": "../public/assets/dist-CgpDlu_d.js"
	},
	"/assets/crown-CeBxryYt.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16a-i6Rpdjva8FUXaXW3NGhfBoPLztU\"",
		"mtime": "2026-08-22T10:59:14.087Z",
		"size": 362,
		"path": "../public/assets/crown-CeBxryYt.js"
	},
	"/assets/createLucideIcon-Dku9ohrO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4d7-JrZNkTdFwyHGUuwhE3hP+8oZPY4\"",
		"mtime": "2026-08-22T10:59:14.084Z",
		"size": 1239,
		"path": "../public/assets/createLucideIcon-Dku9ohrO.js"
	},
	"/assets/dialog-CI_iCI2L.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"84a-xKB2QSIrh1IXYQKlGMiLsU0pha8\"",
		"mtime": "2026-08-22T10:59:14.091Z",
		"size": 2122,
		"path": "../public/assets/dialog-CI_iCI2L.js"
	},
	"/assets/download-CRwij_be.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e8-nGSm5ZTJDNfSD+6HF1FomB93ka8\"",
		"mtime": "2026-08-22T10:59:14.109Z",
		"size": 232,
		"path": "../public/assets/download-CRwij_be.js"
	},
	"/assets/dist-DsTK1sfA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"286-MDTU5YlslIdNUL4Nmz7qXr3qwAY\"",
		"mtime": "2026-08-22T10:59:14.100Z",
		"size": 646,
		"path": "../public/assets/dist-DsTK1sfA.js"
	},
	"/assets/es2015-BAcWSZZF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"67db-qkZsni+RbPsxbr5U9C4W5D3RcLM\"",
		"mtime": "2026-08-22T10:59:14.112Z",
		"size": 26587,
		"path": "../public/assets/es2015-BAcWSZZF.js"
	},
	"/assets/dist-jh-pC5N7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"517-MKEGMO/Tu2AeMFMvqGT7PjeFOTU\"",
		"mtime": "2026-08-22T10:59:14.103Z",
		"size": 1303,
		"path": "../public/assets/dist-jh-pC5N7.js"
	},
	"/assets/dollar-sign-DOXYG9Li.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"db-1uIvawuftWQEN9HCmOmQUa3G9Vs\"",
		"mtime": "2026-08-22T10:59:14.106Z",
		"size": 219,
		"path": "../public/assets/dollar-sign-DOXYG9Li.js"
	},
	"/assets/gavel-B-xkZuXy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13c-IO8orkjC/IqLP7h0gPM5LyLIJnM\"",
		"mtime": "2026-08-22T10:59:14.124Z",
		"size": 316,
		"path": "../public/assets/gavel-B-xkZuXy.js"
	},
	"/assets/external-link-xDgeNPSR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"fb-KwFKrwAmFecuCqQVCgqmgYmkPXM\"",
		"mtime": "2026-08-22T10:59:14.117Z",
		"size": 251,
		"path": "../public/assets/external-link-xDgeNPSR.js"
	},
	"/assets/graduation-cap-D6mm9tEu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c-Q4ebgEb4BQHPS3Lo7fMIAjhNi+o\"",
		"mtime": "2026-08-22T10:59:14.128Z",
		"size": 332,
		"path": "../public/assets/graduation-cap-D6mm9tEu.js"
	},
	"/assets/html2canvas-CRV6Yc1K.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"30b8d-dRJIFW+YrHpaaQMj3RzlDNuvUiY\"",
		"mtime": "2026-08-22T10:59:14.136Z",
		"size": 199565,
		"path": "../public/assets/html2canvas-CRV6Yc1K.js"
	},
	"/assets/file-check-uoUR1bst.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"13e-34nlc6sjtVM+s0NY3TOdk03zeQ8\"",
		"mtime": "2026-08-22T10:59:14.119Z",
		"size": 318,
		"path": "../public/assets/file-check-uoUR1bst.js"
	},
	"/assets/hooks-DOUJz_mf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3d8-0nMZnju8ha+6tZxNS+P011eYWIU\"",
		"mtime": "2026-08-22T10:59:14.132Z",
		"size": 984,
		"path": "../public/assets/hooks-DOUJz_mf.js"
	},
	"/assets/index-x8XQAZy-.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4dad0-d5L3/91Dyk1rpzf/Pp2hVqCSBJk\"",
		"mtime": "2026-08-22T10:59:13.837Z",
		"size": 318160,
		"path": "../public/assets/index-x8XQAZy-.js"
	},
	"/assets/file-text-DW_bZC04.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"181-rmz7kEuu4se2UfNWX5b8Zd/5xw0\"",
		"mtime": "2026-08-22T10:59:14.122Z",
		"size": 385,
		"path": "../public/assets/file-text-DW_bZC04.js"
	},
	"/assets/jspdf.es.min-DOO7EjPr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6181c-yzco1T2/Bt39FoyTTYGYhnnY7kM\"",
		"mtime": "2026-08-22T10:59:14.153Z",
		"size": 399388,
		"path": "../public/assets/jspdf.es.min-DOO7EjPr.js"
	},
	"/assets/index.es-D9zTjRoy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24e86-kUwr1yX1p8ctzqIRNrXtLUfgles\"",
		"mtime": "2026-08-22T10:59:14.144Z",
		"size": 151174,
		"path": "../public/assets/index.es-D9zTjRoy.js"
	},
	"/assets/jsx-runtime-BHz_hoGM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1edb-yHkFp40Xr8eWRIQ4n1jjobd9u08\"",
		"mtime": "2026-08-22T10:59:14.157Z",
		"size": 7899,
		"path": "../public/assets/jsx-runtime-BHz_hoGM.js"
	},
	"/abhiyanta_about.png": {
		"type": "image/png",
		"etag": "\"314ff3-KWRVgpu3CqsexZfpoA9PR4khiFw\"",
		"mtime": "2026-08-22T06:56:24.397Z",
		"size": 3231731,
		"path": "../public/abhiyanta_about.png"
	},
	"/assets/laptop-M7BERZhb.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"130-8CVfZrOBxpn0ituXyf8bHS2L+4s\"",
		"mtime": "2026-08-22T10:59:14.164Z",
		"size": 304,
		"path": "../public/assets/laptop-M7BERZhb.js"
	},
	"/assets/label-DMynU3vy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2be-+pR1LJFX92/hQt1ASZ9E0zvrV5E\"",
		"mtime": "2026-08-22T10:59:14.160Z",
		"size": 702,
		"path": "../public/assets/label-DMynU3vy.js"
	},
	"/assets/inbox-B1Cp8Xfa.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"11e-j2diTMbBlPih4xfi3zvypIe0WJw\"",
		"mtime": "2026-08-22T10:59:14.140Z",
		"size": 286,
		"path": "../public/assets/inbox-B1Cp8Xfa.js"
	},
	"/assets/input-CF9GJUmM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"299-b07vjNs/FgOUUV/EvWiP8GdmugA\"",
		"mtime": "2026-08-22T10:59:14.149Z",
		"size": 665,
		"path": "../public/assets/input-CF9GJUmM.js"
	},
	"/assets/layout-dashboard-myHS8Af0.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"15f-Rsuc6NE0AHdbMglkSXAHBvsOw8E\"",
		"mtime": "2026-08-22T10:59:14.169Z",
		"size": 351,
		"path": "../public/assets/layout-dashboard-myHS8Af0.js"
	},
	"/assets/map-pin-aj-cXMGE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"103-QD53S6k0qX7UC+MvL90Xyqj1SHQ\"",
		"mtime": "2026-08-22T10:59:14.192Z",
		"size": 259,
		"path": "../public/assets/map-pin-aj-cXMGE.js"
	},
	"/assets/phone-DBFNibc3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"142-PDWzaZQVfMw81B3v0XGfktmS38Q\"",
		"mtime": "2026-08-22T10:59:14.197Z",
		"size": 322,
		"path": "../public/assets/phone-DBFNibc3.js"
	},
	"/assets/mail-D8xS4ALm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"d5-2339u4zxoTjgjmDwjBSy4V2E8Gc\"",
		"mtime": "2026-08-22T10:59:14.187Z",
		"size": 213,
		"path": "../public/assets/mail-D8xS4ALm.js"
	},
	"/assets/login-DQbO9TO6.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"201e-Tdr3gRh2XLDOAzc1BKDKk61azHw\"",
		"mtime": "2026-08-22T10:59:14.182Z",
		"size": 8222,
		"path": "../public/assets/login-DQbO9TO6.js"
	},
	"/assets/list-checks-CPEBz6Zi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"117-3Uucrch56FNLqSSJ5RePx9BCsRg\"",
		"mtime": "2026-08-22T10:59:14.178Z",
		"size": 279,
		"path": "../public/assets/list-checks-CPEBz6Zi.js"
	},
	"/assets/react-dom-BYiiqlYf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e06-U10Q8ZMqeCB85cagVfdWphfOFPo\"",
		"mtime": "2026-08-22T10:59:14.212Z",
		"size": 3590,
		"path": "../public/assets/react-dom-BYiiqlYf.js"
	},
	"/assets/purify.es-Bwt4ulIK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6a00-0LDmIFETtaeAWgn0JzNU4gyTehA\"",
		"mtime": "2026-08-22T10:59:14.207Z",
		"size": 27136,
		"path": "../public/assets/purify.es-Bwt4ulIK.js"
	},
	"/assets/link-CijhLZW4.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5b6e-bPRtzrYsZNHxqgdjQXAMhCsQ4Ws\"",
		"mtime": "2026-08-22T10:59:14.173Z",
		"size": 23406,
		"path": "../public/assets/link-CijhLZW4.js"
	},
	"/assets/save-BIH1nRYn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"147-WXeDyWDh97GVuMpuDsYg0I9zJhk\"",
		"mtime": "2026-08-22T10:59:14.224Z",
		"size": 327,
		"path": "../public/assets/save-BIH1nRYn.js"
	},
	"/assets/Match-Ch2UEn26.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"be2b-BrLGBKKrk853uD47Cj1xUxpbxBU\"",
		"mtime": "2026-08-22T10:59:13.845Z",
		"size": 48683,
		"path": "../public/assets/Match-Ch2UEn26.js"
	},
	"/assets/proxy-qVDlFJ9U.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d823-8U4d+eg3SgnYLR3ZR6rD7XrWs7o\"",
		"mtime": "2026-08-22T10:59:14.203Z",
		"size": 120867,
		"path": "../public/assets/proxy-qVDlFJ9U.js"
	},
	"/assets/rolldown-runtime-Bh1tDfsg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"237-RWMfWL++Hyx/oSoFmTJgBJkEveY\"",
		"mtime": "2026-08-22T10:59:14.219Z",
		"size": 567,
		"path": "../public/assets/rolldown-runtime-Bh1tDfsg.js"
	},
	"/assets/routes-DJk4gxCy.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"49a0-4nwWk7vsJD+Y1W5bPuY93Zf/BUw\"",
		"mtime": "2026-08-22T10:59:14.222Z",
		"size": 18848,
		"path": "../public/assets/routes-DJk4gxCy.js"
	},
	"/assets/scorecard-YJeC1y9O.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6d5-OwBCkoSewLTThztvyoiMz74vk88\"",
		"mtime": "2026-08-22T10:59:14.234Z",
		"size": 1749,
		"path": "../public/assets/scorecard-YJeC1y9O.js"
	},
	"/assets/register-candidate-C15-abJj.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b1548-VN02S/KKWrSH1R42+yOhRVhWdx4\"",
		"mtime": "2026-08-22T10:59:14.216Z",
		"size": 726344,
		"path": "../public/assets/register-candidate-C15-abJj.js"
	},
	"/assets/select-CoC66s71.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bfcd-Cc3AftgkVgslXzW4NWL82t8SwJ8\"",
		"mtime": "2026-08-22T10:59:14.242Z",
		"size": 49101,
		"path": "../public/assets/select-CoC66s71.js"
	},
	"/assets/scorecard-Bp2RjhUH.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"54c-rJIJVxBXVMI0a128Bb55vUdUeEw\"",
		"mtime": "2026-08-22T10:59:14.231Z",
		"size": 1356,
		"path": "../public/assets/scorecard-Bp2RjhUH.js"
	},
	"/assets/search-Dm14doRi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ae-BHSzGxP6rOKuyjGQAZy5X55QXms\"",
		"mtime": "2026-08-22T10:59:14.239Z",
		"size": 174,
		"path": "../public/assets/search-Dm14doRi.js"
	},
	"/assets/send-DHANv9AT.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"122-/ARRyv6Cejrwyb6zDwm9TCbhFH8\"",
		"mtime": "2026-08-22T10:59:14.247Z",
		"size": 290,
		"path": "../public/assets/send-DHANv9AT.js"
	},
	"/assets/shield-Dippm1XK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"110-C8BGGnmpIS6d9HPFWqnV6NTeQiI\"",
		"mtime": "2026-08-22T10:59:14.250Z",
		"size": 272,
		"path": "../public/assets/shield-Dippm1XK.js"
	},
	"/assets/star-QvD3ADdz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1d8-qDfZ1lb3Zyg5kW6ok+gtwGJkToc\"",
		"mtime": "2026-08-22T10:59:14.257Z",
		"size": 472,
		"path": "../public/assets/star-QvD3ADdz.js"
	},
	"/assets/textarea-CojIHEkg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"233-EU+OXxi7I4/o6hyV5QNGdVHx1Ik\"",
		"mtime": "2026-08-22T10:59:14.261Z",
		"size": 563,
		"path": "../public/assets/textarea-CojIHEkg.js"
	},
	"/assets/toPropertyKey-1ZER28ru.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"16f-bTN2FrvvbTiH5qmtg+QOxqTqibI\"",
		"mtime": "2026-08-22T10:59:14.264Z",
		"size": 367,
		"path": "../public/assets/toPropertyKey-1ZER28ru.js"
	},
	"/assets/trash-2-ClYE2gZU.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1ac-hZgW99Kew7oGBWC0GjnqjPSXmj8\"",
		"mtime": "2026-08-22T10:59:14.270Z",
		"size": 428,
		"path": "../public/assets/trash-2-ClYE2gZU.js"
	},
	"/assets/triangle-alert-CIYVyeSQ.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"104a-ICEhIGCi9UZE6ZwbxiYDe7D3I2I\"",
		"mtime": "2026-08-22T10:59:14.277Z",
		"size": 4170,
		"path": "../public/assets/triangle-alert-CIYVyeSQ.js"
	},
	"/assets/styles-CQdKnaKJ.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1c882-qlLTpuRpB0CsQpUy+IhyR8l8Ajs\"",
		"mtime": "2026-08-22T10:59:14.326Z",
		"size": 116866,
		"path": "../public/assets/styles-CQdKnaKJ.css"
	},
	"/assets/trending-up-DbMOp-dM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"af-C3/2b2qllvY27ioRZ4Zp7/+wvfc\"",
		"mtime": "2026-08-22T10:59:14.274Z",
		"size": 175,
		"path": "../public/assets/trending-up-DbMOp-dM.js"
	},
	"/assets/skeleton-CUXnEPUs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"df-uihZCDark9MXXNnJgybZ6aD4bVM\"",
		"mtime": "2026-08-22T10:59:14.253Z",
		"size": 223,
		"path": "../public/assets/skeleton-CUXnEPUs.js"
	},
	"/assets/useMatch-_xG0YN4k.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a8-TRFd/55ZI1iDEf/RZ46+N0sAxtg\"",
		"mtime": "2026-08-22T10:59:14.287Z",
		"size": 1192,
		"path": "../public/assets/useMatch-_xG0YN4k.js"
	},
	"/assets/user-C7M_r1VX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c4-Rze7piwbkdzOdguV9aFgkJNSzgg\"",
		"mtime": "2026-08-22T10:59:14.305Z",
		"size": 196,
		"path": "../public/assets/user-C7M_r1VX.js"
	},
	"/assets/useMutation-DC9oiduA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8f6-RofGNrpe3h1IQtZc+fcG6FJRzkY\"",
		"mtime": "2026-08-22T10:59:14.291Z",
		"size": 2294,
		"path": "../public/assets/useMutation-DC9oiduA.js"
	},
	"/assets/useQuery-BCFD6U90.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2287-m4T7kZKmuZ6AmauuMeKfXCruvSI\"",
		"mtime": "2026-08-22T10:59:14.297Z",
		"size": 8839,
		"path": "../public/assets/useQuery-BCFD6U90.js"
	},
	"/assets/user-check-OFHh_HoS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f3-vC+wga1CB5K1CTp61gbb5SCPF10\"",
		"mtime": "2026-08-22T10:59:14.308Z",
		"size": 243,
		"path": "../public/assets/user-check-OFHh_HoS.js"
	},
	"/assets/typeof-B5XbjTb1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"10f-yPXEOGyFHb1Ws7OoWyWNEEBz4mQ\"",
		"mtime": "2026-08-22T10:59:14.283Z",
		"size": 271,
		"path": "../public/assets/typeof-B5XbjTb1.js"
	},
	"/assets/utils-Cpyd4CBY.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6af9-emso3PfLh3E4iW7D+AtZv7+Ev+4\"",
		"mtime": "2026-08-22T10:59:14.320Z",
		"size": 27385,
		"path": "../public/assets/utils-Cpyd4CBY.js"
	},
	"/assets/useRouterState-Bax7vE7J.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c5-WpZr7vsDfDeLkyRPwTQRf1Kyx+0\"",
		"mtime": "2026-08-22T10:59:14.301Z",
		"size": 197,
		"path": "../public/assets/useRouterState-Bax7vE7J.js"
	},
	"/assets/user-plus-BsMtIRQ9.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"136-q/R6/qMrBOqOZ4PaQyMA2T4o9Y0\"",
		"mtime": "2026-08-22T10:59:14.312Z",
		"size": 310,
		"path": "../public/assets/user-plus-BsMtIRQ9.js"
	},
	"/assets/users-BY_mpPzo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"132-RkyuUOuEVa12jd9gYiQA/5tNh3Y\"",
		"mtime": "2026-08-22T10:59:14.317Z",
		"size": 306,
		"path": "../public/assets/users-BY_mpPzo.js"
	},
	"/assets/_authenticated-BdezOlaR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"6109-TQmhHVLS3v722SAmNwmkLR9catE\"",
		"mtime": "2026-08-22T10:59:13.850Z",
		"size": 24841,
		"path": "../public/assets/_authenticated-BdezOlaR.js"
	},
	"/assets/_authenticated.candidates._id-ChdlIMyS.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"88c5-R7v/P3d6mc6Y2YhaiSylFYEuldY\"",
		"mtime": "2026-08-22T10:59:13.859Z",
		"size": 35013,
		"path": "../public/assets/_authenticated.candidates._id-ChdlIMyS.js"
	},
	"/assets/_authenticated.ceo.evaluate._id-51fqiBI5.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"34fa-WFlmzXMC6KmpBGwV7F26obg5nGg\"",
		"mtime": "2026-08-22T10:59:13.863Z",
		"size": 13562,
		"path": "../public/assets/_authenticated.ceo.evaluate._id-51fqiBI5.js"
	},
	"/assets/x-Cx10Qgrm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"116a-z5OTCtmDh1MZWJ3Un48tOgttJLg\"",
		"mtime": "2026-08-22T10:59:14.323Z",
		"size": 4458,
		"path": "../public/assets/x-Cx10Qgrm.js"
	},
	"/assets/_authenticated.candidates-BkQLNqyR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"26af-bumnQf+uAoxGVxNTvICP/8rVPH0\"",
		"mtime": "2026-08-22T10:59:13.855Z",
		"size": 9903,
		"path": "../public/assets/_authenticated.candidates-BkQLNqyR.js"
	},
	"/assets/_authenticated.email-management-BqR15qHr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b0d-kh/n2r/bFfcEmf9RkY9lVEVj+8o\"",
		"mtime": "2026-08-22T10:59:13.877Z",
		"size": 6925,
		"path": "../public/assets/_authenticated.email-management-BqR15qHr.js"
	},
	"/assets/_authenticated.dashboard-D4Jlqaww.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4a2d-KRSzU+MIiEDb44FCcyWhAoxjPUc\"",
		"mtime": "2026-08-22T10:59:13.872Z",
		"size": 18989,
		"path": "../public/assets/_authenticated.dashboard-D4Jlqaww.js"
	},
	"/assets/_authenticated.final-discussion._id-pL2IZD75.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4680-U5IeYVKRNSkNBlN4XVu7M7mlOnY\"",
		"mtime": "2026-08-22T10:59:13.888Z",
		"size": 18048,
		"path": "../public/assets/_authenticated.final-discussion._id-pL2IZD75.js"
	},
	"/assets/_authenticated.final-decision._id-Bz5gC5A7.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b6c-zOb94X2f/m7uQThRs/pI7td6wys\"",
		"mtime": "2026-08-22T10:59:13.883Z",
		"size": 19308,
		"path": "../public/assets/_authenticated.final-decision._id-Bz5gC5A7.js"
	},
	"/assets/_authenticated.ceo.queue-S3TLHDFo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2555-KTCDIWQYZGfZPJt5Y4XD3BG2U4g\"",
		"mtime": "2026-08-22T10:59:13.868Z",
		"size": 9557,
		"path": "../public/assets/_authenticated.ceo.queue-S3TLHDFo.js"
	},
	"/assets/_authenticated.interviewer.evaluate._id-B111DLMf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"442f-D7Ng8y+zm+le+O69JJ1PfOR2nqA\"",
		"mtime": "2026-08-22T10:59:13.910Z",
		"size": 17455,
		"path": "../public/assets/_authenticated.interviewer.evaluate._id-B111DLMf.js"
	},
	"/assets/_authenticated.interviewer.queue-DHo8UCPB.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2298-QgEGZuDbUYNHkIodXTsSDVt2Vn8\"",
		"mtime": "2026-08-22T10:59:13.916Z",
		"size": 8856,
		"path": "../public/assets/_authenticated.interviewer.queue-DHo8UCPB.js"
	},
	"/assets/_authenticated.hr.review._id-CPbS0njx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"366e-PBDK3BhcaNvT5/BReRBtETNfqLA\"",
		"mtime": "2026-08-22T10:59:13.904Z",
		"size": 13934,
		"path": "../public/assets/_authenticated.hr.review._id-CPbS0njx.js"
	},
	"/assets/_authenticated.offer.builder._candidateId-BH_G1BMz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2f39-xJh4ZBxVxPmOeRtcUH1U7ZnFez0\"",
		"mtime": "2026-08-22T10:59:13.936Z",
		"size": 12089,
		"path": "../public/assets/_authenticated.offer.builder._candidateId-BH_G1BMz.js"
	},
	"/assets/_authenticated.interviewer.review._id-B5INLjPx.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"43fe-RjolnVyg0ONClLejOmG9QYMm9oQ\"",
		"mtime": "2026-08-22T10:59:13.923Z",
		"size": 17406,
		"path": "../public/assets/_authenticated.interviewer.review._id-B5INLjPx.js"
	},
	"/assets/_authenticated.offer.preview._candidateId-N-5UzgJc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2881-86EwuP5t2s5pxeGylDLNxj6j2Ys\"",
		"mtime": "2026-08-22T10:59:13.945Z",
		"size": 10369,
		"path": "../public/assets/_authenticated.offer.preview._candidateId-N-5UzgJc.js"
	},
	"/assets/_authenticated.hr.queue-DzYXrC07.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"32e6-+rxSsWeJwPZcRYAozeiWDpVqpXE\"",
		"mtime": "2026-08-22T10:59:13.897Z",
		"size": 13030,
		"path": "../public/assets/_authenticated.hr.queue-DzYXrC07.js"
	},
	"/assets/_authenticated.offer.dashboard-BsFy_K0j.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2105-Een/FtQfRFacXYbMc5b5TLTvpj8\"",
		"mtime": "2026-08-22T10:59:13.940Z",
		"size": 8453,
		"path": "../public/assets/_authenticated.offer.dashboard-BsFy_K0j.js"
	},
	"/assets/_authenticated.offer.queue-DClZTC0I.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b82-fPR3APhOUlGFQasupww2b07II7E\"",
		"mtime": "2026-08-22T10:59:13.950Z",
		"size": 7042,
		"path": "../public/assets/_authenticated.offer.queue-DClZTC0I.js"
	},
	"/assets/_authenticated.offer._candidateId-Gx2oGTbr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4ce8-fL6+xXlz55H4YC2E+GCqFDK8VkY\"",
		"mtime": "2026-08-22T10:59:13.930Z",
		"size": 19688,
		"path": "../public/assets/_authenticated.offer._candidateId-Gx2oGTbr.js"
	},
	"/assets/_authenticated.onboarding.queue-CjBO73vm.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1c95-Rigl4c407qFOTPNQAIkMBtqTTSc\"",
		"mtime": "2026-08-22T10:59:13.969Z",
		"size": 7317,
		"path": "../public/assets/_authenticated.onboarding.queue-CjBO73vm.js"
	},
	"/assets/_authenticated.onboarding.dashboard-tvnQH67_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1fee-JcVVh15enAkwoMAZxtPCMhAflZI\"",
		"mtime": "2026-08-22T10:59:13.965Z",
		"size": 8174,
		"path": "../public/assets/_authenticated.onboarding.dashboard-tvnQH67_.js"
	},
	"/assets/_authenticated.onboarding._candidateId-BjLagh4G.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5e2f-TJrzxQrAj349XfiYUms4ivH4WVI\"",
		"mtime": "2026-08-22T10:59:13.960Z",
		"size": 24111,
		"path": "../public/assets/_authenticated.onboarding._candidateId-BjLagh4G.js"
	},
	"/assets/_authenticated.offer.status._candidateId-BDA8ZgK_.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2cb1-u/NpXT9UtWwq9owksiicWD3b5i0\"",
		"mtime": "2026-08-22T10:59:13.956Z",
		"size": 11441,
		"path": "../public/assets/_authenticated.offer.status._candidateId-BDA8ZgK_.js"
	},
	"/assets/_authenticated.reports-dx2Ir9dA.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"109e-6MJB9iaoFTaU8Stme6DHpJrZZ3Q\"",
		"mtime": "2026-08-22T10:59:13.974Z",
		"size": 4254,
		"path": "../public/assets/_authenticated.reports-dx2Ir9dA.js"
	},
	"/assets/_authenticated.scheduler-C6_w2gFo.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b8b-ujsINGcdeNoKAifG3xZFmzb530A\"",
		"mtime": "2026-08-22T10:59:13.979Z",
		"size": 2955,
		"path": "../public/assets/_authenticated.scheduler-C6_w2gFo.js"
	},
	"/assets/_authenticated.settings-TqdSsWLh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1051-4mwVGpgzwgNe5xYfeHRWRvMBEdE\"",
		"mtime": "2026-08-22T10:59:13.984Z",
		"size": 4177,
		"path": "../public/assets/_authenticated.settings-TqdSsWLh.js"
	},
	"/assets/_authenticated.users-7UicAkjr.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2ed1-AltFXcQIfAnDMEq90axVUvfbZmo\"",
		"mtime": "2026-08-22T10:59:13.988Z",
		"size": 11985,
		"path": "../public/assets/_authenticated.users-7UicAkjr.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets-node
function readAsset(id) {
	const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
	return promises.readFile(resolve(serverDir, public_assets_data_default[id].path));
}
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
function getAsset(id) {
	return public_assets_data_default[id];
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/static.mjs
var METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
var EncodingMap = {
	gzip: ".gz",
	br: ".br",
	zstd: ".zst"
};
var static_default = defineHandler((event) => {
	if (event.req.method && !METHODS.has(event.req.method)) return;
	let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
	let asset;
	const encodings = [...(event.req.headers.get("accept-encoding") || "").split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
	for (const encoding of encodings) for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
		const _asset = getAsset(_id);
		if (_asset) {
			asset = _asset;
			id = _id;
			break;
		}
	}
	if (!asset) {
		if (isPublicAssetURL(id)) {
			event.res.headers.delete("Cache-Control");
			throw new HTTPError({ status: 404 });
		}
		return;
	}
	if (encodings.length > 1) event.res.headers.append("Vary", "Accept-Encoding");
	if (event.req.headers.get("if-none-match") === asset.etag) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	const ifModifiedSinceH = event.req.headers.get("if-modified-since");
	const mtimeDate = new Date(asset.mtime);
	if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
		event.res.status = 304;
		event.res.statusText = "Not Modified";
		return "";
	}
	if (asset.type) event.res.headers.set("Content-Type", asset.type);
	if (asset.etag && !event.res.headers.has("ETag")) event.res.headers.set("ETag", asset.etag);
	if (asset.mtime && !event.res.headers.has("Last-Modified")) event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
	if (asset.encoding && !event.res.headers.has("Content-Encoding")) event.res.headers.set("Content-Encoding", asset.encoding);
	if (asset.size > 0 && !event.res.headers.has("Content-Length")) event.res.headers.set("Content-Length", asset.size.toString());
	return readAsset(id);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_oAI3E7 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_oAI3E7
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
var globalMiddleware = [toEventHandler(static_default)].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~middleware"].push(...globalMiddleware);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		middleware.push(...h3App["~middleware"]);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/hooks.mjs
function _captureError(error, type) {
	console.error(`[${type}]`, error);
	useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
	process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
	process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
//#endregion
//#region #nitro/virtual/tracing
var tracingSrvxPlugins = [];
//#endregion
//#region node_modules/nitro/dist/presets/node/runtime/node-server.mjs
var _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
var port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
var host = process.env.NITRO_HOST || process.env.HOST;
var cert = process.env.NITRO_SSL_CERT;
var key = process.env.NITRO_SSL_KEY;
var nitroApp = useNitroApp();
serve({
	port,
	hostname: host,
	tls: cert && key ? {
		cert,
		key
	} : void 0,
	fetch: nitroApp.fetch,
	plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
var node_server_default = {};
//#endregion
export { node_server_default as default };
