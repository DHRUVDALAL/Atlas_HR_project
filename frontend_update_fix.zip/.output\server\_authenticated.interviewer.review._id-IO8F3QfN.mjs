import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.interviewer.review._id-IO8F3QfN.js
var $$splitComponentImporter = () => import("./_authenticated.interviewer.review._id-Jj_Tj8Y6.mjs");
var Route = createFileRoute("/_authenticated/interviewer/review/$id")({
	head: () => ({ meta: [{ title: "Candidate Review — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
