import { o as __toESM } from "./_runtime.mjs";
import { n as api, t as API_BASE_URL } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { n as useAuth } from "./_ssr/auth-Ba-lKRMp.mjs";
import { t as cn } from "./_ssr/utils-BjLc2HNT.mjs";
import { g as Link, v as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { $ as CircleX, B as FileText, D as MapPin, G as Download, I as GraduationCap, L as Gavel, W as ExternalLink, Y as Clock, Z as ClipboardCheck, bt as ArrowLeft, c as TriangleAlert, ht as Briefcase, i as User, ot as ChevronRight, pt as Calendar, rt as CircleCheckBig, s as UserCheck } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { i as statusMeta } from "./_ssr/scorecard-YpVMHDsm.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
import { t as Route } from "./_authenticated.candidates._id-DxqivG3D.mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, r as DialogDescription, t as Dialog } from "./_ssr/dialog-BymXEgns.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "./_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.candidates._id-IvNT0iIY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var TIMELINE_STEPS = [
	{
		status: "SUBMITTED",
		label: "Application Submitted",
		icon: FileText
	},
	{
		status: "Submitted — awaiting reception",
		label: "Application Submitted",
		icon: FileText
	},
	{
		status: "RECEPTION_FORWARDED",
		label: "Reception Check-In",
		icon: UserCheck
	},
	{
		status: "TECHNICAL_PENDING",
		label: "HR Review Complete",
		icon: ClipboardCheck
	},
	{
		status: "TECHNICAL_ROUND_2_PENDING",
		label: "Technical Round 1",
		icon: Briefcase
	},
	{
		status: "TECHNICAL_ROUND_3_PENDING",
		label: "Technical Round 2",
		icon: Briefcase
	},
	{
		status: "TECHNICAL_ROUND_4_PENDING",
		label: "Technical Round 3",
		icon: Briefcase
	},
	{
		status: "TECHNICAL_ROUND_5_PENDING",
		label: "Technical Round 4",
		icon: Briefcase
	},
	{
		status: "FINAL_DISCUSSION_PENDING",
		label: "Final Discussion",
		icon: Gavel
	},
	{
		status: "SELECTED",
		label: "Selected",
		icon: CircleCheckBig
	}
];
function getTimelineIndex(status) {
	if (status.startsWith("TECHNICAL_")) {
		const n = parseInt(status.split("_")[2], 10);
		if (n <= 1) return 2;
		if (n <= 2) return 3;
		if (n <= 3) return 4;
		return 4;
	}
	const idx = TIMELINE_STEPS.findIndex((s) => s.status === status);
	if (idx >= 0) return idx;
	if (status === "REJECTED") return 0;
	if (status === "ON_HOLD") return 6;
	return 0;
}
function CandidateDetailPage() {
	const { id } = Route.useParams();
	useNavigate();
	const { user, hasPermission } = useAuth();
	const qc = useQueryClient();
	const isReceptionist = hasPermission("workflow.reception_forward") && !hasPermission("workflow.hr_review");
	const [arriveDialogOpen, setArriveDialogOpen] = (0, import_react.useState)(false);
	const [rejectDialogOpen, setRejectDialogOpen] = (0, import_react.useState)(false);
	const [rejectReason, setRejectReason] = (0, import_react.useState)("");
	const { data, isLoading, error } = useQuery({
		queryKey: ["candidate", id],
		queryFn: () => api(`/api/applicants/${id}`).then((r) => r.data)
	});
	const forward = useMutation({
		mutationFn: () => api(`/api/workflow/receptionist/forward/${id}`, { method: "POST" }),
		onSuccess: () => {
			toast.success("Candidate arrived and forwarded to HR");
			qc.invalidateQueries({ queryKey: ["candidate", id] });
			qc.invalidateQueries({ queryKey: ["applicants"] });
			qc.invalidateQueries({ queryKey: ["dashboard-alerts"] });
			setArriveDialogOpen(false);
		},
		onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to forward candidate")
	});
	const reject = useMutation({
		mutationFn: () => api(`/api/workflow/receptionist/reject/${id}`, {
			method: "POST",
			body: { reason: rejectReason }
		}),
		onSuccess: () => {
			toast.success("Candidate rejected");
			qc.invalidateQueries({ queryKey: ["candidate", id] });
			qc.invalidateQueries({ queryKey: ["applicants"] });
			qc.invalidateQueries({ queryKey: ["dashboard-alerts"] });
			setRejectDialogOpen(false);
			setRejectReason("");
		},
		onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to reject candidate")
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-40 rounded-full" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-64" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-48" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-32" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid sm:grid-cols-2 gap-4",
				children: Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-24" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-5 w-40" })]
				}, i))
			})
		]
	});
	if (error || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6 lg:p-10 max-w-7xl mx-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white p-16 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-16 w-16 rounded-full bg-red-50 flex items-center justify-center mx-auto mb-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: "h-8 w-8 text-red-500" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-2xl font-bold text-[#1d1d1f]",
					children: "Candidate Not Found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-[#86868b] mt-2",
					children: "The candidate you are looking for does not exist or has been removed."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/candidates",
					className: "inline-flex items-center justify-center mt-8 px-6 py-3 rounded-full bg-[#1d1d1f] text-white text-sm font-bold hover:bg-black transition-all active:scale-[0.98]",
					children: "Back to Candidates"
				})
			]
		})
	});
	const s = statusMeta(data.status);
	const timelineIndex = getTimelineIndex(data.status);
	const isRejected = data.status === "REJECTED";
	const isHold = data.status === "ON_HOLD";
	const isPreArrival = [
		"SUBMITTED",
		"DRAFT",
		"Submitted — awaiting reception"
	].includes(data.status);
	const canShowReceptionActions = isReceptionist && isPreArrival;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/candidates",
					className: "flex items-center text-sm font-bold text-[#86868b] hover:text-[#1d1d1f] transition-colors",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center mr-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" })
					}), "Back to candidates"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-8 md:p-10 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4 flex-wrap mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
								children: [
									data.first_name,
									" ",
									data.last_name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-semibold tracking-wide ${s.className?.replace("bg-", "bg-opacity-20 text-").replace("text-white", "text-gray-800") || "bg-gray-100 text-gray-800"}`,
								children: s.label
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-medium text-[#86868b]",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-[#1d1d1f] bg-[#f5f5f7] px-2 py-0.5 rounded-md",
									children: data.application_number
								}),
								" ·",
								" ",
								data.position_applied_for ?? "—"
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-medium text-[#86868b] mt-1",
							children: [
								data.email,
								" · ",
								data.phone
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-3",
						children: [
							data.status === "RECEPTION_FORWARDED" && hasPermission("workflow.hr_review") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: `/hr/review/${id}`,
								className: "flex items-center bg-[#0066cc] hover:bg-[#005bb5] text-white rounded-full px-6 py-3 text-sm font-bold shadow-sm transition-all active:scale-[0.98]",
								children: "Start HR Review"
							}),
							data.status.startsWith("TECHNICAL_") && hasPermission("workflow.technical_evaluate") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: `/interviewer/evaluate/${id}`,
								className: "flex items-center bg-[#0066cc] hover:bg-[#005bb5] text-white rounded-full px-6 py-3 text-sm font-bold shadow-sm transition-all active:scale-[0.98]",
								children: "Submit Evaluation"
							}),
							data.status === "CEO_ROUND" && hasPermission("workflow.ceo_evaluate") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: `/ceo/evaluate/${id}`,
								className: "flex items-center bg-[#0066cc] hover:bg-[#005bb5] text-white rounded-full px-6 py-3 text-sm font-bold shadow-sm transition-all active:scale-[0.98]",
								children: "CEO Review"
							}),
							data.status === "FINAL_DISCUSSION_PENDING" && hasPermission("decision.final") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: `/final-decision/${id}`,
								className: "flex items-center bg-[#1d1d1f] hover:bg-black text-white rounded-full px-6 py-3 text-sm font-bold shadow-sm transition-all active:scale-[0.98]",
								children: "Final Decision"
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-1 lg:grid-cols-3 gap-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "lg:col-span-2 space-y-8",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
						defaultValue: "profile",
						className: "w-full",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, {
								className: "w-full flex overflow-x-auto bg-[#f5f5f7] rounded-2xl p-1 h-auto no-scrollbar justify-start mb-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "profile",
										className: "rounded-xl px-5 py-2.5 text-sm font-bold text-[#86868b] data-[state=active]:bg-white data-[state=active]:text-[#1d1d1f] data-[state=active]:shadow-sm transition-all",
										children: "Profile"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "professional",
										className: "rounded-xl px-5 py-2.5 text-sm font-bold text-[#86868b] data-[state=active]:bg-white data-[state=active]:text-[#1d1d1f] data-[state=active]:shadow-sm transition-all",
										children: "Professional"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "experience",
										className: "rounded-xl px-5 py-2.5 text-sm font-bold text-[#86868b] data-[state=active]:bg-white data-[state=active]:text-[#1d1d1f] data-[state=active]:shadow-sm transition-all",
										children: "Experience"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "education",
										className: "rounded-xl px-5 py-2.5 text-sm font-bold text-[#86868b] data-[state=active]:bg-white data-[state=active]:text-[#1d1d1f] data-[state=active]:shadow-sm transition-all",
										children: "Education"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "rounds",
										className: "rounded-xl px-5 py-2.5 text-sm font-bold text-[#86868b] data-[state=active]:bg-white data-[state=active]:text-[#1d1d1f] data-[state=active]:shadow-sm transition-all",
										children: [
											"Rounds (",
											data.interview_rounds?.length ?? 0,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsTrigger, {
										value: "documents",
										className: "rounded-xl px-5 py-2.5 text-sm font-bold text-[#86868b] data-[state=active]:bg-white data-[state=active]:text-[#1d1d1f] data-[state=active]:shadow-sm transition-all",
										children: [
											"Docs (",
											data.documents?.length ?? 0,
											")"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
										value: "timeline",
										className: "rounded-xl px-5 py-2.5 text-sm font-bold text-[#86868b] data-[state=active]:bg-white data-[state=active]:text-[#1d1d1f] data-[state=active]:shadow-sm transition-all",
										children: "Activity Log"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
								value: "profile",
								className: "outline-none",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-6",
										children: "Personal Information"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid sm:grid-cols-2 gap-x-8 gap-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Full Name",
												value: `${data.first_name} ${data.middle_name ?? ""} ${data.last_name}`.trim(),
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Email",
												value: data.email
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Phone",
												value: data.phone
											}),
											data.alternate_phone && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Alternate Phone",
												value: data.alternate_phone
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Gender",
												value: data.gender,
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Date of Birth",
												value: data.date_of_birth,
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Current Address",
												value: [
													data.current_address,
													data.city,
													data.state,
													data.pincode
												].filter(Boolean).join(", "),
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" })
											}),
											data.permanent_address && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Permanent Address",
												value: data.permanent_address,
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Country",
												value: data.country
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sm:col-span-2 h-px bg-gray-100 my-2" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Position Applied For",
												value: data.position_applied_for,
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" })
											}),
											data.applied_from && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Applied From",
												value: data.applied_from
											}),
											data.applied_from === "REFERRAL" && data.source_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Referred By",
												value: data.source_name
											}),
											data.applied_from === "VENDOR" && data.source_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Vendor Name",
												value: data.source_name
											}),
											data.reference_number && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Reference Number",
												value: data.reference_number
											})
										]
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsContent, {
								value: "professional",
								className: "outline-none",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-6",
										children: "Professional Details"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid sm:grid-cols-2 gap-x-8 gap-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Current Company",
												value: data.professional_details?.current_company,
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Current Designation",
												value: data.professional_details?.current_designation
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Total Experience",
												value: data.professional_details?.total_experience ? `${data.professional_details.total_experience} yrs` : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Relevant Experience",
												value: data.professional_details?.relevant_experience ? `${data.professional_details.relevant_experience} yrs` : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Current CTC",
												value: data.professional_details?.current_ctc ? `₹${data.professional_details.current_ctc} LPA` : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Expected CTC",
												value: data.professional_details?.expected_ctc ? `₹${data.professional_details.expected_ctc} LPA` : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Notice Period",
												value: data.professional_details?.notice_period
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Joining Availability",
												value: data.professional_details?.joining_availability
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Preferred Location",
												value: data.professional_details?.preferred_location
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												label: "Employment Type",
												value: data.professional_details?.employment_type
											})
										]
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
								value: "experience",
								className: "outline-none space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xl font-bold tracking-tight text-[#1d1d1f] pl-2",
									children: "Employment History"
								}), (data.employment_history ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-12 rounded-[2.5rem] border border-gray-100 text-center shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-10 w-10 text-gray-200 mx-auto mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#86868b]",
										children: "No employment history captured."
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-4",
									children: (data.employment_history ?? []).map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-col md:flex-row md:items-center justify-between gap-2 mb-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-lg font-bold text-[#1d1d1f]",
													children: [
														h.designation,
														" ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "text-[#86868b] font-medium mx-1",
															children: "at"
														}),
														" ",
														h.company_name
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "inline-flex items-center rounded-full bg-[#f5f5f7] px-3 py-1 text-xs font-bold text-[#86868b]",
													children: [
														h.start_date,
														" — ",
														h.end_date || "Present"
													]
												})]
											}),
											h.responsibilities && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-medium text-[#86868b] leading-relaxed mb-4",
												children: h.responsibilities
											}),
											h.reason_for_leaving && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#fbfbfd] p-4 rounded-2xl border border-gray-100",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs font-bold text-[#1d1d1f] uppercase tracking-wider mb-1",
													children: "Reason for Leaving"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-medium text-[#86868b]",
													children: h.reason_for_leaving
												})]
											})
										]
									}, i))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
								value: "education",
								className: "outline-none space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xl font-bold tracking-tight text-[#1d1d1f] pl-2",
									children: "Education"
								}), (data.education ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-12 rounded-[2.5rem] border border-gray-100 text-center shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "h-10 w-10 text-gray-200 mx-auto mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#86868b]",
										children: "No education captured."
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-4",
									children: (data.education ?? []).map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "bg-white p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid sm:grid-cols-2 gap-x-8 gap-y-6",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
													label: "Qualification",
													value: e.qualification,
													icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "h-4 w-4" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
													label: "Specialization",
													value: e.specialization
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
													label: "Institution",
													value: e.institution_name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
													label: "University",
													value: e.university
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
													label: "Passing Year",
													value: e.passing_year?.toString()
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
													label: "Score",
													value: e.percentage ? `${e.percentage}%` : e.grade
												})
											]
										})
									}, i))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
								value: "rounds",
								className: "outline-none space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xl font-bold tracking-tight text-[#1d1d1f] pl-2",
									children: "Interview Rounds"
								}), (data.interview_rounds ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-12 rounded-[2.5rem] border border-gray-100 text-center shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "h-10 w-10 text-gray-200 mx-auto mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#86868b]",
										children: "No rounds recorded yet."
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-4",
									children: (data.interview_rounds ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-6 border-b border-gray-100",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-lg font-bold text-[#1d1d1f] mb-1",
												children: [
													r.round_type.replace(/_/g, " "),
													" ",
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[#86868b] font-medium mx-1",
														children: "·"
													}),
													" Round ",
													r.round_number
												]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "text-sm font-medium text-[#86868b] flex items-center gap-2",
												children: [
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4" }),
													" ",
													r.interviewer_email
												]
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-col sm:items-end gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-bold tracking-wide ${r.status === "COMPLETED" ? "bg-emerald-50 text-emerald-700" : "bg-[#f5f5f7] text-[#1d1d1f]"}`,
													children: r.status
												}), r.completed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider",
													children: new Date(r.completed_at).toLocaleDateString()
												})]
											})]
										}), r.evaluation_data && Object.keys(r.evaluation_data).length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "grid sm:grid-cols-2 gap-6",
											children: Object.entries(r.evaluation_data).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#fbfbfd] p-5 rounded-2xl border border-gray-100",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex justify-between items-start gap-4 mb-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-sm font-bold text-[#1d1d1f]",
														children: k
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "inline-flex items-center justify-center h-8 w-8 rounded-full bg-white border border-gray-200 text-sm font-bold text-[#1d1d1f] shadow-sm shrink-0",
														children: v.rating
													})]
												}), v.remarks && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-medium text-[#86868b] leading-relaxed",
													children: v.remarks
												})]
											}, k))
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-medium text-[#86868b] text-center p-4 bg-[#fbfbfd] rounded-2xl border border-gray-50",
											children: "No evaluation data available yet."
										})]
									}, r.round_id))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
								value: "documents",
								className: "outline-none space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xl font-bold tracking-tight text-[#1d1d1f] pl-2",
									children: "Uploaded Documents"
								}), (data.documents ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-12 rounded-[2.5rem] border border-gray-100 text-center shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-10 w-10 text-gray-200 mx-auto mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#86868b]",
										children: "No documents uploaded."
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-4",
									children: (data.documents ?? []).map((d) => {
										const fileUrl = `${API_BASE_URL}${d.file_path.startsWith("/") ? "" : "/"}${d.file_path}`;
										const isPdf = d.file_name?.toLowerCase().endsWith(".pdf");
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center gap-4",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "h-12 w-12 rounded-2xl bg-blue-50 flex items-center justify-center shrink-0",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-6 w-6 text-blue-600" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "min-w-0 pr-4",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-sm font-bold text-[#1d1d1f] mb-0.5",
															children: d.document_type.replace(/_/g, " ")
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-xs font-medium text-[#86868b] truncate max-w-md",
															children: d.file_name
														})]
													})]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
														href: fileUrl,
														target: "_blank",
														rel: "noreferrer",
														className: "flex items-center justify-center h-10 w-10 rounded-full bg-white border border-gray-200 text-[#1d1d1f] hover:bg-gray-50 transition-colors shadow-sm",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-4 w-4" })
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
														href: fileUrl,
														download: d.file_name,
														className: "flex items-center justify-center h-10 w-10 rounded-full bg-[#f5f5f7] text-[#1d1d1f] hover:bg-[#e8e8ed] transition-colors",
														children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" })
													})]
												})]
											}), isPdf && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "mt-6 rounded-2xl border border-gray-100 overflow-hidden bg-[#f5f5f7]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
													src: fileUrl,
													className: "w-full h-[400px]",
													title: d.file_name
												})
											})]
										}, d.document_id);
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
								value: "timeline",
								className: "outline-none space-y-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-xl font-bold tracking-tight text-[#1d1d1f] pl-2",
									children: "Activity Log"
								}), (data.activity_logs ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-12 rounded-[2.5rem] border border-gray-100 text-center shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-10 w-10 text-gray-200 mx-auto mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#86868b]",
										children: "No activity recorded yet."
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-6",
										children: (data.activity_logs ?? []).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()).map((log, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex gap-4 relative",
											children: [
												i < (data.activity_logs?.length ?? 0) - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-2.5 top-6 bottom-[-24px] w-px bg-gray-100" }),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "h-5 w-5 rounded-full bg-blue-50 border-2 border-white shadow-sm flex items-center justify-center mt-1 relative z-10 shrink-0",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-2 w-2 rounded-full bg-[#0066cc]" })
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex-1 min-w-0 bg-[#fbfbfd] p-4 rounded-2xl border border-gray-50",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-sm font-bold text-[#1d1d1f]",
															children: log.action
														}),
														log.details && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
															className: "text-sm font-medium text-[#86868b] mt-1",
															children: log.details
														}),
														/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
															className: "text-xs font-bold text-[#1d1d1f]/40 uppercase tracking-wider mt-3 flex items-center gap-2",
															children: [
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: log.performed_by }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1 h-1 rounded-full bg-gray-300" }),
																/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: new Date(log.timestamp).toLocaleString() })
															]
														})
													]
												})
											]
										}, log.log_id ?? i))
									})
								})]
							})
						]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6",
					children: [canShowReceptionActions && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white p-8 rounded-[2.5rem] border-2 border-[#0066cc]/20 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-2",
								children: "Reception Actions"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-[#86868b] mb-6",
								children: "Process this candidate by marking them as arrived or rejecting their application."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setArriveDialogOpen(true),
									className: "w-full flex items-center justify-center bg-[#0066cc] text-white rounded-full px-6 py-3.5 text-sm font-bold shadow-sm transition-all active:scale-[0.98] hover:bg-[#005bb5]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-4 w-4 mr-2" }), " Mark as Arrived"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setRejectDialogOpen(true),
									className: "w-full flex items-center justify-center bg-red-50 text-red-600 rounded-full px-6 py-3.5 text-sm font-bold transition-all active:scale-[0.98] hover:bg-red-100",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-4 w-4 mr-2" }), " Reject Candidate"]
								})]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] sticky top-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-8",
							children: "Application Progress"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [
								TIMELINE_STEPS.map((step, i) => {
									const Icon = step.icon;
									const isCurrentStep = i === timelineIndex && !isRejected;
									const isCompleted = i < timelineIndex || isRejected && i === 0;
									const isPending = i > timelineIndex && !isRejected;
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex gap-4 relative",
										children: [
											i < TIMELINE_STEPS.length - 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `absolute left-[15px] top-[32px] w-[2px] h-[calc(100%-16px)] rounded-full ${isCompleted ? "bg-[#1d1d1f]" : "bg-gray-100"}` }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: `relative z-10 h-8 w-8 rounded-full flex items-center justify-center shrink-0 transition-colors duration-300 ${isCurrentStep ? "bg-[#1d1d1f] text-white ring-4 ring-black/5" : isCompleted ? "bg-[#1d1d1f] text-white" : "bg-gray-100 text-[#86868b]"}`,
												children: isCompleted && !isCurrentStep ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: `pb-8 pt-1 transition-opacity duration-300 ${isPending ? "opacity-50" : "opacity-100"}`,
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: `text-sm font-bold ${isCurrentStep || isCompleted ? "text-[#1d1d1f]" : "text-[#86868b]"}`,
													children: step.label
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs font-bold tracking-wide uppercase mt-1 text-[#86868b]",
													children: isCompleted || isCurrentStep ? "Completed" : "Pending"
												})]
											})
										]
									}, `${step.status}-${i}`);
								}),
								isRejected && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-4 relative mt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "relative z-10 h-8 w-8 rounded-full flex items-center justify-center shrink-0 bg-red-500 text-white shadow-md shadow-red-500/20",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-4 w-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-bold text-red-500",
											children: "Rejected"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs font-medium text-[#86868b] mt-1",
											children: "Candidate was rejected"
										})]
									})]
								}),
								isHold && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex gap-4 relative mt-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "relative z-10 h-8 w-8 rounded-full flex items-center justify-center shrink-0 bg-amber-500 text-white shadow-md shadow-amber-500/20",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "pt-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-sm font-bold text-amber-500",
											children: "On Hold"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "text-xs font-medium text-[#86868b] mt-1",
											children: "Candidate is on hold"
										})]
									})]
								})
							]
						})]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: arriveDialogOpen,
				onOpenChange: setArriveDialogOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md sm:rounded-[2.5rem] p-8 border-none shadow-[0_20px_60px_rgb(0,0,0,0.12)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
							className: "mb-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-12 w-12 rounded-2xl bg-[#0066cc]/10 flex items-center justify-center mb-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-6 w-6 text-[#0066cc]" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
									className: "text-2xl font-bold tracking-tighter text-[#1d1d1f]",
									children: "Confirm Candidate Arrival"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
									className: "text-sm font-medium text-[#86868b] mt-2",
									children: "This will mark the candidate as arrived and forward them to the HR review queue."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-[#fbfbfd] p-5 rounded-2xl border border-gray-100 space-y-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm border-b border-gray-100 pb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-[#86868b]",
										children: "Candidate"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-bold text-[#1d1d1f]",
										children: [
											data.first_name,
											" ",
											data.last_name
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm border-b border-gray-100 pb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-[#86868b]",
										children: "Application"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-[#1d1d1f] bg-white px-2 py-0.5 rounded border border-gray-100 shadow-sm",
										children: data.application_number
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm border-b border-gray-100 pb-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-[#86868b]",
										children: "Email"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-[#1d1d1f] truncate pl-4 max-w-[200px]",
										children: data.email
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-[#86868b]",
										children: "Position"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium text-[#1d1d1f] text-right",
										children: data.position_applied_for ?? "—"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end gap-3 mt-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => setArriveDialogOpen(false),
								className: "px-6 py-3 rounded-full bg-white text-[#1d1d1f] border border-gray-200 text-sm font-bold hover:bg-gray-50 transition-colors",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								onClick: () => forward.mutate(),
								disabled: forward.isPending,
								className: "px-6 py-3 rounded-full bg-[#0066cc] text-white text-sm font-bold hover:bg-[#005bb5] transition-colors disabled:opacity-50 flex items-center",
								children: [forward.isPending ? "Processing..." : "Confirm Arrival", !forward.isPending && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4 ml-1" })]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
				open: rejectDialogOpen,
				onOpenChange: setRejectDialogOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
					className: "max-w-md sm:rounded-[2.5rem] p-8 border-none shadow-[0_20px_60px_rgb(0,0,0,0.12)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, {
							className: "mb-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-12 w-12 rounded-2xl bg-red-50 flex items-center justify-center mb-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-6 w-6 text-red-500" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
									className: "text-2xl font-bold tracking-tighter text-[#1d1d1f]",
									children: "Reject Candidate"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
									className: "text-sm font-medium text-[#86868b] mt-2",
									children: "This will reject the candidate and remove them from the recruitment pipeline. This action cannot be undone."
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-[#fbfbfd] p-4 rounded-2xl border border-gray-100 space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-[#86868b]",
										children: "Candidate"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "font-bold text-[#1d1d1f]",
										children: [
											data.first_name,
											" ",
											data.last_name
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex justify-between items-center text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-[#86868b]",
										children: "Application"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold text-[#1d1d1f] bg-white px-2 py-0.5 rounded border border-gray-100 shadow-sm",
										children: data.application_number
									})]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-xs font-bold text-[#86868b] uppercase tracking-wide ml-1",
									children: "Reason for Rejection *"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-red-500 focus:ring-4 focus:ring-red-500/10 rounded-2xl p-4 text-sm text-[#1d1d1f] transition-all outline-none resize-none min-h-[120px]",
									placeholder: "Please provide a clear reason for rejecting this candidate...",
									value: rejectReason,
									onChange: (e) => setRejectReason(e.target.value)
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex justify-end gap-3 mt-8",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => {
									setRejectDialogOpen(false);
									setRejectReason("");
								},
								className: "px-6 py-3 rounded-full bg-white text-[#1d1d1f] border border-gray-200 text-sm font-bold hover:bg-gray-50 transition-colors",
								children: "Cancel"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								onClick: () => reject.mutate(),
								disabled: reject.isPending || rejectReason.trim().length < 3,
								className: "px-6 py-3 rounded-full bg-red-500 text-white text-sm font-bold hover:bg-red-600 transition-colors disabled:opacity-50",
								children: reject.isPending ? "Rejecting..." : "Reject Candidate"
							})]
						})
					]
				})
			})
		]
	});
}
function Field({ label, value, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-[11px] font-bold uppercase tracking-wider text-[#86868b] flex items-center gap-1.5 mb-1",
		children: [icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "opacity-70",
			children: icon
		}), label]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "text-sm font-medium text-[#1d1d1f] break-words",
		children: value ?? "—"
	})] });
}
//#endregion
export { CandidateDetailPage as component };
