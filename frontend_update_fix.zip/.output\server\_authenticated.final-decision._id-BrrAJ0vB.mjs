import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.final-decision._id-BrrAJ0vB.js
var $$splitComponentImporter = () => import("./_authenticated.final-decision._id-C12YDlbo.mjs");
var Route = createFileRoute("/_authenticated/final-decision/$id")({
	head: () => ({ meta: [{ title: "Final Decision — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
