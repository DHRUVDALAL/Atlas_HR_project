import { o as __toESM } from "../_runtime.mjs";
import { a as getRefreshToken, i as getAccessToken, n as api, o as setStoredUser, r as clearAuth, s as setTokens } from "./api-85Rra_o2.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/auth-Ba-lKRMp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var AuthContext = (0, import_react.createContext)(null);
function AuthProvider({ children }) {
	const [user, setUser] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const logout = (0, import_react.useCallback)(() => {
		const refresh_token = getRefreshToken();
		if (refresh_token) api("/api/auth/logout", {
			method: "POST",
			body: { refresh_token },
			auth: false
		}).catch((e) => console.error("Error during API logout:", e));
		clearAuth();
		setUser(null);
	}, []);
	(0, import_react.useEffect)(() => {
		const restoreSession = async () => {
			if (getAccessToken()) try {
				const res = await api("/api/auth/me");
				if (res.success && res.user) {
					const authUser = {
						user_id: res.user.user_id,
						email: res.user.email,
						first_name: res.user.first_name,
						last_name: res.user.last_name,
						roles: [res.user.role],
						permissions: res.permissions || []
					};
					setStoredUser(authUser);
					setUser(authUser);
				} else logout();
			} catch (error) {
				console.error("Failed to restore session:", error);
				logout();
			}
			setLoading(false);
		};
		restoreSession();
	}, [logout]);
	const login = (0, import_react.useCallback)(async (email, password) => {
		const res = await api("/api/auth/login", {
			method: "POST",
			body: {
				email,
				password
			},
			auth: false
		});
		if (!res.success) throw new Error(res.message || "Invalid credentials");
		setTokens(res.token, res.refresh_token);
		const meRes = await api("/api/auth/me");
		const authUser = {
			user_id: meRes.user.user_id,
			email: meRes.user.email,
			first_name: meRes.user.first_name,
			last_name: meRes.user.last_name,
			roles: [meRes.user.role],
			permissions: meRes.permissions || []
		};
		setStoredUser(authUser);
		setUser(authUser);
		return authUser;
	}, []);
	const hasRole = (0, import_react.useCallback)((role) => !!user?.roles?.includes(role), [user]);
	const hasAnyRole = (0, import_react.useCallback)((roles) => !!user?.roles?.some((r) => roles.includes(r)), [user]);
	const hasPermission = (0, import_react.useCallback)((perm) => !!user?.permissions?.includes(perm) || !!user?.permissions?.includes("*"), [user]);
	const hasAnyPermission = (0, import_react.useCallback)((perms) => !!user?.permissions?.includes("*") || !!user?.permissions?.some((p) => perms.includes(p)), [user]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthContext.Provider, {
		value: {
			user,
			isAuthenticated: !!user,
			loading,
			login,
			logout,
			hasRole,
			hasAnyRole,
			hasPermission,
			hasAnyPermission
		},
		children
	});
}
function useAuth() {
	const ctx = (0, import_react.useContext)(AuthContext);
	if (!ctx) throw new Error("useAuth must be used within <AuthProvider>");
	return ctx;
}
//#endregion
export { useAuth as n, AuthProvider as t };
