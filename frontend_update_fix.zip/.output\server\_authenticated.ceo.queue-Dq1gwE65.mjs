import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { L as Gavel, Y as Clock, q as Crown, rt as CircleCheckBig, vt as ArrowUpDown, y as Search, yt as ArrowRight } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { i as statusMeta } from "./_ssr/scorecard-YpVMHDsm.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.ceo.queue-Dq1gwE65.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CeoQueue() {
	const [search, setSearch] = (0, import_react.useState)("");
	const [view, setView] = (0, import_react.useState)("ceo");
	const [sortOrder, setSortOrder] = (0, import_react.useState)("asc");
	const { data, isLoading } = useQuery({
		queryKey: [
			"applicants",
			"ceo-queue",
			view,
			search,
			sortOrder
		],
		queryFn: () => api("/api/applicants?limit=500").then((r) => {
			let list = r.applicants ?? [];
			const targetStatus = view === "ceo" ? "CEO_ROUND" : "FINAL_DISCUSSION_PENDING";
			list = list.filter((c) => c.status === targetStatus);
			if (search) {
				const q = search.toLowerCase();
				list = list.filter((c) => c.first_name.toLowerCase().includes(q) || c.last_name.toLowerCase().includes(q) || c.application_number.toLowerCase().includes(q) || c.position_applied_for?.toLowerCase().includes(q));
			}
			list.sort((a, b) => {
				const da = new Date(a.created_at).getTime();
				const db = new Date(b.created_at).getTime();
				return sortOrder === "asc" ? da - db : db - da;
			});
			return list;
		})
	});
	isLoading || (data ?? []).length;
	const { data: allData } = useQuery({
		queryKey: ["applicants", "all"],
		queryFn: () => api("/api/applicants?limit=500").then((r) => r.applicants ?? [])
	});
	const allList = allData ?? [];
	const totalCeo = allList.filter((c) => c.status === "CEO_ROUND").length;
	const totalFinal = allList.filter((c) => c.status === "FINAL_DISCUSSION_PENDING").length;
	const totalSelected = allList.filter((c) => c.status === "SELECTED").length;
	const totalRejected = allList.filter((c) => c.status === "REJECTED").length;
	const candidates = data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-3xl font-bold tracking-tighter text-[#1d1d1f] flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-8 w-8 text-indigo-600" }), "CEO Review Queue"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-[#86868b] mt-1 ml-11",
				children: "Candidates awaiting executive evaluation or final discussion."
			})] }),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-20 mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-12 mb-2" })]
				}, i))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "CEO Pending"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: totalCeo
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-indigo-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-5 w-5 text-indigo-600" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "Final Discussion"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: totalFinal
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-amber-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gavel, { className: "h-5 w-5 text-amber-600" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "Selected"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: totalSelected
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-green-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-5 w-5 text-green-600" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "Rejected"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: totalRejected
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-red-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-5 w-5 text-red-600" })
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-4 md:p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col sm:flex-row gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1 bg-[#f5f5f7] p-1.5 rounded-[1.25rem]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setView("ceo"),
							className: `flex-1 flex items-center justify-center px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${view === "ceo" ? "bg-white text-[#1d1d1f] shadow-sm" : "text-[#86868b] hover:text-[#1d1d1f]"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-4 w-4 mr-2" }),
								" CEO Reviews (",
								totalCeo,
								")"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							onClick: () => setView("final"),
							className: `flex-1 flex items-center justify-center px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${view === "final" ? "bg-white text-[#1d1d1f] shadow-sm" : "text-[#86868b] hover:text-[#1d1d1f]"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gavel, { className: "h-4 w-4 mr-2" }),
								" Final Decisions (",
								totalFinal,
								")"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-[#86868b]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							placeholder: "Search candidates…",
							className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl pl-11 pr-5 py-3 text-sm text-[#1d1d1f] placeholder:text-[#86868b] transition-all outline-none",
							value: search,
							onChange: (e) => setSearch(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "h-11 px-5 flex items-center justify-center bg-transparent hover:bg-gray-50 text-[#86868b] border border-gray-200 rounded-2xl text-sm font-medium transition-colors whitespace-nowrap",
						onClick: () => setSortOrder(sortOrder === "asc" ? "desc" : "asc"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpDown, { className: "h-4 w-4 mr-2" }), sortOrder === "asc" ? "Oldest first" : "Newest first"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white rounded-[2rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-6 px-8 py-6 border-b border-gray-50/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-10 rounded-full" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-60" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-24 rounded-full" })
						]
					}, i))
				}) : candidates.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-16 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-lg font-bold text-[#1d1d1f]",
						children: "No candidates"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-[#86868b] mt-1",
						children: view === "ceo" ? "No candidates awaiting CEO evaluation." : "No candidates in final discussion."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: candidates.map((c) => {
						const s = statusMeta(c.status);
						const actionHref = view === "ceo" ? `/ceo/evaluate/${c.candidate_id}` : `/final-decision/${c.candidate_id}`;
						const actionLabel = view === "ceo" ? "Evaluate" : "Decide";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[auto_1fr_auto_auto] gap-6 px-6 md:px-8 py-5 border-b border-gray-50/50 hover:bg-[#f5f5f7]/60 transition-colors items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "h-10 w-10 rounded-full bg-[#f5f5f7] grid place-items-center text-[#1d1d1f] font-bold text-xs",
									children: [c.first_name[0], c.last_name[0]]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 pr-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-sm font-bold text-[#1d1d1f] truncate",
										children: [
											c.first_name,
											" ",
											c.last_name
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
										children: [
											c.application_number,
											" · ",
											c.position_applied_for ?? "—",
											" · ",
											c.email
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-semibold tracking-wide ${s.className}`,
									children: s.label
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-end w-28",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: actionHref,
										className: `flex items-center ${view === "ceo" ? "bg-[#0066cc] hover:bg-[#005bb5]" : "bg-[#1d1d1f] hover:bg-black"} text-white rounded-full px-5 py-2 text-xs font-bold transition-all shadow-sm active:scale-[0.98]`,
										children: [
											actionLabel,
											" ",
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 ml-1.5" })
										]
									})
								})
							]
						}, c.candidate_id);
					})
				})
			})
		]
	});
}
//#endregion
export { CeoQueue as component };
