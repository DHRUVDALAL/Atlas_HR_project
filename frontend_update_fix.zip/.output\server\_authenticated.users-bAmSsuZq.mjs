import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { C as Plus, T as Pen, d as Trash2, y as Search } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-CAzbakW8.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
import { a as DialogTitle, i as DialogHeader, n as DialogContent, t as Dialog } from "./_ssr/dialog-BymXEgns.mjs";
import { t as Label } from "./_ssr/label-BgXw8JJ9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.users-bAmSsuZq.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UsersPage() {
	const qc = useQueryClient();
	const [search, setSearch] = (0, import_react.useState)("");
	const [isCreateModalOpen, setIsCreateModalOpen] = (0, import_react.useState)(false);
	const [editUser, setEditUser] = (0, import_react.useState)(null);
	const { data: users, isLoading } = useQuery({
		queryKey: ["users"],
		queryFn: () => api("/api/users?limit=200").then((r) => r ?? [])
	});
	const { data: roles } = useQuery({
		queryKey: ["roles"],
		queryFn: () => api("/api/roles").then((r) => r ?? [])
	});
	const deleteMutation = useMutation({
		mutationFn: (userId) => api(`/api/users/${userId}`, { method: "DELETE" }),
		onSuccess: () => {
			toast.success("User deleted successfully.");
			qc.invalidateQueries({ queryKey: ["users"] });
		},
		onError: (e) => toast.error(e.message || "Failed to delete user.")
	});
	const filteredUsers = (users || []).filter((u) => `${u.first_name} ${u.last_name} ${u.email} ${u.employee_code}`.toLowerCase().includes(search.toLowerCase()));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
					children: "Employee Management"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-[#86868b] mt-1",
					children: "Manage system users, roles, and access."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => setIsCreateModalOpen(true),
					className: "flex items-center bg-[#1d1d1f] hover:bg-black text-white rounded-full px-6 py-2.5 text-sm font-bold shadow-sm transition-all active:scale-[0.98]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "h-4 w-4 mr-2" }), " Add Employee"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-4 md:p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1 w-full max-w-2xl mx-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-[#86868b]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl pl-11 pr-5 py-3 text-sm text-[#1d1d1f] placeholder:text-[#86868b] transition-all outline-none",
						placeholder: "Search by name, email, or ID...",
						value: search,
						onChange: (e) => setSearch(e.target.value)
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white rounded-[2.5rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-6 px-8 py-6 border-b border-gray-50/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-10 rounded-full" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-60" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-24 rounded-full" })
						]
					}, i))
				}) : filteredUsers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-16 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-12 w-12 rounded-full bg-[#f5f5f7] flex items-center justify-center mx-auto mb-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "h-5 w-5 text-[#86868b]" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-lg font-bold text-[#1d1d1f]",
							children: "No employees found"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-[#86868b] mt-1",
							children: "Try adjusting your search terms or add a new employee."
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: filteredUsers.map((u) => {
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[auto_1fr_auto_auto_auto] gap-6 px-6 md:px-8 py-5 border-b border-gray-50/50 hover:bg-[#f5f5f7]/60 transition-colors items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "h-10 w-10 rounded-full bg-[#f5f5f7] grid place-items-center text-[#1d1d1f] font-bold text-xs",
									children: [u.first_name?.[0]?.toUpperCase(), u.last_name?.[0]?.toUpperCase()]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 pr-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-sm font-bold text-[#1d1d1f] truncate",
										children: [
											u.first_name,
											" ",
											u.last_name
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
										children: [
											u.email,
											" • ",
											u.employee_code
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hidden sm:block",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "inline-flex items-center justify-center rounded-full bg-gray-100 px-3 py-1 text-[11px] font-bold text-gray-700 tracking-wide",
										children: u.role?.role_name || "Unknown"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-[11px] font-bold tracking-wide ${u.is_active ? "bg-emerald-50 text-emerald-700" : "bg-red-50 text-red-700"}`,
										children: u.is_active ? "Active" : "Inactive"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-end gap-2 w-20",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => setEditUser(u),
										className: "h-9 w-9 flex items-center justify-center rounded-full border border-transparent text-[#86868b] hover:bg-gray-100 hover:text-[#1d1d1f] transition-all",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pen, { className: "h-4 w-4" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										onClick: () => {
											if (confirm(`Are you sure you want to delete ${u.first_name}?`)) deleteMutation.mutate(u.user_id);
										},
										className: "h-9 w-9 flex items-center justify-center rounded-full border border-transparent text-red-500 hover:bg-red-50 transition-all",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "h-4 w-4" })
									})]
								})
							]
						}, u.user_id);
					})
				})
			}),
			isCreateModalOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserModal, {
				roles: roles || [],
				onClose: () => setIsCreateModalOpen(false),
				onSuccess: () => {
					setIsCreateModalOpen(false);
					qc.invalidateQueries({ queryKey: ["users"] });
				}
			}),
			editUser && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserModal, {
				user: editUser,
				roles: roles || [],
				onClose: () => setEditUser(null),
				onSuccess: () => {
					setEditUser(null);
					qc.invalidateQueries({ queryKey: ["users"] });
				}
			})
		]
	});
}
function UserModal({ user, roles, onClose, onSuccess }) {
	const isEdit = !!user;
	const [formData, setFormData] = (0, import_react.useState)({
		first_name: user?.first_name || "",
		last_name: user?.last_name || "",
		email: user?.email || "",
		employee_code: user?.employee_code || "",
		role_id: user?.role_id || "",
		department: user?.department || "",
		password: "",
		is_active: user ? user.is_active : true
	});
	const saveMutation = useMutation({
		mutationFn: async () => {
			if (isEdit) {
				const payload = { ...formData };
				if (!payload.password) delete payload.password;
				return api(`/api/users/${user.user_id}`, {
					method: "PUT",
					body: payload
				});
			} else return api("/api/users", {
				method: "POST",
				body: formData
			});
		},
		onSuccess: () => {
			toast.success(isEdit ? "User updated" : "User created");
			onSuccess();
		},
		onError: (e) => toast.error(e.message || "Operation failed")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: true,
		onOpenChange: (open) => !open && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-w-md sm:rounded-[2.5rem] p-8 border-none shadow-[0_20px_60px_rgb(0,0,0,0.12)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, {
					className: "mb-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
						className: "text-2xl font-bold tracking-tighter text-[#1d1d1f]",
						children: isEdit ? "Edit Employee" : "Add Employee"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-[#86868b] uppercase tracking-wide",
									children: "First Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl px-4 py-3 text-sm text-[#1d1d1f] transition-all outline-none",
									value: formData.first_name,
									onChange: (e) => setFormData({
										...formData,
										first_name: e.target.value
									})
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-[#86868b] uppercase tracking-wide",
									children: "Last Name"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl px-4 py-3 text-sm text-[#1d1d1f] transition-all outline-none",
									value: formData.last_name,
									onChange: (e) => setFormData({
										...formData,
										last_name: e.target.value
									})
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-[#86868b] uppercase tracking-wide",
								children: "Email"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl px-4 py-3 text-sm text-[#1d1d1f] transition-all outline-none",
								value: formData.email,
								onChange: (e) => setFormData({
									...formData,
									email: e.target.value
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-[#86868b] uppercase tracking-wide",
									children: "Employee ID"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl px-4 py-3 text-sm text-[#1d1d1f] transition-all outline-none disabled:opacity-50",
									value: formData.employee_code,
									onChange: (e) => setFormData({
										...formData,
										employee_code: e.target.value
									}),
									disabled: isEdit
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									className: "text-xs font-bold text-[#86868b] uppercase tracking-wide",
									children: "Department"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl px-4 py-3 text-sm text-[#1d1d1f] transition-all outline-none",
									value: formData.department,
									onChange: (e) => setFormData({
										...formData,
										department: e.target.value
									})
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-[#86868b] uppercase tracking-wide",
								children: "Role"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: formData.role_id,
								onValueChange: (v) => setFormData({
									...formData,
									role_id: v
								}),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl px-4 py-3 h-12 text-sm text-[#1d1d1f] transition-all outline-none",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Select a role" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, {
									className: "rounded-2xl border-gray-100 shadow-xl overflow-hidden",
									children: roles.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: r.role_id,
										className: "cursor-pointer py-3 rounded-xl focus:bg-[#f5f5f7] focus:text-[#1d1d1f] m-1",
										children: r.role_name
									}, r.role_id))
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-[#86868b] uppercase tracking-wide",
								children: isEdit ? "Reset Password (Optional)" : "Password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								placeholder: isEdit ? "Leave blank to keep current" : "Temporary password",
								className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl px-4 py-3 text-sm text-[#1d1d1f] transition-all outline-none placeholder:text-[#86868b]",
								value: formData.password,
								onChange: (e) => setFormData({
									...formData,
									password: e.target.value
								})
							})]
						}),
						isEdit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex items-center gap-3 pt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "relative inline-flex items-center cursor-pointer",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										className: "sr-only peer",
										checked: formData.is_active,
										onChange: (e) => setFormData({
											...formData,
											is_active: e.target.checked
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-[#34c759]" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "ml-3 text-sm font-medium text-[#1d1d1f]",
										children: "Active Account"
									})
								]
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex justify-end gap-3 mt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: onClose,
						className: "px-6 py-3 rounded-full bg-white text-[#1d1d1f] border border-gray-200 text-sm font-bold hover:bg-gray-50 transition-colors",
						children: "Cancel"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => saveMutation.mutate(),
						disabled: saveMutation.isPending,
						className: "px-6 py-3 rounded-full bg-[#0066cc] text-white text-sm font-bold hover:bg-[#005bb5] transition-colors disabled:opacity-50",
						children: saveMutation.isPending ? "Saving..." : "Save"
					})]
				})
			]
		})
	});
}
//#endregion
export { UsersPage as component };
