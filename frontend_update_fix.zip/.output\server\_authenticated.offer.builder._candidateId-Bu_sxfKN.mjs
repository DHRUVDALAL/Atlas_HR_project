import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.offer.builder._candidateId-Bu_sxfKN.js
var $$splitComponentImporter = () => import("./_authenticated.offer.builder._candidateId-aeKZuhJa.mjs");
var Route = createFileRoute("/_authenticated/offer/builder/$candidateId")({
	head: () => ({ meta: [{ title: "Build Offer — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
