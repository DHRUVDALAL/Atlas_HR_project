import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { $ as CircleX, N as Laptop, V as FileCheck, X as ClipboardList, a as UserPlus, bt as ArrowLeft, h as Shield, ht as Briefcase, i as User, pt as Calendar, rt as CircleCheckBig } from "./_libs/lucide-react.mjs";
import { n as AnimatePresence, t as motion } from "./_libs/framer-motion+[...].mjs";
import { t as Route } from "./_authenticated.onboarding._candidateId-DlpjqSBk.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.onboarding._candidateId-BnD1hDCg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DOC_TYPE_MAP = {
	aadhaar: "AADHAAR",
	pan: "PAN",
	passport: "PASSPORT",
	driving_license: "DL",
	education: "EDUCATION",
	experience: "EXPERIENCE",
	resume: "RESUME",
	offer_letter: "OFFER_LETTER"
};
var DOC_TYPE_REVERSE = {
	AADHAAR: "aadhaar",
	PAN: "pan",
	PASSPORT: "passport",
	DL: "driving_license",
	EDUCATION: "education",
	EXPERIENCE: "experience",
	RESUME: "resume",
	OFFER_LETTER: "offer_letter"
};
var BGV_TYPE_MAP = {
	reference_check: "REFERENCE",
	employment_verification: "EMPLOYMENT",
	education_verification: "EDUCATION",
	criminal_verification: "CRIMINAL"
};
var BGV_TYPE_REVERSE = {
	REFERENCE: "reference_check",
	EMPLOYMENT: "employment_verification",
	EDUCATION: "education_verification",
	CRIMINAL: "criminal_verification"
};
var ASSET_TYPE_MAP = {
	laptop: "LAPTOP",
	monitor: "MONITOR",
	phone: "PHONE",
	email: "EMAIL",
	access_card: "ACCESS_CARD",
	vpn: "VPN",
	software_licenses: "SOFTWARE_LICENSES"
};
var ASSET_TYPE_REVERSE = {
	LAPTOP: "laptop",
	MONITOR: "monitor",
	PHONE: "phone",
	EMAIL: "email",
	ACCESS_CARD: "access_card",
	VPN: "vpn",
	SOFTWARE_LICENSES: "software_licenses"
};
function transformApiToOnboarding(apiData) {
	const docKeys = [
		"aadhaar",
		"pan",
		"passport",
		"driving_license",
		"education",
		"experience",
		"resume",
		"offer_letter"
	];
	const documents = {};
	for (const key of docKeys) {
		const apiDoc = apiData.documents.find((d) => DOC_TYPE_REVERSE[d.document_type] === key);
		documents[key] = {
			status: apiDoc?.status?.toLowerCase() ?? "pending",
			verified_at: apiDoc?.verified_at || void 0,
			notes: apiDoc?.notes || void 0
		};
	}
	const bgvKeys = [
		"reference_check",
		"employment_verification",
		"education_verification",
		"criminal_verification"
	];
	const background_verification = {};
	for (const key of bgvKeys) {
		const apiBgv = apiData.background_checks.find((b) => BGV_TYPE_REVERSE[b.category] === key);
		background_verification[key] = {
			status: apiBgv?.status?.toLowerCase() ?? "pending",
			verified_at: apiBgv?.verified_at || void 0,
			notes: apiBgv?.notes || void 0
		};
	}
	const assetKeys = [
		"laptop",
		"monitor",
		"phone",
		"email",
		"access_card",
		"vpn",
		"software_licenses"
	];
	const assets = {};
	for (const key of assetKeys) {
		const apiAsset = apiData.assets.find((a) => ASSET_TYPE_REVERSE[a.asset_type] === key);
		assets[key] = {
			status: apiAsset?.status?.toLowerCase() ?? "pending",
			asset_id: apiAsset?.asset_id || void 0,
			allocated_at: apiAsset?.allocated_at || void 0,
			notes: apiAsset?.notes || void 0
		};
	}
	const checklistKeys = [
		"offer_accepted",
		"documents_received",
		"background_complete",
		"it_ready",
		"payroll_ready",
		"manager_assigned",
		"joining_kit",
		"orientation_scheduled"
	];
	const checklist = {};
	for (const key of checklistKeys) checklist[key] = apiData.checklist.find((c) => c.item_name === key)?.is_completed ?? false;
	const history = (apiData.activities ?? []).map((a) => ({
		action: a.action,
		timestamp: a.created_at,
		by: a.performed_by,
		details: a.details
	}));
	return {
		candidate_id: apiData.candidate_id,
		status: apiData.status?.toLowerCase(),
		documents,
		background_verification,
		assets,
		checklist,
		history,
		created_at: apiData.created_at,
		updated_at: apiData.updated_at
	};
}
function getDocProgress(docs) {
	const items = Object.values(docs);
	return Math.round(items.filter((d) => d.status === "verified").length / items.length * 100);
}
function getBgProgress(bgv) {
	const items = Object.values(bgv);
	return Math.round(items.filter((d) => d.status === "cleared").length / items.length * 100);
}
function getAssetProgress(assets) {
	const items = Object.values(assets);
	return Math.round(items.filter((a) => a.status === "allocated" || a.status === "configured").length / items.length * 100);
}
function getChecklistProgress(checklist) {
	const items = Object.values(checklist);
	return Math.round(items.filter(Boolean).length / items.length * 100);
}
function EmployeeProfile() {
	const { candidateId } = Route.useParams();
	const [activeTab, setActiveTab] = (0, import_react.useState)("overview");
	const queryClient = useQueryClient();
	const { data: candidate, isLoading: isLoadingCandidate } = useQuery({
		queryKey: ["candidate", candidateId],
		queryFn: () => api(`/api/applicants/${candidateId}`)
	});
	const { data: onboardingData, isLoading: isLoadingOnboarding, refetch: refetchOnboarding } = useQuery({
		queryKey: ["onboarding", candidateId],
		queryFn: async () => {
			try {
				return await api(`/api/onboarding/candidate/${candidateId}`);
			} catch (err) {
				if (err instanceof Error && "status" in err && err.status === 404) return null;
				throw err;
			}
		}
	});
	const rec = onboardingData?.data ? transformApiToOnboarding(onboardingData.data) : null;
	const startOnboardingMutation = useMutation({
		mutationFn: () => api("/api/onboarding", {
			method: "POST",
			body: { candidate_id: candidateId }
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["onboarding", candidateId] });
			toast.success("Onboarding started");
		},
		onError: () => toast.error("Failed to start onboarding")
	});
	const verifyDocMutation = useMutation({
		mutationFn: ({ docType, notes }) => api(`/api/onboarding/${onboardingData.data.onboarding_id}/documents/${docType}/verify`, {
			method: "POST",
			body: { notes }
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["onboarding", candidateId] });
			toast.success("Document verified");
		},
		onError: () => toast.error("Failed to verify document")
	});
	const rejectDocMutation = useMutation({
		mutationFn: ({ docType, notes }) => api(`/api/onboarding/${onboardingData.data.onboarding_id}/documents/${docType}/reject`, {
			method: "POST",
			body: { notes }
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["onboarding", candidateId] });
			toast.success("Document rejected");
		},
		onError: () => toast.error("Failed to reject document")
	});
	const clearBgvMutation = useMutation({
		mutationFn: ({ category, notes }) => api(`/api/onboarding/${onboardingData.data.onboarding_id}/bgv/${category}/clear`, {
			method: "POST",
			body: { notes }
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["onboarding", candidateId] });
			toast.success("BGV cleared");
		},
		onError: () => toast.error("Failed to clear BGV")
	});
	const failBgvMutation = useMutation({
		mutationFn: ({ category, notes }) => api(`/api/onboarding/${onboardingData.data.onboarding_id}/bgv/${category}/fail`, {
			method: "POST",
			body: { notes }
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["onboarding", candidateId] });
			toast.success("BGV failed");
		},
		onError: () => toast.error("Failed to mark BGV as failed")
	});
	const allocateAssetMutation = useMutation({
		mutationFn: ({ assetType, assetId, notes }) => api(`/api/onboarding/${onboardingData.data.onboarding_id}/assets/${assetType}/allocate`, {
			method: "POST",
			body: {
				asset_id: assetId,
				notes
			}
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["onboarding", candidateId] });
			toast.success("Asset allocated");
		},
		onError: () => toast.error("Failed to allocate asset")
	});
	const checklistMutation = useMutation({
		mutationFn: ({ itemName, isCompleted }) => api(`/api/onboarding/${onboardingData.data.onboarding_id}/checklist/${itemName}`, {
			method: "PUT",
			body: { is_completed: isCompleted }
		}),
		onSuccess: () => {
			queryClient.invalidateQueries({ queryKey: ["onboarding", candidateId] });
			toast.success("Checklist updated");
		},
		onError: () => toast.error("Failed to update checklist")
	});
	const isLoading = isLoadingCandidate || isLoadingOnboarding;
	const formatDate = (dateStr) => {
		return new Date(dateStr).toLocaleDateString("en-IN", {
			day: "numeric",
			month: "short",
			year: "numeric"
		});
	};
	const handleStartOnboarding = () => {
		startOnboardingMutation.mutate();
	};
	const handleUpdateVerification = (category, key, status) => {
		if (!onboardingData?.data) return;
		if (category === "documents") {
			const apiDocType = DOC_TYPE_MAP[key];
			if (!apiDocType) return;
			if (status === "verified") verifyDocMutation.mutate({
				docType: apiDocType,
				notes: ""
			});
			else rejectDocMutation.mutate({
				docType: apiDocType,
				notes: ""
			});
		} else {
			const apiCategory = BGV_TYPE_MAP[key];
			if (!apiCategory) return;
			if (status === "cleared") clearBgvMutation.mutate({
				category: apiCategory,
				notes: ""
			});
			else failBgvMutation.mutate({
				category: apiCategory,
				notes: ""
			});
		}
	};
	const handleUpdateAsset = (key, status) => {
		if (!onboardingData?.data) return;
		const apiAssetType = ASSET_TYPE_MAP[key];
		if (!apiAssetType) return;
		allocateAssetMutation.mutate({
			assetType: apiAssetType,
			assetId: "",
			notes: ""
		});
	};
	const handleToggleChecklist = (key) => {
		if (!onboardingData?.data) return;
		const current = rec?.checklist?.[key] ?? false;
		checklistMutation.mutate({
			itemName: key,
			isCompleted: !current
		});
	};
	const tabs = [
		{
			key: "overview",
			label: "Overview",
			icon: User
		},
		{
			key: "documents",
			label: "Documents",
			icon: FileCheck
		},
		{
			key: "background",
			label: "Background",
			icon: Shield
		},
		{
			key: "assets",
			label: "IT Assets",
			icon: Laptop
		},
		{
			key: "checklist",
			label: "Checklist",
			icon: ClipboardList
		},
		{
			key: "timeline",
			label: "Timeline",
			icon: Calendar
		}
	];
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-10 max-w-6xl mx-auto space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-48 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 w-32 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-full bg-gray-100 rounded-full animate-pulse" })]
		})]
	});
	if (!candidate) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6 lg:p-10 max-w-6xl mx-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white p-12 rounded-[2.5rem] border border-gray-100 text-center shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xl font-bold text-[#1d1d1f]",
				children: "Candidate not found"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/onboarding/queue",
				className: "inline-flex items-center justify-center px-6 py-2.5 rounded-full bg-[#f5f5f7] text-[#1d1d1f] text-sm font-bold hover:bg-gray-200 transition-colors mt-6",
				children: "Back to Queue"
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-6xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/onboarding/queue",
						className: "h-10 w-10 rounded-full bg-[#f5f5f7] flex items-center justify-center text-[#86868b] hover:text-[#1d1d1f] hover:bg-gray-200 transition-colors shrink-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-5 w-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "text-2xl font-bold tracking-tight text-[#1d1d1f]",
							children: [
								candidate.first_name,
								" ",
								candidate.last_name
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-medium text-[#86868b] mt-1 flex flex-wrap items-center gap-x-4 gap-y-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono font-bold bg-[#f5f5f7] px-2 py-0.5 rounded-md text-[#1d1d1f]",
								children: candidate.application_number
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" }),
									" ",
									candidate.position_applied_for ?? "—"
								]
							})]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-3 ml-[4rem] md:ml-0",
					children: [!rec && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: handleStartOnboarding,
						disabled: startOnboardingMutation.isPending,
						className: "inline-flex items-center justify-center px-6 py-2.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98] disabled:opacity-50 disabled:pointer-events-none",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4 mr-2" }), " Start Onboarding"]
					}), rec && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `inline-flex items-center justify-center rounded-full px-4 py-2 text-xs font-bold uppercase tracking-wider ${rec.status === "completed" ? "bg-emerald-50 text-emerald-700" : rec.status === "in_progress" ? "bg-[#0066cc]/10 text-[#0066cc]" : "bg-amber-50 text-amber-700"}`,
						children: rec.status === "completed" ? "Completed" : rec.status === "in_progress" ? "In Progress" : "Pending"
					})]
				})]
			}),
			rec && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 md:grid-cols-4 gap-4",
				children: [
					{
						label: "Documents",
						value: getDocProgress(rec.documents),
						icon: FileCheck,
						color: "text-[#0066cc]"
					},
					{
						label: "Background",
						value: getBgProgress(rec.background_verification),
						icon: Shield,
						color: "text-purple-500"
					},
					{
						label: "IT Assets",
						value: getAssetProgress(rec.assets),
						icon: Laptop,
						color: "text-amber-500"
					},
					{
						label: "Checklist",
						value: getChecklistProgress(rec.checklist),
						icon: ClipboardList,
						color: "text-emerald-500"
					}
				].map((item) => {
					const Icon = item.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white p-5 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 mb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `h-8 w-8 rounded-full bg-gray-50 flex items-center justify-center ${item.color}`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-bold text-[#86868b] uppercase tracking-wider",
								children: item.label
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex-1 h-2 bg-gray-100 rounded-full overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									initial: { width: 0 },
									animate: { width: `${item.value}%` },
									transition: {
										duration: 1,
										ease: "easeOut"
									},
									className: `h-full rounded-full ${item.value === 100 ? "bg-emerald-500" : "bg-[#1d1d1f]"}`
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `text-lg font-bold ${item.value === 100 ? "text-emerald-500" : "text-[#1d1d1f]"}`,
								children: [item.value, "%"]
							})]
						})]
					}, item.label);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex overflow-x-auto gap-2 p-1.5 bg-[#f5f5f7] rounded-full w-fit scrollbar-none",
				children: tabs.map((tab) => {
					const Icon = tab.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => setActiveTab(tab.key),
						className: `flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-all whitespace-nowrap ${activeTab === tab.key ? "bg-white text-[#1d1d1f] shadow-sm" : "text-[#86868b] hover:text-[#1d1d1f] hover:bg-gray-200/50"}`,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }), tab.label]
					}, tab.key);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
				mode: "wait",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 10
					},
					animate: {
						opacity: 1,
						y: 0
					},
					exit: {
						opacity: 0,
						y: -10
					},
					transition: { duration: .2 },
					children: [
						activeTab === "overview" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-1 lg:grid-cols-2 gap-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-xl font-bold text-[#1d1d1f] mb-6 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4 text-[#86868b]" })
									}), "Personal Information"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Full Name",
											value: `${candidate.first_name} ${candidate.last_name}`
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Email",
											value: candidate.email
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Phone",
											value: candidate.phone
										}),
										candidate.gender && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Gender",
											value: candidate.gender
										}),
										candidate.city && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Location",
											value: `${candidate.city}, ${candidate.state}`
										}),
										candidate.applied_from && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Applied From",
											value: candidate.applied_from
										}),
										candidate.applied_from === "REFERRAL" && candidate.source_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Referred By",
											value: candidate.source_name
										}),
										candidate.applied_from === "VENDOR" && candidate.source_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Vendor Name",
											value: candidate.source_name
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "text-xl font-bold text-[#1d1d1f] mb-6 flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4 text-[#86868b]" })
									}), "Professional Details"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "space-y-4",
									children: [
										candidate.professional_details?.current_company && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Current Company",
											value: candidate.professional_details.current_company
										}),
										candidate.professional_details?.current_designation && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Current Designation",
											value: candidate.professional_details.current_designation
										}),
										candidate.professional_details?.total_experience && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Total Experience",
											value: `${candidate.professional_details.total_experience} years`
										}),
										candidate.professional_details?.current_ctc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Current CTC",
											value: `₹${candidate.professional_details.current_ctc} LPA`
										}),
										candidate.professional_details?.expected_ctc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoRow, {
											label: "Expected CTC",
											value: `₹${candidate.professional_details.expected_ctc} LPA`
										})
									]
								})]
							})]
						}),
						activeTab === "documents" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-8 sm:p-10 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-xl font-bold text-[#1d1d1f] mb-8 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-4 w-4 text-[#86868b]" })
								}), "Document Verification"]
							}), !rec ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
								icon: FileCheck,
								title: "Start onboarding first",
								description: "Begin the onboarding process to track document verification."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4",
								children: Object.entries(rec.documents).map(([key, doc]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerificationCard, {
									title: key.replace(/_/g, " "),
									status: doc.status,
									onVerify: () => handleUpdateVerification("documents", key, "verified"),
									onReject: () => handleUpdateVerification("documents", key, "rejected"),
									isPending: verifyDocMutation.isPending || rejectDocMutation.isPending
								}, key))
							})]
						}),
						activeTab === "background" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-8 sm:p-10 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-xl font-bold text-[#1d1d1f] mb-8 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { className: "h-4 w-4 text-[#86868b]" })
								}), "Background Verification"]
							}), !rec ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
								icon: Shield,
								title: "Start onboarding first",
								description: "Begin the onboarding process to track background verification."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 gap-4",
								children: Object.entries(rec.background_verification).map(([key, bgv]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VerificationCard, {
									title: key.replace(/_/g, " "),
									status: bgv.status,
									onVerify: () => handleUpdateVerification("background_verification", key, "cleared"),
									onReject: () => handleUpdateVerification("background_verification", key, "failed"),
									verifyLabel: "Clear",
									rejectLabel: "Fail",
									isPending: clearBgvMutation.isPending || failBgvMutation.isPending
								}, key))
							})]
						}),
						activeTab === "assets" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-8 sm:p-10 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-xl font-bold text-[#1d1d1f] mb-8 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Laptop, { className: "h-4 w-4 text-[#86868b]" })
								}), "IT Asset Allocation"]
							}), !rec ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
								icon: Laptop,
								title: "Start onboarding first",
								description: "Begin the onboarding process to track IT asset allocation."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",
								children: Object.entries(rec.assets).map(([key, asset]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "p-5 rounded-[2rem] border border-gray-100 bg-[#fbfbfd] hover:border-gray-200 transition-colors group",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center justify-between mb-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "font-bold text-sm text-[#1d1d1f] capitalize",
											children: key.replace(/_/g, " ")
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${asset.status === "allocated" || asset.status === "configured" ? "bg-emerald-50 text-emerald-700" : "bg-amber-50 text-amber-700"}`,
											children: asset.status === "allocated" ? "Allocated" : asset.status === "configured" ? "Configured" : asset.status === "returned" ? "Returned" : "Pending"
										})]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => handleUpdateAsset(key, key === "email" || key === "vpn" ? "configured" : "allocated"),
										disabled: allocateAssetMutation.isPending || asset.status === "allocated" || asset.status === "configured",
										className: `w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${asset.status === "allocated" || asset.status === "configured" ? "bg-gray-100 text-gray-400 cursor-not-allowed" : "bg-white border border-gray-200 text-[#1d1d1f] hover:bg-gray-50 active:scale-[0.98] shadow-sm"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-4 w-4" }), key === "email" || key === "vpn" ? "Configure" : "Allocate"]
									})]
								}, key))
							})]
						}),
						activeTab === "checklist" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-8 sm:p-10 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-xl font-bold text-[#1d1d1f] mb-8 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "h-4 w-4 text-[#86868b]" })
								}), "HR Onboarding Checklist"]
							}), !rec ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
								icon: ClipboardList,
								title: "Start onboarding first",
								description: "Begin the onboarding process to track the HR checklist."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-3 max-w-3xl",
								children: Object.entries(rec.checklist).map(([key, completed]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `flex items-center gap-4 p-4 rounded-[1.5rem] cursor-pointer transition-colors border ${completed ? "bg-emerald-50/50 border-emerald-100" : "bg-white border-gray-100 hover:border-gray-200 hover:bg-[#fbfbfd]"}`,
									onClick: () => handleToggleChecklist(key),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: `h-6 w-6 rounded-full border-2 flex items-center justify-center transition-colors shrink-0 ${completed ? "bg-emerald-500 border-emerald-500 text-white" : "border-gray-300"}`,
											children: completed && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-4 w-4" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex-1 min-w-0",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: `text-sm font-bold capitalize truncate ${completed ? "text-emerald-900" : "text-[#1d1d1f]"}`,
												children: key.replace(/_/g, " ")
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider shrink-0 ${completed ? "bg-emerald-100 text-emerald-800" : "bg-gray-100 text-gray-600"}`,
											children: completed ? "Done" : "Pending"
										})
									]
								}, key))
							})]
						}),
						activeTab === "timeline" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-8 sm:p-10 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-xl font-bold text-[#1d1d1f] mb-8 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4 text-[#86868b]" })
								}), "Onboarding Timeline"]
							}), !rec || rec.history.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
								icon: Calendar,
								title: "No activity yet",
								description: "Timeline will appear as onboarding progresses."
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "relative max-w-3xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-[2.25rem] top-6 bottom-6 w-0.5 bg-gray-100" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "space-y-8",
									children: rec.history.slice().reverse().map((entry, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "relative flex items-start gap-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "relative z-10 h-[4.5rem] w-[4.5rem] rounded-full bg-white border-[4px] border-[#1d1d1f] text-[#1d1d1f] flex items-center justify-center shrink-0 shadow-sm",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-7 w-7" })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex-1 pt-2 pb-6 border-b border-gray-50 last:border-0 last:pb-0",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h4", {
													className: "text-lg font-bold text-[#1d1d1f] capitalize",
													children: entry.action.replace(/_/g, " ")
												}),
												entry.details && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-medium text-[#86868b] mt-1",
													children: entry.details
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mt-3",
													children: [
														formatDate(entry.timestamp),
														" ",
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "mx-1",
															children: "•"
														}),
														" ",
														entry.by
													]
												})
											]
										})]
									}, i))
								})]
							})]
						})
					]
				}, activeTab)
			})
		]
	});
}
function InfoRow({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col sm:flex-row sm:items-center sm:justify-between py-2 border-b border-gray-50 last:border-0 gap-1 sm:gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider shrink-0",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm font-bold text-[#1d1d1f] text-left sm:text-right",
			children: value
		})]
	});
}
function EmptyState({ icon: Icon, title, description }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center py-12 bg-[#fbfbfd] rounded-[2rem] border border-gray-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "w-20 h-20 mx-auto rounded-full bg-white border border-gray-100 flex items-center justify-center mb-6 shadow-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-10 w-10 text-[#86868b]" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-2xl font-bold text-[#1d1d1f] mb-2",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-[#86868b] max-w-sm mx-auto",
				children: description
			})
		]
	});
}
function VerificationCard({ title, status, onVerify, onReject, verifyLabel = "Verify", rejectLabel = "Reject", isPending = false }) {
	const isVerified = status === "verified" || status === "cleared";
	const isRejected = status === "rejected" || status === "failed";
	const isFinished = isVerified || isRejected;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-5 rounded-[2rem] border border-gray-100 bg-[#fbfbfd] hover:border-gray-200 transition-colors group",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between mb-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "font-bold text-sm text-[#1d1d1f] capitalize",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${isVerified ? "bg-emerald-50 text-emerald-700" : isRejected ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`,
				children: isVerified ? "Cleared" : isRejected ? "Failed" : "Pending"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: onVerify,
				disabled: isPending || isFinished,
				className: `flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${isVerified ? "bg-emerald-50 text-emerald-700 cursor-not-allowed" : isFinished ? "bg-gray-50 text-gray-400 cursor-not-allowed" : "bg-white border border-gray-200 text-[#1d1d1f] hover:bg-gray-50 active:scale-[0.98] shadow-sm"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-3.5 w-3.5" }), verifyLabel]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				onClick: onReject,
				disabled: isPending || isFinished,
				className: `flex-1 flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl text-xs font-bold transition-all ${isRejected ? "bg-red-50 text-red-700 cursor-not-allowed" : isFinished ? "bg-gray-50 text-gray-400 cursor-not-allowed" : "bg-white border border-gray-200 text-[#1d1d1f] hover:bg-red-50 hover:text-red-600 hover:border-red-200 active:scale-[0.98] shadow-sm"}`,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: "h-3.5 w-3.5" }), rejectLabel]
			})]
		})]
	});
}
//#endregion
export { EmployeeProfile as component };
