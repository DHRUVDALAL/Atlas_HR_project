import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.offer.status._candidateId-Dg_YY84G.js
var $$splitComponentImporter = () => import("./_authenticated.offer.status._candidateId-TZpIuVvT.mjs");
var Route = createFileRoute("/_authenticated/offer/status/$candidateId")({
	head: () => ({ meta: [{ title: "Offer Status — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
