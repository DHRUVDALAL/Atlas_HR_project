import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { V as FileCheck, a as UserPlus, ot as ChevronRight, st as ChevronLeft, y as Search, yt as ArrowRight } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.onboarding.queue-ylZ9nQQt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var statusParamMap = {
	all: void 0,
	pending: "PENDING",
	in_progress: "IN_PROGRESS",
	completed: "COMPLETED"
};
function EmployeeQueue() {
	const [search, setSearch] = (0, import_react.useState)("");
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [page, setPage] = (0, import_react.useState)(1);
	const pageSize = 10;
	const skip = (page - 1) * pageSize;
	const params = new URLSearchParams({
		skip: String(skip),
		limit: String(pageSize),
		sort_by: "created_at",
		sort_order: "desc"
	});
	const statusParam = statusParamMap[filter];
	if (statusParam) params.set("status", statusParam);
	if (search) params.set("search", search);
	const { data: onboardingData, isLoading } = useQuery({
		queryKey: ["onboarding", {
			skip,
			limit: pageSize,
			status: statusParam,
			search,
			sort_by: "created_at",
			sort_order: "desc"
		}],
		queryFn: () => api(`/api/onboarding?${params.toString()}`)
	});
	const items = onboardingData?.data ?? [];
	const total = onboardingData?.total ?? 0;
	const totalPages = Math.ceil(total / pageSize);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
					children: "Employee Queue"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-[#86868b] mt-1",
					children: "Manage onboarding for selected candidates."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/onboarding/dashboard",
					className: "flex items-center bg-white border border-gray-200 text-[#1d1d1f] hover:bg-[#f5f5f7] rounded-full px-6 py-2.5 text-sm font-bold shadow-sm transition-all active:scale-[0.98]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4 mr-2" }), " Dashboard"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-4 md:p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] space-y-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col md:flex-row items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1 w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-[#86868b]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "text",
							placeholder: "Search by name, email, application number...",
							value: search,
							onChange: (e) => {
								setSearch(e.target.value);
								setPage(1);
							},
							className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl pl-11 pr-5 py-3 text-sm text-[#1d1d1f] placeholder:text-[#86868b] transition-all outline-none"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-2 w-full md:w-auto",
						children: [
							"all",
							"pending",
							"in_progress",
							"completed"
						].map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => {
								setFilter(f);
								setPage(1);
							},
							className: `px-5 py-2.5 text-sm font-bold rounded-2xl transition-colors ${filter === f ? "bg-[#1d1d1f] text-white shadow-sm" : "bg-[#f5f5f7] text-[#86868b] hover:text-[#1d1d1f]"}`,
							children: f === "all" ? "All" : f === "pending" ? "Pending" : f === "in_progress" ? "In Progress" : "Completed"
						}, f))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-[2.5rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-6 px-8 py-6 border-b border-gray-50/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-10 rounded-full" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-60" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-24 rounded-full" })
						]
					}, i))
				}) : items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-16 text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-12 w-12 text-gray-200 mx-auto mb-4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-lg font-bold text-[#1d1d1f]",
							children: "No candidates found"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-[#86868b] mt-1",
							children: search ? "Try adjusting your search terms." : filter !== "all" ? "No candidates match this filter." : "No selected candidates yet. Onboarding will appear here once candidates reach SELECTED status."
						})
					]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: items.map((item) => {
						const statusUpper = item.status?.toUpperCase();
						const nameParts = item.candidate_name?.split(" ") ?? [];
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[auto_1fr_auto_auto_auto] gap-6 px-6 md:px-8 py-5 border-b border-gray-50/50 hover:bg-[#f5f5f7]/60 transition-colors items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-10 w-10 rounded-full bg-[#f5f5f7] grid place-items-center text-[#1d1d1f] font-bold text-xs",
									children: nameParts.length >= 2 ? `${nameParts[0][0]}${nameParts[nameParts.length - 1][0]}` : item.candidate_name?.[0]?.toUpperCase() ?? "?"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 pr-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-bold text-[#1d1d1f] truncate",
										children: item.candidate_name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
										children: item.application_number
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "hidden sm:flex items-center justify-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-1.5 text-xs font-bold text-[#86868b]",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-3.5 w-3.5" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: item.progress_percent === 100 ? "text-emerald-600" : "",
											children: [item.progress_percent, "%"]
										})]
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex justify-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-semibold tracking-wide ${statusUpper === "COMPLETED" ? "bg-emerald-50 text-emerald-700" : statusUpper === "IN_PROGRESS" ? "bg-blue-50 text-blue-700" : "bg-amber-50 text-amber-700"}`,
										children: statusUpper === "COMPLETED" ? "Completed" : statusUpper === "IN_PROGRESS" ? "In Progress" : statusUpper === "PENDING" ? "Pending" : item.status
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-end w-24",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/onboarding/$candidateId",
										params: { candidateId: item.candidate_id },
										className: `flex items-center ${statusUpper === "PENDING" ? "bg-[#0066cc] hover:bg-[#005bb5] text-white" : "bg-transparent hover:bg-gray-100 border border-gray-200 text-[#1d1d1f]"} rounded-full px-5 py-2 text-xs font-bold transition-all shadow-sm active:scale-[0.98]`,
										children: statusUpper === "PENDING" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["Start ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 ml-1.5" })] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: ["View ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 ml-1.5" })] })
									})
								})
							]
						}, item.candidate_id);
					})
				}), totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-8 py-5 bg-[#fbfbfd] border-t border-gray-100 flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm font-medium text-[#86868b]",
						children: [
							"Showing ",
							skip + 1,
							"–",
							Math.min(skip + pageSize, total),
							" of ",
							total
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: page === 1,
							onClick: () => setPage((p) => p - 1),
							className: "h-9 w-9 flex items-center justify-center rounded-full border border-gray-200 text-[#1d1d1f] hover:bg-gray-50 disabled:opacity-50 disabled:hover:bg-transparent transition-colors",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							disabled: page === totalPages,
							onClick: () => setPage((p) => p + 1),
							className: "h-9 w-9 flex items-center justify-center rounded-full border border-gray-200 text-[#1d1d1f] hover:bg-gray-50 disabled:opacity-50 disabled:hover:bg-transparent transition-colors",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })
						})]
					})]
				})]
			})
		]
	});
}
//#endregion
export { EmployeeQueue as component };
