import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { B as FileText, D as MapPin, G as Download, I as GraduationCap, W as ExternalLink, Y as Clock, Z as ClipboardCheck, bt as ArrowLeft, ht as Briefcase, i as User, m as Star, pt as Calendar } from "./_libs/lucide-react.mjs";
import { i as statusMeta } from "./_ssr/scorecard-YpVMHDsm.mjs";
import { n as AnimatePresence, t as motion } from "./_libs/framer-motion+[...].mjs";
import { t as Route } from "./_authenticated.interviewer.review._id-IO8F3QfN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.interviewer.review._id-Jj_Tj8Y6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function InterviewerReview() {
	const { id } = Route.useParams();
	const [activeTab, setActiveTab] = (0, import_react.useState)("profile");
	const { data, isLoading } = useQuery({
		queryKey: ["candidate", id],
		queryFn: () => api(`/api/applicants/${id}`).then((r) => r.data)
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-10 max-w-6xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-32 bg-gray-100 rounded-full animate-pulse" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-64 bg-gray-100 rounded-full animate-pulse" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-48 bg-gray-100 rounded-full animate-pulse" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-32 bg-gray-100 rounded-full animate-pulse" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-full bg-gray-100 rounded-full animate-pulse" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] grid sm:grid-cols-2 gap-6",
				children: Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-24 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-40 bg-gray-100 rounded-full animate-pulse" })]
				}, i))
			})
		]
	});
	if (!data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-8 text-center text-sm font-bold text-[#86868b]",
		children: "Not found"
	});
	const s = statusMeta(data.status);
	const tabs = [
		{
			id: "profile",
			label: "Profile"
		},
		{
			id: "experience",
			label: "Experience"
		},
		{
			id: "education",
			label: "Education"
		},
		{
			id: "rounds",
			label: `Rounds (${data.interview_rounds?.length ?? 0})`
		},
		{
			id: "documents",
			label: `Documents (${data.documents?.length ?? 0})`
		},
		{
			id: "timeline",
			label: "Timeline"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-6xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/interviewer/queue",
						className: "flex items-center text-sm font-bold text-[#86868b] hover:text-[#1d1d1f] transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center mr-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" })
						}), "Back to queue"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: `/interviewer/evaluate/${id}`,
					className: "inline-flex items-center justify-center px-6 py-2.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "h-4 w-4 mr-2" }), " Start Evaluation"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "h-16 w-16 rounded-full bg-[#f5f5f7] flex items-center justify-center text-xl font-bold text-[#1d1d1f] shrink-0 border-2 border-white shadow-sm",
							children: [data.first_name[0], data.last_name[0]]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3 flex-wrap",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
								className: "text-2xl font-bold tracking-tight text-[#1d1d1f]",
								children: [
									data.first_name,
									" ",
									data.last_name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold tracking-wide uppercase ${s.className.replace("border-transparent", "")}`,
								children: s.label
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-medium text-[#86868b] mt-2 flex flex-wrap gap-x-4 gap-y-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono font-bold bg-[#f5f5f7] px-2 py-0.5 rounded-md text-[#1d1d1f]",
									children: data.application_number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" }),
										" ",
										data.position_applied_for ?? "—"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: data.email }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: data.phone })
							]
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: `/interviewer/evaluate/${id}`,
							className: "inline-flex items-center justify-center px-6 py-2.5 rounded-full bg-[#f5f5f7] text-[#1d1d1f] text-sm font-bold hover:bg-gray-200 transition-colors",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "h-4 w-4 mr-2" }), " Submit Evaluation"]
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex overflow-x-auto gap-2 p-1.5 bg-[#f5f5f7] rounded-full w-fit scrollbar-none",
				children: tabs.map((tab) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					onClick: () => setActiveTab(tab.id),
					className: `flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-all whitespace-nowrap ${activeTab === tab.id ? "bg-white text-[#1d1d1f] shadow-sm" : "text-[#86868b] hover:text-[#1d1d1f] hover:bg-gray-200/50"}`,
					children: tab.label
				}, tab.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
				mode: "wait",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: 10
					},
					animate: {
						opacity: 1,
						y: 0
					},
					exit: {
						opacity: 0,
						y: -10
					},
					transition: { duration: .2 },
					children: [
						activeTab === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] grid sm:grid-cols-2 gap-x-8 gap-y-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Gender",
									value: data.gender,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Date of birth",
									value: data.date_of_birth,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Address",
									value: [
										data.current_address,
										data.city,
										data.state,
										data.pincode
									].filter(Boolean).join(", "),
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Country",
									value: data.country,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" })
								}),
								data.applied_from && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Applied From",
									value: data.applied_from,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" })
								}),
								data.applied_from === "REFERRAL" && data.source_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Referred By",
									value: data.source_name,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-4 w-4" })
								}),
								data.applied_from === "VENDOR" && data.source_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Vendor Name",
									value: data.source_name,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "sm:col-span-2 h-px bg-gray-100 my-2" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Total experience",
									value: data.professional_details?.total_experience ? `${data.professional_details.total_experience} yrs` : "—",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Relevant experience",
									value: data.professional_details?.relevant_experience ? `${data.professional_details.relevant_experience} yrs` : "—",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Current company",
									value: data.professional_details?.current_company,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Current designation",
									value: data.professional_details?.current_designation,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Current CTC",
									value: data.professional_details?.current_ctc ? `₹${data.professional_details.current_ctc} LPA` : "—",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Expected CTC",
									value: data.professional_details?.expected_ctc ? `₹${data.professional_details.expected_ctc} LPA` : "—",
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Notice period",
									value: data.professional_details?.notice_period,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Preferred location",
									value: data.professional_details?.preferred_location,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Joining availability",
									value: data.professional_details?.joining_availability,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Employment type",
									value: data.professional_details?.employment_type,
									icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" })
								})
							]
						}),
						activeTab === "experience" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [(data.employment_history ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] text-center text-sm font-bold text-[#86868b]",
								children: "No history captured."
							}), (data.employment_history ?? []).map((h, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between gap-4 flex-wrap mb-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-bold text-[#1d1d1f] text-lg",
											children: [
												h.designation,
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#86868b] font-medium px-2",
													children: "at"
												}),
												" ",
												h.company_name
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider bg-[#f5f5f7] px-3 py-1 rounded-full",
											children: [
												h.start_date,
												" — ",
												h.end_date || "Present"
											]
										})]
									}),
									h.responsibilities && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm font-medium text-[#1d1d1f] leading-relaxed mt-4 bg-[#fbfbfd] p-4 rounded-2xl border border-gray-50",
										children: h.responsibilities
									}),
									h.reason_for_leaving && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mt-4",
										children: ["Reason for leaving: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[#1d1d1f] normal-case tracking-normal text-sm font-medium",
											children: h.reason_for_leaving
										})]
									})
								]
							}, i))]
						}),
						activeTab === "education" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [(data.education ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] text-center text-sm font-bold text-[#86868b]",
								children: "No education captured."
							}), (data.education ?? []).map((e, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] grid sm:grid-cols-2 gap-x-8 gap-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Qualification",
										value: e.qualification,
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "h-4 w-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Specialization",
										value: e.specialization,
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "h-4 w-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Institution",
										value: e.institution_name,
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "University",
										value: e.university,
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "h-4 w-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Passing year",
										value: e.passing_year?.toString(),
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "h-4 w-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Score",
										value: e.percentage ? `${e.percentage}%` : e.grade,
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-4 w-4" })
									})
								]
							}, i))]
						}),
						activeTab === "rounds" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [(data.interview_rounds ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] text-center text-sm font-bold text-[#86868b]",
								children: "No rounds recorded yet."
							}), (data.interview_rounds ?? []).map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-baseline justify-between gap-4 flex-wrap mb-4",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "font-bold text-lg text-[#1d1d1f]",
											children: [
												r.round_type.replace(/_/g, " "),
												" ",
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-[#86868b] font-medium px-1",
													children: "·"
												}),
												" Round ",
												r.round_number
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider bg-gray-100 text-gray-700",
											children: r.status
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2 text-[11px] font-bold text-[#86868b] uppercase tracking-wider mb-6 pb-4 border-b border-gray-50",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.interviewer_email }), r.completed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1 h-1 rounded-full bg-gray-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Completed ", new Date(r.completed_at).toLocaleDateString()] })] })]
									}),
									r.evaluation_data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-4",
										children: Object.entries(r.evaluation_data).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center justify-between gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-sm font-medium text-[#1d1d1f]",
												children: k
											}), v.remarks && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wide mt-1",
												children: v.remarks
											})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-1.5 bg-[#fbfbfd] px-3 py-1 rounded-full border border-gray-100 shrink-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-3.5 w-3.5 text-[#0066cc] fill-[#0066cc]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "font-mono text-sm font-bold text-[#1d1d1f]",
													children: [v.rating, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[#86868b]",
														children: "/5"
													})]
												})]
											})]
										}, k))
									})
								]
							}, r.round_id))]
						}),
						activeTab === "documents" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-4",
							children: [(data.documents ?? []).length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] text-center text-sm font-bold text-[#86868b]",
								children: "No documents uploaded."
							}), (data.documents ?? []).map((d) => {
								const fileUrl = `http://localhost:8001${d.file_path.startsWith("/") ? "" : "/"}${d.file_path}`;
								const isPdf = d.file_name?.toLowerCase().endsWith(".pdf");
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "bg-white p-6 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-4",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-12 w-12 rounded-2xl bg-[#f5f5f7] flex items-center justify-center shrink-0",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-6 w-6 text-[#86868b]" })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex-1 min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-sm font-bold text-[#1d1d1f]",
													children: d.document_type.replace(/_/g, " ")
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
													children: d.file_name
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
													href: fileUrl,
													target: "_blank",
													rel: "noreferrer",
													className: "inline-flex items-center justify-center px-4 py-2 rounded-full bg-[#f5f5f7] text-[#1d1d1f] text-xs font-bold hover:bg-gray-200 transition-colors",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExternalLink, { className: "h-3.5 w-3.5 mr-1.5" }), " View"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: fileUrl,
													download: d.file_name,
													className: "inline-flex items-center justify-center h-8 w-8 rounded-full bg-[#f5f5f7] text-[#1d1d1f] hover:bg-gray-200 transition-colors",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" })
												})]
											})
										]
									}), isPdf && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-6 border border-gray-100 rounded-[1.5rem] overflow-hidden shadow-sm",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("iframe", {
											src: fileUrl,
											className: "w-full h-80 bg-[#f5f5f7]",
											title: d.file_name
										})
									})]
								}, d.document_id);
							})]
						}),
						activeTab === "timeline" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimelineTab, { candidateId: id })
					]
				}, activeTab)
			})
		]
	});
}
function TimelineTab({ candidateId }) {
	const { data, isLoading } = useQuery({
		queryKey: ["candidate-timeline", candidateId],
		queryFn: () => api(`/api/workflow/candidate/${candidateId}/timeline`).then((r) => r.activities ?? [])
	});
	if (isLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] space-y-6",
		children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-3 bg-gray-200 rounded-full mt-1.5 animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-48 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-32 bg-gray-50 rounded-full animate-pulse" })]
			})]
		}, i))
	});
	const activities = data ?? [];
	if (activities.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] text-center text-sm font-bold text-[#86868b]",
		children: "No timeline events recorded."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] relative",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute left-[2.35rem] top-8 bottom-8 w-px bg-gray-100" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-8 relative z-10",
			children: activities.map((a, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-4 rounded-full bg-white border-[3px] border-[#1d1d1f] shrink-0 mt-1 shadow-sm" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex-1 min-w-0 bg-[#fbfbfd] p-4 rounded-2xl border border-gray-50",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-bold text-[#1d1d1f]",
						children: a.description
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mt-2 flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: a.performed_by }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1 h-1 rounded-full bg-gray-300" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: new Date(a.created_at).toLocaleString(void 0, {
								dateStyle: "medium",
								timeStyle: "short"
							}) })
						]
					})]
				})]
			}, a.activity_id))
		})]
	});
}
function Field({ label, value, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3",
		children: [icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-0.5 text-gray-400 shrink-0",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] font-bold text-[#86868b] uppercase tracking-widest",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-medium text-[#1d1d1f] mt-1",
			children: value ?? "—"
		})] })]
	});
}
//#endregion
export { InterviewerReview as component };
