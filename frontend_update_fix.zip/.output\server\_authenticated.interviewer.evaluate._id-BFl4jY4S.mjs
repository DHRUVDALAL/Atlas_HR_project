import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link, v as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { $ as CircleX, Z as ClipboardCheck, bt as ArrowLeft, ct as ChevronDown, ht as Briefcase, i as User, it as CircleAlert, nt as CircleCheck, tt as CirclePause, v as Send } from "./_libs/lucide-react.mjs";
import { n as AnimatePresence, t as motion } from "./_libs/framer-motion+[...].mjs";
import { t as Route } from "./_authenticated.interviewer.evaluate._id-CZEBw3EA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.interviewer.evaluate._id-BFl4jY4S.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TechEval() {
	const { id } = Route.useParams();
	const nav = useNavigate();
	const qc = useQueryClient();
	const { data: candidate, isLoading: candidateLoading } = useQuery({
		queryKey: ["candidate", id],
		queryFn: () => api(`/api/applicants/${id}`).then((r) => r.data)
	});
	const { data: assignment } = useQuery({
		queryKey: [
			"interview",
			"assignment",
			id
		],
		queryFn: () => api(`/api/interview/assignment/${id}`).then((r) => r.assignment),
		enabled: !!id
	});
	const domainCode = assignment?.domain_code || candidate?.domain || "";
	const bracketCode = assignment?.experience_bracket_code || "";
	const { data: topicGroups, isLoading: topicsLoading } = useQuery({
		queryKey: [
			"interview",
			"questions",
			domainCode,
			bracketCode
		],
		queryFn: () => api(`/api/interview/questions?domain=${domainCode}&experience=${bracketCode}&grouped=true`).then((r) => r.groups ?? []),
		enabled: !!domainCode && !!bracketCode
	});
	const nextRound = (candidate?.interview_rounds ?? []).filter((r) => r.round_type === "TECHNICAL").length + 1;
	const [status, setStatus] = (0, import_react.useState)("COMPLETED");
	const [remarks, setRemarks] = (0, import_react.useState)("");
	const [nextInterviewer, setNextInterviewer] = (0, import_react.useState)("");
	const [roundNumber, setRoundNumber] = (0, import_react.useState)(nextRound);
	const [responses, setResponses] = (0, import_react.useState)({});
	const [expandedCategories, setExpandedCategories] = (0, import_react.useState)({});
	const autoSaveTimerRef = (0, import_react.useRef)(null);
	const { data: savedProgress } = useQuery({
		queryKey: [
			"interview",
			"auto-save",
			id
		],
		queryFn: () => api(`/api/interview/auto-save/${id}`).then((r) => r),
		enabled: !!id
	});
	(0, import_react.useEffect)(() => {
		if (topicGroups && topicGroups.length > 0) {
			const initial = {};
			topicGroups.forEach((group) => {
				group.questions.forEach((q) => {
					initial[q.id] = {
						rating: null,
						comment: ""
					};
				});
			});
			if (savedProgress?.responses) savedProgress.responses.forEach((r) => {
				if (initial[r.topic_id]) initial[r.topic_id] = {
					rating: r.rating ?? null,
					comment: r.comment ?? ""
				};
			});
			setResponses(initial);
		}
	}, [topicGroups, savedProgress]);
	(0, import_react.useEffect)(() => {
		if (topicGroups) {
			const expanded = {};
			topicGroups.forEach((g) => {
				expanded[g.topic_category] = true;
			});
			setExpandedCategories(expanded);
		}
	}, [topicGroups]);
	const triggerAutoSave = (0, import_react.useCallback)(() => {
		if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current);
		autoSaveTimerRef.current = setTimeout(() => {
			if (!assignment) return;
			const responseList = Object.entries(responses).map(([topicId, data]) => ({
				topic_id: topicId,
				rating: data.rating || null,
				comment: data.comment
			}));
			api(`/api/interview/auto-save/${id}`, {
				method: "POST",
				body: { responses: responseList }
			}).catch(() => {});
		}, 2e3);
	}, [
		responses,
		assignment,
		id
	]);
	(0, import_react.useEffect)(() => {
		triggerAutoSave();
		return () => {
			if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current);
		};
	}, [responses, triggerAutoSave]);
	const updateRating = (topicId, rating) => {
		setResponses((prev) => ({
			...prev,
			[topicId]: {
				...prev[topicId],
				rating
			}
		}));
	};
	const updateComment = (topicId, comment) => {
		setResponses((prev) => ({
			...prev,
			[topicId]: {
				...prev[topicId],
				comment
			}
		}));
	};
	const toggleCategory = (category) => {
		setExpandedCategories((prev) => ({
			...prev,
			[category]: !prev[category]
		}));
	};
	const RATING_OPTIONS = [
		{
			value: 5,
			label: "Good"
		},
		{
			value: 4,
			label: "OK"
		},
		{
			value: 3,
			label: "Basic"
		},
		{
			value: 2,
			label: "Has Knowledge (Not Worked)"
		},
		{
			value: 1,
			label: "Not Worked"
		},
		{
			value: 0,
			label: "Bad"
		}
	];
	const allQuestions = topicGroups?.flatMap((g) => g.questions) ?? [];
	const totalQuestions = allQuestions.length;
	const answeredQuestions = allQuestions.filter((q) => responses[q.id]?.rating !== void 0 && responses[q.id]?.rating !== null).length;
	const allRated = totalQuestions > 0 && answeredQuestions === totalQuestions;
	const progressPercent = totalQuestions > 0 ? answeredQuestions / totalQuestions * 100 : 0;
	const submit = useMutation({
		mutationFn: async () => {
			const responseList = Object.entries(responses).map(([topicId, data]) => ({
				topic_id: topicId,
				rating: data.rating !== null && data.rating !== void 0 ? data.rating : null,
				comment: data.comment
			}));
			return await api(`/api/interview/submit/${id}`, {
				method: "POST",
				body: {
					responses: responseList,
					overall_remarks: remarks,
					status_selection: status,
					round_number: roundNumber,
					next_interviewer_email: status === "COMPLETED" ? nextInterviewer : null
				}
			});
		},
		onSuccess: () => {
			toast.success("Interview submitted successfully");
			qc.invalidateQueries();
			nav({ to: `/candidates/${id}` });
		},
		onError: (e) => toast.error(e instanceof Error ? e.message : "Failed to submit")
	});
	if (candidateLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-10 max-w-5xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-32 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-32 bg-gray-100 rounded-full animate-pulse" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-64 bg-gray-100 rounded-full animate-pulse" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-48 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-32 bg-gray-100 rounded-full animate-pulse" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-full bg-gray-100 rounded-xl animate-pulse" }, i))
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-5xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/interviewer/queue",
						className: "flex items-center text-sm font-bold text-[#86868b] hover:text-[#1d1d1f] transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center mr-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" })
						}), "Back to queue"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[#86868b] font-bold",
						children: "/"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: `/interviewer/review/${id}`,
						className: "flex items-center text-sm font-bold text-[#86868b] hover:text-[#1d1d1f] transition-colors bg-[#f5f5f7] px-4 py-1.5 rounded-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-3.5 w-3.5 mr-1.5" }), " View profile"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-3xl font-bold tracking-tighter text-[#1d1d1f] flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-12 w-12 rounded-2xl bg-blue-50 flex items-center justify-center shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "h-6 w-6 text-[#0066cc]" })
				}), "Technical Evaluation"]
			}), candidate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-medium text-[#86868b] mt-2 ml-[3.75rem]",
				children: [
					"Round ",
					roundNumber,
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono font-bold bg-[#f5f5f7] px-2 py-0.5 rounded-md text-[#1d1d1f]",
						children: candidate.application_number
					})
				]
			})] }),
			candidate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col md:flex-row md:items-center gap-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "h-16 w-16 rounded-full bg-[#f5f5f7] flex items-center justify-center text-xl font-bold text-[#1d1d1f] shrink-0 border-2 border-white shadow-sm",
							children: [candidate.first_name[0], candidate.last_name[0]]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex-1 min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-1",
								children: [
									candidate.first_name,
									" ",
									candidate.last_name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm font-medium text-[#86868b] flex flex-wrap items-center gap-x-4 gap-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1.5",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" }),
											" ",
											candidate.position_applied_for ?? "—"
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: candidate.email }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [candidate.professional_details?.total_experience ?? "—", " yrs exp"] }),
									candidate.applied_from && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["via ", candidate.applied_from] })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "md:text-right flex md:flex-col gap-6 md:gap-2 pt-4 md:pt-0 border-t md:border-t-0 border-gray-100 mt-4 md:mt-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-bold uppercase tracking-widest text-[#86868b]",
								children: "Domain"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-[#1d1d1f]",
								children: domainCode || "—"
							})] }), bracketCode && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-bold uppercase tracking-widest text-[#86868b]",
								children: "Experience"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-bold text-[#1d1d1f]",
								children: bracketCode
							})] })]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] space-y-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-2",
					children: "Round Conclusion"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid sm:grid-cols-2 gap-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
								children: "Round number"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "number",
								min: 1,
								value: roundNumber,
								onChange: (e) => setRoundNumber(Number(e.target.value)),
								className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl py-3.5 px-4 text-sm font-bold text-[#1d1d1f] transition-all outline-none"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
								children: "Decision"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setStatus("COMPLETED"),
										className: `flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all ${status === "COMPLETED" ? "border-[#0066cc] bg-[#0066cc]/5 text-[#0066cc] shadow-sm" : "border-transparent bg-[#f5f5f7] text-[#86868b] hover:bg-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: `w-5 h-5 mb-1.5 ${status === "COMPLETED" ? "text-[#0066cc]" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-bold uppercase tracking-wide",
											children: "Select"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setStatus("HOLD"),
										className: `flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all ${status === "HOLD" ? "border-amber-500 bg-amber-50 text-amber-700 shadow-sm" : "border-transparent bg-[#f5f5f7] text-[#86868b] hover:bg-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePause, { className: `w-5 h-5 mb-1.5 ${status === "HOLD" ? "text-amber-500" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-bold uppercase tracking-wide",
											children: "Hold"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										onClick: () => setStatus("REJECTED"),
										className: `flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all ${status === "REJECTED" ? "border-red-500 bg-red-50 text-red-700 shadow-sm" : "border-transparent bg-[#f5f5f7] text-[#86868b] hover:bg-gray-200"}`,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: `w-5 h-5 mb-1.5 ${status === "REJECTED" ? "text-red-500" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-[10px] font-bold uppercase tracking-wide",
											children: "Reject"
										})]
									})
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: status === "COMPLETED" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							initial: {
								opacity: 0,
								height: 0
							},
							animate: {
								opacity: 1,
								height: "auto"
							},
							exit: {
								opacity: 0,
								height: 0
							},
							className: "space-y-2 sm:col-span-2 overflow-hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
								children: "Next interviewer email (optional routing)"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								value: nextInterviewer,
								onChange: (e) => setNextInterviewer(e.target.value),
								placeholder: "panel2@atlas.com",
								className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl py-3.5 px-4 text-sm font-bold text-[#1d1d1f] transition-all outline-none placeholder:font-medium placeholder:text-gray-400"
							})]
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2 sm:col-span-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
								children: "Overall remarks"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: remarks,
								onChange: (e) => setRemarks(e.target.value),
								placeholder: "Summary of the interview round…",
								rows: 3,
								className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl p-4 text-sm font-medium text-[#1d1d1f] transition-all outline-none resize-none placeholder:text-gray-400"
							})]
						})
					]
				})]
			}),
			totalQuestions > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-bold text-[#1d1d1f]",
							children: "Evaluation Progress"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-sm font-mono font-bold text-[#86868b]",
							children: [
								answeredQuestions,
								" / ",
								totalQuestions
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "w-full bg-[#f5f5f7] rounded-full h-3 overflow-hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `h-full transition-all duration-500 ease-out ${progressPercent === 100 ? "bg-emerald-500" : "bg-[#0066cc]"}`,
							style: { width: `${progressPercent}%` }
						})
					}),
					!allRated && answeredQuestions > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-bold text-amber-600 mt-4 flex items-center gap-2 bg-amber-50 px-3 py-2 rounded-lg w-fit",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleAlert, { className: "h-4 w-4" }), "All questions must be rated before submitting"]
					}),
					allRated && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-bold text-emerald-600 mt-4 flex items-center gap-2 bg-emerald-50 px-3 py-2 rounded-lg w-fit",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }), "All questions evaluated. Ready to submit."]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-6 flex items-center gap-2",
				children: "Interview Questions"
			}), topicsLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] space-y-6",
				children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-48 bg-gray-100 rounded-full animate-pulse" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-full bg-gray-100 rounded-xl animate-pulse" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 w-full bg-gray-100 rounded-xl animate-pulse" })
					]
				}, i))
			}) : topicGroups && topicGroups.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-6",
				children: topicGroups.map((group) => {
					const isExpanded = expandedCategories[group.topic_category] !== false;
					const groupAnswered = group.questions.filter((q) => responses[q.id]?.rating !== void 0 && responses[q.id]?.rating !== null).length;
					const isGroupComplete = groupAnswered === group.questions.length;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] overflow-hidden transition-all duration-300",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => toggleCategory(group.topic_category),
							className: "w-full p-6 flex items-center justify-between hover:bg-gray-50/50 transition-colors text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-8 w-8 rounded-full flex items-center justify-center transition-colors ${isExpanded ? "bg-[#f5f5f7] text-[#1d1d1f]" : "bg-transparent text-[#86868b]"}`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, { className: `h-5 w-5 transition-transform duration-300 ${isExpanded ? "" : "-rotate-90"}` })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-bold text-[#1d1d1f]",
									children: group.topic_category
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mt-0.5",
									children: [group.questions.length, " questions"]
								})] })]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-bold font-mono tracking-wide ${isGroupComplete ? "bg-emerald-50 text-emerald-700" : "bg-[#f5f5f7] text-[#86868b]"}`,
								children: [
									groupAnswered,
									"/",
									group.questions.length
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, {
							initial: false,
							children: isExpanded && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
								initial: {
									height: 0,
									opacity: 0
								},
								animate: {
									height: "auto",
									opacity: 1
								},
								exit: {
									height: 0,
									opacity: 0
								},
								transition: { duration: .3 },
								className: "overflow-hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "divide-y divide-gray-100 border-t border-gray-100 px-6",
									children: group.questions.map((question, qIdx) => {
										const r = responses[question.id] ?? {
											rating: null,
											comment: ""
										};
										return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "py-6 space-y-4",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-2",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "inline-flex items-center justify-center px-2 py-0.5 rounded text-[10px] font-bold font-mono text-[#0066cc] bg-[#0066cc]/10",
															children: question.question_id_code
														}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "inline-flex items-center justify-center px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest text-[#86868b] bg-[#f5f5f7]",
															children: question.module_code
														})]
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-base font-bold text-[#1d1d1f] leading-snug",
														children: question.question_topic
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex flex-col gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold text-[#86868b] uppercase tracking-wider",
														children: "Rating"
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "flex flex-wrap gap-2",
														children: RATING_OPTIONS.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
															type: "button",
															onClick: () => updateRating(question.id, opt.value),
															className: `px-4 py-2 rounded-xl text-xs font-bold transition-all border-2 ${r.rating === opt.value ? "bg-[#1d1d1f] text-white border-[#1d1d1f] shadow-sm" : "bg-[#f5f5f7] text-[#86868b] border-transparent hover:bg-gray-200"}`,
															children: [
																opt.value,
																" - ",
																opt.label
															]
														}, opt.value))
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "pt-2",
													children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
														value: r.comment,
														onChange: (e) => updateComment(question.id, e.target.value),
														placeholder: "Optional comment on this question…",
														rows: 2,
														className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl p-4 text-sm font-medium text-[#1d1d1f] transition-all outline-none resize-none placeholder:text-gray-400"
													})
												})
											]
										}, question.id);
									})
								})
							})
						})]
					}, group.topic_category);
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-bold text-[#86868b]",
					children: "No interview questions are available for the selected Domain and Experience Bracket."
				})
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col-reverse sm:flex-row justify-end gap-3 pb-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: `/interviewer/queue`,
					className: "inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-white border border-gray-200 text-[#1d1d1f] text-sm font-bold shadow-sm hover:bg-gray-50 transition-colors",
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					onClick: () => submit.mutate(),
					disabled: !allRated || submit.isPending,
					className: "inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4 mr-2" }), submit.isPending ? "Submitting..." : "Submit evaluation"]
				})]
			})
		]
	});
}
//#endregion
export { TechEval as component };
