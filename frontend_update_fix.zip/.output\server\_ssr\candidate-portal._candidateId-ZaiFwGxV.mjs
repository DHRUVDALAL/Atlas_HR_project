import { m as createFileRoute, p as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/candidate-portal._candidateId-ZaiFwGxV.js
var $$splitComponentImporter = () => import("./candidate-portal._candidateId-DGDQ3cvT.mjs");
var Route = createFileRoute("/candidate-portal/$candidateId")({
	head: () => ({ meta: [{ title: "Candidate Portal — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
