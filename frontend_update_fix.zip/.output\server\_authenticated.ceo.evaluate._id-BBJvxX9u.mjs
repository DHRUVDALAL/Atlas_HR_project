import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.ceo.evaluate._id-BBJvxX9u.js
var $$splitComponentImporter = () => import("./_authenticated.ceo.evaluate._id-VzbA2o6U.mjs");
var Route = createFileRoute("/_authenticated/ceo/evaluate/$id")({
	head: () => ({ meta: [{ title: "CEO Evaluation — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
