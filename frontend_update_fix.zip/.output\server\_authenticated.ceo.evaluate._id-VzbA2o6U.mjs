import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link, v as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { b as Save, bt as ArrowLeft, ft as ChartColumn, ht as Briefcase, i as User, l as TrendingUp, m as Star, p as Target, q as Crown, u as TrendingDown, v as Send } from "./_libs/lucide-react.mjs";
import { t as CEO_DIMENSIONS } from "./_ssr/scorecard-YpVMHDsm.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
import { t as Route } from "./_authenticated.ceo.evaluate._id-BBJvxX9u.mjs";
import { n as useScorecard, t as ScorecardEditor } from "./_ssr/scorecard-D-ENrYNz.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.ceo.evaluate._id-VzbA2o6U.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CeoEval() {
	const { id } = Route.useParams();
	const nav = useNavigate();
	const qc = useQueryClient();
	const { data: candidate, isLoading: candidateLoading } = useQuery({
		queryKey: ["candidate", id],
		queryFn: () => api(`/api/applicants/${id}`).then((r) => r.data)
	});
	const { data: assignment } = useQuery({
		queryKey: [
			"interview",
			"assignment",
			id
		],
		queryFn: () => api(`/api/interview/assignment/${id}`).then((r) => r.assignment),
		enabled: !!id
	});
	const { data: interviewScore } = useQuery({
		queryKey: [
			"interview",
			"result",
			id
		],
		queryFn: () => api(`/api/interview/result/${id}`).then((r) => r.score),
		enabled: !!id
	});
	const { data: interviewSummary } = useQuery({
		queryKey: [
			"interview",
			"summary",
			id
		],
		queryFn: () => api(`/api/interview/summary/${id}`).then((r) => r.summary?.summary_json),
		enabled: !!id
	});
	const { state, update, isComplete } = useScorecard(CEO_DIMENSIONS);
	const [remarks, setRemarks] = (0, import_react.useState)("");
	const submit = useMutation({
		mutationFn: (saveDraft) => api(`/api/workflow/ceo/evaluate/${id}`, {
			method: "POST",
			body: {
				remarks: remarks || "No remarks provided",
				evaluation_data: state,
				save_draft: saveDraft
			}
		}),
		onSuccess: (_, saveDraft) => {
			toast.success(saveDraft ? "Draft saved" : "CEO evaluation submitted");
			qc.invalidateQueries();
			nav({ to: saveDraft ? `/ceo/queue` : `/candidates/${id}` });
		},
		onError: (e) => toast.error(e instanceof Error ? e.message : "Failed")
	});
	if (candidateLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-10 max-w-5xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-40 bg-gray-100 rounded-full animate-pulse" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-64 bg-gray-100 rounded-full animate-pulse" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-48 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-32 bg-gray-100 rounded-full animate-pulse" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-full bg-gray-100 rounded-xl animate-pulse" }, i))
			})
		]
	});
	const topicScores = interviewScore?.topic_scores ?? {};
	const overallPct = interviewScore?.overall_percentage ?? 0;
	const recommendation = interviewScore?.recommendation ?? "N/A";
	const highestTopic = interviewScore?.highest_topic;
	const weakestTopic = interviewScore?.weakest_topic;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-5xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/ceo/queue",
					className: "flex items-center text-sm font-bold text-[#86868b] hover:text-[#1d1d1f] transition-colors",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-8 w-8 rounded-full bg-[#f5f5f7] flex items-center justify-center mr-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4" })
					}), "Back to queue"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: `/candidates/${id}`,
					className: "flex items-center text-sm font-bold text-[#86868b] hover:text-[#1d1d1f] transition-colors bg-[#f5f5f7] px-4 py-1.5 rounded-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "h-3.5 w-3.5 mr-1.5" }), " View profile"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-3xl font-bold tracking-tighter text-[#1d1d1f] flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-12 w-12 rounded-2xl bg-indigo-50 flex items-center justify-center shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-6 w-6 text-indigo-600" })
				}), "CEO Evaluation"]
			}), candidate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-medium text-[#86868b] mt-2 ml-[3.75rem]",
				children: ["Executive scorecard for ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-bold text-[#1d1d1f]",
					children: candidate.application_number
				})]
			})] }),
			candidate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col md:flex-row md:items-center gap-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-16 w-16 rounded-full bg-[#f5f5f7] flex items-center justify-center text-xl font-bold text-[#1d1d1f] shrink-0 border-2 border-white shadow-sm",
						children: [candidate.first_name[0], candidate.last_name[0]]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-xl font-bold tracking-tight text-[#1d1d1f] flex items-center gap-3",
							children: [
								candidate.first_name,
								" ",
								candidate.last_name,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "inline-flex items-center justify-center rounded-full bg-indigo-50 px-3 py-1 text-[10px] font-bold tracking-wide text-indigo-700 uppercase",
									children: "CEO Round"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-sm font-medium text-[#86868b] mt-1 flex flex-wrap items-center gap-x-4 gap-y-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-1.5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" }),
										" ",
										candidate.position_applied_for ?? "—"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: candidate.email }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [candidate.professional_details?.total_experience ?? "—", " yrs exp"] }),
								candidate.applied_from && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["via ", candidate.applied_from] })
							]
						})]
					})]
				})
			}),
			interviewScore ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-6 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "h-5 w-5 text-[#0066cc]" }), "Technical Interview Results"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-5 bg-[#fbfbfd] rounded-2xl border border-gray-100",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
									children: [overallPct.toFixed(1), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xl text-[#86868b]",
										children: "%"
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mt-2",
									children: "Overall Score"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-5 bg-[#fbfbfd] rounded-2xl border border-gray-100",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
									children: [interviewScore.answered_questions, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-xl text-[#86868b]",
										children: ["/", interviewScore.total_questions]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mt-2",
									children: "Questions Rated"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-5 bg-[#fbfbfd] rounded-2xl border border-gray-100",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
									children: interviewScore.average_rating?.toFixed(1) ?? "—"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mt-2",
									children: "Avg Rating"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-5 bg-[#fbfbfd] rounded-2xl border border-gray-100 flex flex-col justify-center items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-wider ${recommendation === "Excellent" || recommendation === "Very Strong" ? "bg-emerald-50 text-emerald-700" : recommendation === "Needs Improvement" ? "bg-red-50 text-red-700" : "bg-gray-200 text-gray-800"}`,
									children: recommendation
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mt-3",
									children: "Recommendation"
								})]
							})
						]
					}),
					assignment && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-6 p-4 bg-[#f5f5f7] rounded-xl text-sm font-medium text-[#86868b] mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Domain: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-[#1d1d1f]",
							children: assignment.domain_code
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Experience: ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
							className: "text-[#1d1d1f]",
							children: assignment.experience_bracket_code
						})] })]
					}),
					Object.keys(topicScores).length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4 mb-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
							className: "text-sm font-bold text-[#1d1d1f] uppercase tracking-wider flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, { className: "h-4 w-4 text-[#86868b]" }), " Topic Breakdown"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid gap-4",
							children: Object.entries(topicScores).sort(([, a], [, b]) => b - a).map(([topic, score]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 min-w-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-bold text-[#1d1d1f] truncate mb-1.5",
										children: topic
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-full bg-[#f5f5f7] rounded-full h-2 overflow-hidden",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "bg-[#0066cc] h-full rounded-full transition-all duration-1000",
											style: { width: `${score / 5 * 100}%` }
										})
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-sm font-bold text-[#86868b] shrink-0 mt-6",
									children: [score.toFixed(1), "/5"]
								})]
							}, topic))
						})]
					}),
					(highestTopic || weakestTopic) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid sm:grid-cols-2 gap-4 mb-8 border-t border-gray-100 pt-8",
						children: [highestTopic && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3 p-4 bg-emerald-50 rounded-2xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-8 w-8 rounded-full bg-emerald-100 flex items-center justify-center shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingUp, { className: "h-4 w-4 text-emerald-600" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-bold text-emerald-700 uppercase tracking-widest mb-0.5",
								children: "Strongest Topic"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-[#1d1d1f]",
								children: highestTopic
							})] })]
						}), weakestTopic && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3 p-4 bg-red-50 rounded-2xl",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-8 w-8 rounded-full bg-red-100 flex items-center justify-center shrink-0",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TrendingDown, { className: "h-4 w-4 text-red-600" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[10px] font-bold text-red-700 uppercase tracking-widest mb-0.5",
								children: "Weakest Topic"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-[#1d1d1f]",
								children: weakestTopic
							})] })]
						})]
					}),
					interviewSummary?.overall_remarks && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-gray-100 pt-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider mb-3",
							children: "Interviewer Remarks"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-[#fbfbfd] p-5 rounded-2xl border border-gray-100 text-sm font-medium text-[#1d1d1f] leading-relaxed",
							children: interviewSummary.overall_remarks
						})]
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-12 rounded-[2.5rem] border border-gray-100 text-center shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartColumn, { className: "h-10 w-10 text-gray-200 mx-auto mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-[#86868b]",
					children: "No technical interview results available yet."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-xl font-bold tracking-tight text-[#1d1d1f] mb-1 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-5 w-5 text-indigo-600" }), "Executive Scorecard"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-[#86868b] mb-8",
						children: "Rate each dimension on a scale of 1-5."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScorecardEditor, {
							dimensions: CEO_DIMENSIONS,
							scorecard: state,
							onUpdate: update
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-3 pt-6 border-t border-gray-100",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
								className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
								children: "Executive Remarks (Required, min 5 chars)"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
								value: remarks,
								onChange: (e) => setRemarks(e.target.value),
								placeholder: "Provide your executive assessment of this candidate…",
								rows: 4,
								className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl p-4 text-sm text-[#1d1d1f] transition-all outline-none resize-none"
							}),
							remarks.length > 0 && remarks.length < 5 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-bold text-red-500 uppercase tracking-wide pl-1",
								children: "Minimum 5 characters required"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col-reverse sm:flex-row justify-between gap-4 pt-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/ceo/queue",
					className: "inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-white border border-gray-200 text-[#1d1d1f] text-sm font-bold shadow-sm hover:bg-gray-50 transition-colors",
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col sm:flex-row gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => submit.mutate(true),
						disabled: remarks.length < 5 || submit.isPending,
						className: "inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-white border border-gray-200 text-[#1d1d1f] text-sm font-bold shadow-sm hover:bg-gray-50 transition-colors disabled:opacity-50",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4 mr-2" }), " Save Draft"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => submit.mutate(false),
						disabled: !isComplete || remarks.length < 5 || submit.isPending,
						className: "inline-flex items-center justify-center px-8 py-3.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4 mr-2" }), " Submit Evaluation"]
					})]
				})]
			})
		]
	});
}
//#endregion
export { CeoEval as component };
