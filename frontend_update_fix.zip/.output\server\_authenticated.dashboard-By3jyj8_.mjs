import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { n as useAuth } from "./_ssr/auth-Ba-lKRMp.mjs";
import { n as safeDate } from "./_ssr/utils-BjLc2HNT.mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { F as Inbox, J as Copy, L as Gavel, V as FileCheck, Z as ClipboardCheck, a as UserPlus, j as ListChecks, pt as Calendar, q as Crown, r as Users, rt as CircleCheckBig, s as UserCheck, tt as CirclePause, v as Send, yt as ArrowRight, z as FolderOpen } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { i as statusMeta } from "./_ssr/scorecard-YpVMHDsm.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
import { t as Card } from "./_ssr/card-CIRKiXmB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.dashboard-By3jyj8_.js
var import_jsx_runtime = require_jsx_runtime();
function greet() {
	const h = (/* @__PURE__ */ new Date()).getHours();
	if (h < 12) return "Good morning";
	if (h < 17) return "Good afternoon";
	return "Good evening";
}
function isToday(dateString) {
	const d = safeDate(dateString);
	if (!d) return false;
	const now = /* @__PURE__ */ new Date();
	return d.getDate() === now.getDate() && d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
}
function Dashboard() {
	const { user, hasAnyRole, hasAnyPermission } = useAuth();
	const { data: all, isLoading } = useQuery({
		queryKey: ["applicants", "all"],
		queryFn: () => api("/api/applicants?limit=500").then((r) => r.applicants ?? []),
		enabled: hasAnyPermission(["candidate.list"]),
		retry: false
	});
	const list = all ?? [];
	const count = (s) => list.filter((c) => c.status === s).length;
	const SUBMITTED_STATUSES = [
		"DRAFT",
		"SUBMITTED",
		"Submitted — awaiting reception"
	];
	const countAwaiting = list.filter((c) => SUBMITTED_STATUSES.includes(c.status)).length;
	const countArrivedToday = list.filter((c) => !SUBMITTED_STATUSES.includes(c.status) && isToday(c.updated_at)).length;
	const countAppsToday = list.filter((c) => isToday(c.created_at)).length;
	const countForwardedToHr = count("RECEPTION_FORWARDED");
	const countTechRounds = list.filter((c) => c.status.startsWith("TECHNICAL_")).length;
	const countCeoRound = count("CEO_ROUND");
	const countFinalDiscussion = count("FINAL_DISCUSSION_PENDING");
	const countSelected = count("SELECTED");
	const countOnHold = count("ON_HOLD");
	const countRejected = count("REJECTED");
	const kpis = [
		{
			label: "Total",
			value: list.length,
			icon: Users,
			tint: "text-info",
			bg: "bg-info/10"
		},
		{
			label: "Awaiting Check-in",
			value: countAwaiting,
			icon: Inbox,
			tint: "text-blue-600",
			bg: "bg-blue-50"
		},
		{
			label: "Arrived Today",
			value: countArrivedToday,
			icon: CircleCheckBig,
			tint: "text-emerald-600",
			bg: "bg-emerald-50"
		},
		{
			label: "Awaiting HR",
			value: countForwardedToHr,
			icon: Send,
			tint: "text-violet-600",
			bg: "bg-violet-50"
		},
		{
			label: "Technical",
			value: countTechRounds,
			icon: ClipboardCheck,
			tint: "text-purple-600",
			bg: "bg-purple-50"
		},
		{
			label: "CEO Review",
			value: countCeoRound,
			icon: Crown,
			tint: "text-indigo-600",
			bg: "bg-indigo-50"
		},
		{
			label: "Selected",
			value: countSelected,
			icon: CircleCheckBig,
			tint: "text-green-600",
			bg: "bg-green-50"
		},
		{
			label: "On Hold",
			value: countOnHold,
			icon: CirclePause,
			tint: "text-amber-600",
			bg: "bg-amber-50"
		}
	];
	const isReception = hasAnyRole(["RECEPTIONIST", "SYSTEM_ADMIN"]);
	const isHr = hasAnyRole(["HR_ADMIN", "SYSTEM_ADMIN"]);
	const isInterviewer = hasAnyRole([
		"L1_PANEL",
		"L2_PANEL",
		"TECH_HEAD"
	]);
	const isCeo = hasAnyRole(["CEO", "SYSTEM_ADMIN"]);
	const { data: assignments, isLoading: assignmentsLoading } = useQuery({
		queryKey: ["assignments", "my"],
		queryFn: () => api("/api/workflow/my-assignments?only_pending=true").then((r) => r.assignments ?? []),
		enabled: isInterviewer
	});
	const assignmentList = assignments ?? [];
	const assignedTotal = assignmentList.length;
	const assignedToday = assignmentList.filter((a) => {
		const d = safeDate(a.assigned_at);
		if (!d) return false;
		return isToday(d.toISOString());
	}).length;
	const { data: offerStats } = useQuery({
		queryKey: ["offers", "stats"],
		queryFn: () => api("/api/offers/stats").then((r) => r.data),
		enabled: isHr && hasAnyPermission(["decision.final"])
	});
	const { data: onboardingStats } = useQuery({
		queryKey: ["onboarding", "stats"],
		queryFn: () => api("/api/onboarding/stats").then((r) => r.data),
		enabled: isHr && hasAnyPermission(["decision.final"])
	});
	const selectedList = list.filter((c) => c.status === "SELECTED");
	offerStats ? offerStats.pending : selectedList.length;
	onboardingStats ? onboardingStats.pending : selectedList.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rounded-3xl bg-white border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] p-8 lg:p-10 relative overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "text-3xl lg:text-4xl font-bold tracking-tighter text-[#1d1d1f] relative",
						children: [
							greet(),
							", ",
							user?.first_name,
							" 👋"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm font-medium text-[#86868b] mt-2 relative",
						children: [
							"Today is",
							" ",
							(/* @__PURE__ */ new Date()).toLocaleDateString(void 0, {
								weekday: "long",
								year: "numeric",
								month: "long",
								day: "numeric"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-8 mt-8 relative",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "New Applications"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-mono tracking-tight text-[#1d1d1f] mt-1",
								children: countAppsToday
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px bg-gray-100" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "Candidates Waiting"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-mono tracking-tight text-[#1d1d1f] mt-1",
								children: countAwaiting
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px bg-gray-100" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "Active Interviews"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-mono tracking-tight text-[#1d1d1f] mt-1",
								children: countTechRounds + countCeoRound
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px bg-gray-100" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "Pending HR Reviews"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-mono tracking-tight text-[#1d1d1f] mt-1",
								children: countForwardedToHr
							})] })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [
					isReception && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/register-candidate",
						className: "flex items-center bg-[#1d1d1f] text-white hover:bg-black rounded-full px-6 py-2.5 text-sm font-medium shadow-sm transition-all active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4 mr-2" }), " Register Candidate"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "flex items-center bg-transparent hover:bg-gray-100 text-[#1d1d1f] border border-gray-200 rounded-full px-6 py-2.5 text-sm font-medium transition-colors active:scale-[0.98]",
						onClick: () => {
							const url = `${window.location.origin}/register-candidate`;
							navigator.clipboard.writeText(url);
							toast.success("Registration link copied");
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "h-4 w-4 mr-2" }), " Copy Registration Link"]
					})] }),
					isHr && hasAnyPermission(["workflow.hr_review", "candidate.list"]) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/hr/queue",
						className: "flex items-center bg-[#1d1d1f] text-white hover:bg-black rounded-full px-6 py-2.5 text-sm font-medium shadow-sm transition-all active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardCheck, { className: "h-4 w-4 mr-2" }), " HR Review Queue"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/candidates",
						className: "flex items-center bg-transparent hover:bg-gray-100 text-[#1d1d1f] border border-gray-200 rounded-full px-6 py-2.5 text-sm font-medium transition-colors active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "h-4 w-4 mr-2" }), " Full Directory"]
					})] }),
					isInterviewer && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/interviewer/queue",
						className: "flex items-center bg-[#1d1d1f] text-white hover:bg-black rounded-full px-6 py-2.5 text-sm font-medium shadow-sm transition-all active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "h-4 w-4 mr-2" }), " Interview Queue"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/candidates",
						className: "flex items-center bg-transparent hover:bg-gray-100 text-[#1d1d1f] border border-gray-200 rounded-full px-6 py-2.5 text-sm font-medium transition-colors active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "h-4 w-4 mr-2" }), " Candidate Directory"]
					})] }),
					isCeo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/ceo/queue",
						className: "flex items-center bg-[#1d1d1f] text-white hover:bg-black rounded-full px-6 py-2.5 text-sm font-medium shadow-sm transition-all active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Crown, { className: "h-4 w-4 mr-2" }), " CEO Review Queue"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/candidates",
						className: "flex items-center bg-transparent hover:bg-gray-100 text-[#1d1d1f] border border-gray-200 rounded-full px-6 py-2.5 text-sm font-medium transition-colors active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "h-4 w-4 mr-2" }), " Candidate Directory"]
					})] }),
					isHr && hasAnyPermission(["decision.final"]) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/offer/dashboard",
						className: "flex items-center bg-transparent hover:bg-gray-100 text-[#1d1d1f] border border-gray-200 rounded-full px-6 py-2.5 text-sm font-medium transition-colors active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-4 w-4 mr-2" }), " Offer Management"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/onboarding/dashboard",
						className: "flex items-center bg-transparent hover:bg-gray-100 text-[#1d1d1f] border border-gray-200 rounded-full px-6 py-2.5 text-sm font-medium transition-colors active:scale-[0.98]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4 mr-2" }), " Onboarding"]
					})] })
				]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-4",
				children: Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-20 mb-4" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-12 mb-2" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-24" })
					]
				}, i))
			}) : isCeo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: [
					{
						label: "CEO Pending",
						value: countCeoRound,
						icon: Crown,
						tint: "text-indigo-600",
						bg: "bg-indigo-50"
					},
					{
						label: "Final Discussion",
						value: countFinalDiscussion,
						icon: Gavel,
						tint: "text-amber-600",
						bg: "bg-amber-50"
					},
					{
						label: "Selected",
						value: countSelected,
						icon: CircleCheckBig,
						tint: "text-green-600",
						bg: "bg-green-50"
					},
					{
						label: "Rejected",
						value: countRejected,
						icon: CirclePause,
						tint: "text-red-600",
						bg: "bg-red-50"
					}
				].map((k) => {
					const Icon = k.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: k.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: k.value
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `h-10 w-10 rounded-2xl ${k.bg} grid place-items-center`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `h-5 w-5 ${k.tint}` })
							})]
						})
					}, k.label);
				})
			}) : isInterviewer ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: [
					{
						label: "Assigned Interviews",
						value: assignedTotal,
						icon: ListChecks,
						tint: "text-blue-600",
						bg: "bg-blue-50"
					},
					{
						label: "Assigned Today",
						value: assignedToday,
						icon: Calendar,
						tint: "text-violet-600",
						bg: "bg-violet-50"
					},
					{
						label: "Technical Queue",
						value: countTechRounds,
						icon: ClipboardCheck,
						tint: "text-purple-600",
						bg: "bg-purple-50"
					},
					{
						label: "CEO Queue",
						value: countCeoRound,
						icon: Crown,
						tint: "text-indigo-600",
						bg: "bg-indigo-50"
					}
				].map((k) => {
					const Icon = k.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: k.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: k.value
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `h-10 w-10 rounded-2xl ${k.bg} grid place-items-center`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `h-5 w-5 ${k.tint}` })
							})]
						})
					}, k.label);
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-4 gap-4",
				children: kpis.map((k) => {
					const Icon = k.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: k.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: k.value
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `h-10 w-10 rounded-2xl ${k.bg} grid place-items-center`,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `h-5 w-5 ${k.tint}` })
							})]
						})
					}, k.label);
				})
			}),
			isReception && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueWidget, {
				title: "Reception check-in queue",
				description: "Candidates who have submitted and are awaiting arrival check-in.",
				list: list.filter((c) => SUBMITTED_STATUSES.includes(c.status)),
				actionLabel: "Open",
				hrefBuilder: (c) => `/candidates/${c.candidate_id}`,
				icon: Inbox
			}),
			isHr && hasAnyPermission(["workflow.hr_review", "candidate.list"]) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueWidget, {
				title: "Pending HR screenings",
				description: "Candidates forwarded from reception awaiting your recruiter review.",
				list: list.filter((c) => c.status === "RECEPTION_FORWARDED"),
				actionLabel: "Review",
				hrefBuilder: (c) => `/hr/review/${c.candidate_id}`,
				icon: ClipboardCheck
			}),
			isInterviewer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AssignmentWidget, {
				title: "Your assigned interviews",
				description: "Interviews assigned to you that are pending evaluation.",
				assignments: assignmentList,
				isLoading: assignmentsLoading,
				actionLabel: "Evaluate",
				hrefBuilder: (a) => `/interviewer/evaluate/${a.candidate_id}`,
				icon: UserCheck
			}),
			isCeo && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueWidget, {
				title: "CEO evaluation queue",
				description: "Candidates awaiting your executive review.",
				list: list.filter((c) => c.status === "CEO_ROUND"),
				actionLabel: "Evaluate",
				hrefBuilder: (c) => `/ceo/evaluate/${c.candidate_id}`,
				icon: Crown
			}),
			isCeo && hasAnyPermission(["decision.final"]) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueWidget, {
				title: "Final decisions pending",
				description: "Aggregate all panel feedback and release the offer, hold, or reject.",
				list: list.filter((c) => c.status === "FINAL_DISCUSSION_PENDING"),
				actionLabel: "Decide",
				hrefBuilder: (c) => `/final-decision/${c.candidate_id}`,
				icon: Gavel
			}),
			isHr && hasAnyPermission(["decision.final"]) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueWidget, {
				title: "Offer management queue",
				description: "Selected candidates awaiting offer letter generation and status tracking.",
				list: selectedList,
				actionLabel: "Build Offer",
				hrefBuilder: (c) => `/offer/builder/${c.candidate_id}`,
				icon: FileCheck
			}),
			isHr && hasAnyPermission(["decision.final"]) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueueWidget, {
				title: "Onboarding queue",
				description: "Selected candidates awaiting onboarding process initiation.",
				list: selectedList,
				actionLabel: "Start Onboarding",
				hrefBuilder: (c) => `/onboarding/${c.candidate_id}`,
				icon: UserPlus
			}),
			!isReception && !isHr && !isInterviewer && !isCeo && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-12 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-lg font-semibold",
					children: "Nothing to show yet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground mt-1",
					children: "You don't have any dashboard modules assigned. Contact your administrator."
				})]
			})
		]
	});
}
function QueueWidget({ title, description, list, actionLabel, hrefBuilder, icon: Icon = Users }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-white rounded-[2rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-6 md:p-8 border-b border-gray-100 flex items-start justify-between gap-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-[#1d1d1f]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold tracking-tight text-[#1d1d1f]",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 inline-flex items-center justify-center bg-[#f5f5f7] text-[#1d1d1f] rounded-full px-2.5 py-0.5 text-xs font-bold tracking-wide",
						children: list.length
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-[#86868b] mt-1.5",
				children: description
			})] })
		}), list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-12 text-center text-sm font-medium text-[#86868b]",
			children: "No candidates in this queue."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col",
			children: list.slice(0, 8).map((c) => {
				const s = statusMeta(c.status);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1fr_auto_auto] gap-6 px-6 md:px-8 py-5 border-b border-gray-50/50 hover:bg-[#f5f5f7]/60 transition-colors items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-sm font-bold text-[#1d1d1f] truncate",
								children: [
									c.first_name,
									" ",
									c.last_name
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
								children: [
									c.application_number,
									" · ",
									c.position_applied_for ?? "—",
									" · ",
									c.email
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-semibold tracking-wide ${s.className}`,
							children: s.label
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: hrefBuilder(c),
							className: "flex items-center bg-transparent border border-gray-200 hover:bg-gray-100 text-[#1d1d1f] rounded-full px-5 py-2 text-xs font-bold transition-all active:scale-[0.98]",
							children: [
								actionLabel,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 ml-1.5" })
							]
						})
					]
				}, c.candidate_id);
			})
		})]
	});
}
function AssignmentWidget({ title, description, assignments, isLoading, actionLabel, hrefBuilder, icon: Icon = Users }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-white rounded-[2rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-6 md:p-8 border-b border-gray-100 flex items-start justify-between gap-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5 text-[#1d1d1f]" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-bold tracking-tight text-[#1d1d1f]",
						children: title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 inline-flex items-center justify-center bg-[#f5f5f7] text-[#1d1d1f] rounded-full px-2.5 py-0.5 text-xs font-bold tracking-wide",
						children: assignments.length
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-[#86868b] mt-1.5",
				children: description
			})] })
		}), isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-6 space-y-4",
			children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-10 rounded-full" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 space-y-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-60" })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-24 rounded-full" })
				]
			}, i))
		}) : assignments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-12 text-center text-sm font-medium text-[#86868b]",
			children: "No pending assignments."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col",
			children: assignments.slice(0, 8).map((a) => {
				const s = statusMeta(a.status);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1fr_auto_auto] gap-6 px-6 md:px-8 py-5 border-b border-gray-50/50 hover:bg-[#f5f5f7]/60 transition-colors items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-sm font-bold text-[#1d1d1f] truncate",
								children: a.candidate_name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
								children: [
									a.position ?? "—",
									" · ",
									a.domain ?? "—",
									" · Round ",
									a.round_number
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-semibold tracking-wide ${s.className}`,
							children: s.label
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: hrefBuilder(a),
							className: "flex items-center bg-transparent border border-gray-200 hover:bg-gray-100 text-[#1d1d1f] rounded-full px-5 py-2 text-xs font-bold transition-all active:scale-[0.98]",
							children: [
								actionLabel,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 ml-1.5" })
							]
						})
					]
				}, a.assignment_id);
			})
		})]
	});
}
//#endregion
export { Dashboard as component };
