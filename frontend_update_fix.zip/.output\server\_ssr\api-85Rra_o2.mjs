//#region node_modules/.nitro/vite/services/ssr/assets/api-85Rra_o2.js
typeof window !== "undefined" && window.location.hostname;
var API_BASE_URL = "http://localhost:8001";
var ACCESS_KEY = "atlas.access_token";
var REFRESH_KEY = "atlas.refresh_token";
var USER_KEY = "atlas.user";
function getAccessToken() {
	if (typeof window === "undefined") return null;
	return localStorage.getItem(ACCESS_KEY);
}
function getRefreshToken() {
	if (typeof window === "undefined") return null;
	return localStorage.getItem(REFRESH_KEY);
}
function setTokens(access, refresh) {
	localStorage.setItem(ACCESS_KEY, access);
	if (refresh) localStorage.setItem(REFRESH_KEY, refresh);
}
function clearAuth() {
	localStorage.removeItem(ACCESS_KEY);
	localStorage.removeItem(REFRESH_KEY);
	localStorage.removeItem(USER_KEY);
}
function setStoredUser(user) {
	localStorage.setItem(USER_KEY, JSON.stringify(user));
}
async function refreshAccessToken() {
	const refresh_token = getRefreshToken();
	if (!refresh_token) return null;
	const res = await fetch(`${API_BASE_URL}/api/auth/refresh`, {
		method: "POST",
		headers: { "Content-Type": "application/json" },
		body: JSON.stringify({ refresh_token })
	});
	if (!res.ok) return null;
	const data = await res.json();
	setTokens(data.access_token);
	return data.access_token;
}
async function api(path, opts = {}) {
	const { body, raw, auth = true, headers, ...rest } = opts;
	const url = `${API_BASE_URL}${path}`;
	const buildHeaders = (token) => {
		const h = { ...headers };
		if (!raw && body !== void 0 && !(body instanceof FormData)) h["Content-Type"] = h["Content-Type"] ?? "application/json";
		if (auth && token) h["Authorization"] = `Bearer ${token}`;
		return h;
	};
	const doFetch = async (token) => {
		const finalBody = raw ? body : body instanceof FormData ? body : body !== void 0 ? JSON.stringify(body) : void 0;
		try {
			return await fetch(url, {
				...rest,
				headers: buildHeaders(token),
				body: finalBody
			});
		} catch (e) {
			throw new ApiError(`Cannot reach backend at ${API_BASE_URL}. Set VITE_API_BASE_URL to your FastAPI URL.`, 0, e);
		}
	};
	let res = await doFetch(auth ? getAccessToken() : null);
	if (res.status === 401 && auth) {
		const newToken = await refreshAccessToken();
		if (newToken) res = await doFetch(newToken);
		else {
			clearAuth();
			if (typeof window !== "undefined" && !window.location.pathname.startsWith("/login")) window.location.href = "/login";
		}
	}
	if (!res.ok) {
		let detail = null;
		try {
			detail = await res.json();
		} catch {}
		const msg = detail?.detail ?? `Request failed with status ${res.status}`;
		throw new ApiError(typeof msg === "string" ? msg : "Request failed", res.status, detail);
	}
	if (res.status === 204) return void 0;
	return await res.json();
}
var ApiError = class extends Error {
	status;
	detail;
	constructor(message, status, detail) {
		super(message);
		this.status = status;
		this.detail = detail;
	}
};
//#endregion
export { getRefreshToken as a, getAccessToken as i, api as n, setStoredUser as o, clearAuth as r, setTokens as s, API_BASE_URL as t };
