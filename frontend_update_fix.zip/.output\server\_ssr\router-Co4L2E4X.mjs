import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as AuthProvider } from "./auth-Ba-lKRMp.mjs";
import { t as Button } from "./button-B_S4Wnqd.mjs";
import { c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { r as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
import { t as Route$18 } from "../_authenticated.candidates._id-DxqivG3D.mjs";
import { t as Route$19 } from "../_authenticated.ceo.evaluate._id-BBJvxX9u.mjs";
import { t as Route$20 } from "../_authenticated.final-decision._id-BrrAJ0vB.mjs";
import { t as Route$21 } from "../_authenticated.hr.review._id-CQuafpWt.mjs";
import { t as Route$22 } from "../_authenticated.interviewer.evaluate._id-CZEBw3EA.mjs";
import { t as Route$23 } from "../_authenticated.interviewer.review._id-IO8F3QfN.mjs";
import { t as Route$24 } from "../_authenticated.offer._candidateId-DHSIt-Ws.mjs";
import { t as Route$25 } from "../_authenticated.offer.builder._candidateId-Bu_sxfKN.mjs";
import { t as Route$26 } from "../_authenticated.offer.preview._candidateId-DNTJHrTN.mjs";
import { t as Route$27 } from "../_authenticated.offer.status._candidateId-Dg_YY84G.mjs";
import { t as Route$28 } from "../_authenticated.onboarding._candidateId-DlpjqSBk.mjs";
import { t as Route$29 } from "../_authenticated.final-discussion._id-yQbVexvX.mjs";
import { t as Route$30 } from "./candidate-portal._candidateId-ZaiFwGxV.mjs";
import { t as Route$31 } from "./register-candidate-BIg2WqKn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-Co4L2E4X.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var styles_default = "/assets/styles-CQdKnaKJ.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
}
var Toaster$1 = ({ ...props }) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
			description: "group-[.toast]:text-muted-foreground",
			actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
			cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
		} },
		...props
	});
};
var ErrorBoundary = class extends import_react.Component {
	constructor(props) {
		super(props);
		this.state = {
			hasError: false,
			error: null
		};
	}
	static getDerivedStateFromError(error) {
		return {
			hasError: true,
			error
		};
	}
	componentDidCatch(error, errorInfo) {
		console.error("ErrorBoundary caught:", error, errorInfo);
	}
	render() {
		if (this.state.hasError) {
			if (this.props.fallback) return this.props.fallback;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex min-h-[200px] items-center justify-center rounded-lg border border-destructive/20 bg-destructive/5 p-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg font-semibold text-destructive",
							children: "Something went wrong"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted-foreground",
							children: this.state.error?.message || "An unexpected error occurred"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							className: "mt-4",
							onClick: () => this.setState({
								hasError: false,
								error: null
							}),
							children: "Try again"
						})
					]
				})
			});
		}
		return this.props.children;
	}
};
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$17 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Atlas HR — Recruitment Management" },
			{
				name: "description",
				content: "Atlas HR Recruitment Management System — enterprise applicant tracking with multi-stage panel evaluations and role-based dashboards."
			},
			{
				property: "og:title",
				content: "Atlas HR — Recruitment Management"
			},
			{
				property: "og:description",
				content: "Enterprise ATS: registration, reception check-in, HR screening, technical panels, CEO review, and final decisions."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [{
			rel: "stylesheet",
			href: styles_default
		}, {
			rel: "stylesheet",
			href: "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
		}]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$17.useRouteContext();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ErrorBoundary, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {
			richColors: true,
			position: "top-right"
		})] })
	});
}
var $$splitComponentImporter$16 = () => import("./login-1NVFmtJK.mjs");
var Route$16 = createFileRoute("/login")({
	head: () => ({ meta: [{ title: "Sign in — Atlas HR" }, {
		name: "description",
		content: "Sign in to the Atlas HR recruitment management console."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$16, "component")
});
var $$splitComponentImporter$15 = () => import("../_authenticated-DH762YDN.mjs");
var Route$15 = createFileRoute("/_authenticated")({
	ssr: false,
	component: lazyRouteComponent($$splitComponentImporter$15, "component")
});
var $$splitComponentImporter$14 = () => import("./routes-Db8pX8Xj.mjs");
var Route$14 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("../_authenticated.users-bAmSsuZq.mjs");
var Route$13 = createFileRoute("/_authenticated/users")({
	head: () => ({ meta: [{ title: "Employee Management — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component")
});
var $$splitComponentImporter$12 = () => import("../_authenticated.settings-Bpt7Dpdp.mjs");
var Route$12 = createFileRoute("/_authenticated/settings")({ component: lazyRouteComponent($$splitComponentImporter$12, "component") });
var $$splitComponentImporter$11 = () => import("../_authenticated.scheduler-CllNqKHi.mjs");
var Route$11 = createFileRoute("/_authenticated/scheduler")({
	head: () => ({ meta: [{ title: "Scheduler — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$11, "component")
});
var $$splitComponentImporter$10 = () => import("../_authenticated.reports-CGR-hueH.mjs");
var Route$10 = createFileRoute("/_authenticated/reports")({
	head: () => ({ meta: [{ title: "Reports — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$10, "component")
});
var $$splitComponentImporter$9 = () => import("../_authenticated.email-management-DEkKiIJb.mjs");
var Route$9 = createFileRoute("/_authenticated/email-management")({
	head: () => ({ meta: [{ title: "Email Management — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
var $$splitComponentImporter$8 = () => import("../_authenticated.dashboard-By3jyj8_.mjs");
var Route$8 = createFileRoute("/_authenticated/dashboard")({
	head: () => ({ meta: [{ title: "Dashboard — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("../_authenticated.candidates-BtyM095A.mjs");
var Route$7 = createFileRoute("/_authenticated/candidates")({
	head: () => ({ meta: [{ title: "Candidates — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("../_authenticated.onboarding.queue-ylZ9nQQt.mjs");
var Route$6 = createFileRoute("/_authenticated/onboarding/queue")({
	head: () => ({ meta: [{ title: "Employee Queue — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("../_authenticated.onboarding.dashboard-DvE12_gJ.mjs");
var Route$5 = createFileRoute("/_authenticated/onboarding/dashboard")({
	head: () => ({ meta: [{ title: "Onboarding Dashboard — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("../_authenticated.offer.queue-VF2AKUMc.mjs");
var Route$4 = createFileRoute("/_authenticated/offer/queue")({
	head: () => ({ meta: [{ title: "Offer Queue — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("../_authenticated.offer.dashboard-BNzVWD5V.mjs");
var Route$3 = createFileRoute("/_authenticated/offer/dashboard")({
	head: () => ({ meta: [{ title: "Offer Dashboard — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("../_authenticated.interviewer.queue-lve7EVDB.mjs");
var Route$2 = createFileRoute("/_authenticated/interviewer/queue")({
	head: () => ({ meta: [{ title: "Interview Queue — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("../_authenticated.hr.queue-DzuW-e-9.mjs");
var Route$1 = createFileRoute("/_authenticated/hr/queue")({
	head: () => ({ meta: [{ title: "HR Review Queue — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("../_authenticated.ceo.queue-Dq1gwE65.mjs");
var Route = createFileRoute("/_authenticated/ceo/queue")({
	head: () => ({ meta: [{ title: "CEO Review Queue — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var RegisterCandidateRoute = Route$31.update({
	id: "/register-candidate",
	path: "/register-candidate",
	getParentRoute: () => Route$17
});
var LoginRoute = Route$16.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$17
});
var AuthenticatedRoute = Route$15.update({
	id: "/_authenticated",
	getParentRoute: () => Route$17
});
var IndexRoute = Route$14.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$17
});
var CandidatePortalCandidateIdRoute = Route$30.update({
	id: "/candidate-portal/$candidateId",
	path: "/candidate-portal/$candidateId",
	getParentRoute: () => Route$17
});
var AuthenticatedUsersRoute = Route$13.update({
	id: "/users",
	path: "/users",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedSettingsRoute = Route$12.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedSchedulerRoute = Route$11.update({
	id: "/scheduler",
	path: "/scheduler",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedReportsRoute = Route$10.update({
	id: "/reports",
	path: "/reports",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedEmailManagementRoute = Route$9.update({
	id: "/email-management",
	path: "/email-management",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedDashboardRoute = Route$8.update({
	id: "/dashboard",
	path: "/dashboard",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedCandidatesRoute = Route$7.update({
	id: "/candidates",
	path: "/candidates",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedOnboardingQueueRoute = Route$6.update({
	id: "/onboarding/queue",
	path: "/onboarding/queue",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedOnboardingDashboardRoute = Route$5.update({
	id: "/onboarding/dashboard",
	path: "/onboarding/dashboard",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedOnboardingCandidateIdRoute = Route$28.update({
	id: "/onboarding/$candidateId",
	path: "/onboarding/$candidateId",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedOfferQueueRoute = Route$4.update({
	id: "/offer/queue",
	path: "/offer/queue",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedOfferDashboardRoute = Route$3.update({
	id: "/offer/dashboard",
	path: "/offer/dashboard",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedOfferCandidateIdRoute = Route$24.update({
	id: "/offer/$candidateId",
	path: "/offer/$candidateId",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedInterviewerQueueRoute = Route$2.update({
	id: "/interviewer/queue",
	path: "/interviewer/queue",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedHrQueueRoute = Route$1.update({
	id: "/hr/queue",
	path: "/hr/queue",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedFinalDiscussionIdRoute = Route$29.update({
	id: "/final-discussion/$id",
	path: "/final-discussion/$id",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedFinalDecisionIdRoute = Route$20.update({
	id: "/final-decision/$id",
	path: "/final-decision/$id",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedCeoQueueRoute = Route.update({
	id: "/ceo/queue",
	path: "/ceo/queue",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedCandidatesIdRoute = Route$18.update({
	id: "/$id",
	path: "/$id",
	getParentRoute: () => AuthenticatedCandidatesRoute
});
var AuthenticatedOfferStatusCandidateIdRoute = Route$27.update({
	id: "/offer/status/$candidateId",
	path: "/offer/status/$candidateId",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedOfferPreviewCandidateIdRoute = Route$26.update({
	id: "/offer/preview/$candidateId",
	path: "/offer/preview/$candidateId",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedOfferBuilderCandidateIdRoute = Route$25.update({
	id: "/offer/builder/$candidateId",
	path: "/offer/builder/$candidateId",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedInterviewerReviewIdRoute = Route$23.update({
	id: "/interviewer/review/$id",
	path: "/interviewer/review/$id",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedInterviewerEvaluateIdRoute = Route$22.update({
	id: "/interviewer/evaluate/$id",
	path: "/interviewer/evaluate/$id",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedHrReviewIdRoute = Route$21.update({
	id: "/hr/review/$id",
	path: "/hr/review/$id",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedCeoEvaluateIdRoute = Route$19.update({
	id: "/ceo/evaluate/$id",
	path: "/ceo/evaluate/$id",
	getParentRoute: () => AuthenticatedRoute
});
var AuthenticatedCandidatesRouteChildren = { AuthenticatedCandidatesIdRoute };
var AuthenticatedRouteChildren = {
	AuthenticatedCandidatesRoute: AuthenticatedCandidatesRoute._addFileChildren(AuthenticatedCandidatesRouteChildren),
	AuthenticatedDashboardRoute,
	AuthenticatedEmailManagementRoute,
	AuthenticatedReportsRoute,
	AuthenticatedSchedulerRoute,
	AuthenticatedSettingsRoute,
	AuthenticatedUsersRoute,
	AuthenticatedCeoQueueRoute,
	AuthenticatedFinalDecisionIdRoute,
	AuthenticatedFinalDiscussionIdRoute,
	AuthenticatedHrQueueRoute,
	AuthenticatedInterviewerQueueRoute,
	AuthenticatedOfferCandidateIdRoute,
	AuthenticatedOfferDashboardRoute,
	AuthenticatedOfferQueueRoute,
	AuthenticatedOnboardingCandidateIdRoute,
	AuthenticatedOnboardingDashboardRoute,
	AuthenticatedOnboardingQueueRoute,
	AuthenticatedCeoEvaluateIdRoute,
	AuthenticatedHrReviewIdRoute,
	AuthenticatedInterviewerEvaluateIdRoute,
	AuthenticatedInterviewerReviewIdRoute,
	AuthenticatedOfferBuilderCandidateIdRoute,
	AuthenticatedOfferPreviewCandidateIdRoute,
	AuthenticatedOfferStatusCandidateIdRoute
};
var rootRouteChildren = {
	IndexRoute,
	AuthenticatedRoute: AuthenticatedRoute._addFileChildren(AuthenticatedRouteChildren),
	LoginRoute,
	RegisterCandidateRoute,
	CandidatePortalCandidateIdRoute
};
var routeTree = Route$17._addFileChildren(rootRouteChildren)._addFileTypes();
var getRouter = () => {
	return createRouter({
		routeTree,
		context: { queryClient: new QueryClient({ defaultOptions: {
			queries: {
				staleTime: 300 * 1e3,
				gcTime: 600 * 1e3,
				retry: 1,
				refetchOnWindowFocus: false
			},
			mutations: { retry: 0 }
		} }) },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { getRouter };
