import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { P as KeyRound } from "./_libs/lucide-react.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
import { t as Label } from "./_ssr/label-BgXw8JJ9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.settings-Bpt7Dpdp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsPage() {
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const changePassword = useMutation({
		mutationFn: async () => {
			if (newPassword !== confirmPassword) throw new Error("New passwords do not match.");
			return api("/api/auth/change-password", {
				method: "POST",
				body: {
					current_password: currentPassword,
					new_password: newPassword
				}
			});
		},
		onSuccess: () => {
			toast.success("Password changed successfully.");
			setCurrentPassword("");
			setNewPassword("");
			setConfirmPassword("");
		},
		onError: (e) => {
			toast.error(e.message || "Failed to change password.");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-2xl mx-auto space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-10 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
				children: "Settings"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-[#86868b] mt-2",
				children: "Manage your account settings and security."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "bg-white rounded-[2.5rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-8 py-6 border-b border-gray-100 flex items-center gap-3 bg-[#fbfbfd]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-10 w-10 rounded-full bg-[#f5f5f7] flex items-center justify-center",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(KeyRound, { className: "h-5 w-5 text-[#1d1d1f]" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold tracking-tight text-[#1d1d1f]",
						children: "Change Password"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-[#86868b] mt-0.5",
						children: "Update your password to keep your account secure."
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-8 space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-[#86868b] uppercase tracking-wide",
								children: "Current Password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl px-4 py-3 h-12 text-sm text-[#1d1d1f] transition-all outline-none placeholder:text-[#86868b]",
								value: currentPassword,
								onChange: (e) => setCurrentPassword(e.target.value),
								placeholder: "Enter current password"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-[#86868b] uppercase tracking-wide",
								children: "New Password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl px-4 py-3 h-12 text-sm text-[#1d1d1f] transition-all outline-none placeholder:text-[#86868b]",
								value: newPassword,
								onChange: (e) => setNewPassword(e.target.value),
								placeholder: "Enter new password"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
								className: "text-xs font-bold text-[#86868b] uppercase tracking-wide",
								children: "Confirm New Password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl px-4 py-3 h-12 text-sm text-[#1d1d1f] transition-all outline-none placeholder:text-[#86868b]",
								value: confirmPassword,
								onChange: (e) => setConfirmPassword(e.target.value),
								placeholder: "Confirm new password"
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-8 py-5 bg-[#fbfbfd] border-t border-gray-100 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => changePassword.mutate(),
						disabled: !currentPassword || !newPassword || !confirmPassword || changePassword.isPending,
						className: "px-6 py-2.5 rounded-full bg-[#0066cc] text-white text-sm font-bold shadow-sm hover:bg-[#005bb5] transition-all active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100",
						children: changePassword.isPending ? "Changing..." : "Update Password"
					})
				})
			]
		})]
	});
}
//#endregion
export { SettingsPage as component };
