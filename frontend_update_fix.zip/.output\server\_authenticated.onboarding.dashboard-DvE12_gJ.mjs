import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { N as Laptop, V as FileCheck, Y as Clock, a as UserPlus, h as Shield, l as TrendingUp, pt as Calendar, r as Users, rt as CircleCheckBig, yt as ArrowRight } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.onboarding.dashboard-DvE12_gJ.js
var import_jsx_runtime = require_jsx_runtime();
function OnboardingDashboard() {
	const { data: stats, isLoading: statsLoading } = useQuery({
		queryKey: ["onboarding", "stats"],
		queryFn: () => api("/api/onboarding/stats").then((r) => r.data)
	});
	const { data: onboardings, isLoading: onboardingsLoading } = useQuery({
		queryKey: ["onboarding", "list"],
		queryFn: () => api("/api/onboarding?limit=500").then((r) => r.data ?? [])
	});
	const isLoading = statsLoading || onboardingsLoading;
	const kpis = [
		{
			label: "Total Employees",
			value: stats?.total_employees ?? 0,
			icon: Users,
			tint: "text-blue-600",
			bg: "bg-blue-50"
		},
		{
			label: "In Progress",
			value: stats?.in_progress ?? 0,
			icon: TrendingUp,
			tint: "text-violet-600",
			bg: "bg-violet-50"
		},
		{
			label: "Completed",
			value: stats?.completed ?? 0,
			icon: CircleCheckBig,
			tint: "text-emerald-600",
			bg: "bg-emerald-50"
		},
		{
			label: "Pending Documents",
			value: stats?.documents_pending ?? 0,
			icon: FileCheck,
			tint: "text-orange-600",
			bg: "bg-orange-50"
		},
		{
			label: "BGV Pending",
			value: stats?.bgv_pending ?? 0,
			icon: Shield,
			tint: "text-red-600",
			bg: "bg-red-50"
		},
		{
			label: "IT Assets Pending",
			value: stats?.assets_pending ?? 0,
			icon: Laptop,
			tint: "text-cyan-600",
			bg: "bg-cyan-50"
		},
		{
			label: "Joining This Month",
			value: stats?.onboarding_this_month ?? 0,
			icon: Calendar,
			tint: "text-indigo-600",
			bg: "bg-indigo-50"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rounded-[2.5rem] bg-[#1d1d1f] p-8 lg:p-12 text-white relative overflow-hidden shadow-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-20 -top-20 h-96 w-96 rounded-full bg-indigo-500/10 blur-[80px] pointer-events-none" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -left-20 -bottom-20 h-80 w-80 rounded-full bg-blue-500/10 blur-[80px] pointer-events-none" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl lg:text-4xl font-bold tracking-tighter relative z-10",
						children: "Employee Onboarding"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-white/70 mt-2 relative z-10 max-w-lg",
						children: "Manage the complete onboarding lifecycle for selected candidates."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-8 mt-10 relative z-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-white/50 uppercase mb-1",
								children: "Total Employees"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-bold tracking-tighter text-white",
								children: stats?.total_employees ?? 0
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px bg-white/10" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-white/50 uppercase mb-1",
								children: "In Progress"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-bold tracking-tighter text-white",
								children: stats?.in_progress ?? 0
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px bg-white/10" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-white/50 uppercase mb-1",
								children: "Completed"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-bold tracking-tighter text-white",
								children: stats?.completed ?? 0
							})] })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/onboarding/queue",
					className: "flex items-center bg-white border border-gray-200 text-[#1d1d1f] hover:bg-[#f5f5f7] rounded-full px-6 py-2.5 text-sm font-bold shadow-sm transition-all active:scale-[0.98]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserPlus, { className: "h-4 w-4 mr-2" }), " Employee Queue"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/candidates",
					className: "flex items-center bg-white border border-gray-200 text-[#1d1d1f] hover:bg-[#f5f5f7] rounded-full px-6 py-2.5 text-sm font-bold shadow-sm transition-all active:scale-[0.98]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 mr-2" }), " Candidate Directory"]
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: Array.from({ length: 8 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-24 mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-12" })]
				}, i))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 sm:grid-cols-4 gap-4",
				children: kpis.map((k) => {
					const Icon = k.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col h-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] uppercase tracking-widest font-bold text-[#86868b] leading-tight",
									children: k.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-8 w-8 rounded-xl ${k.bg} flex-shrink-0 grid place-items-center ml-2`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `h-4 w-4 ${k.tint}` })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-auto text-2xl font-bold tracking-tighter text-[#1d1d1f]",
								children: k.value
							})]
						})
					}, k.label);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-[2.5rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-8 py-6 border-b border-gray-100 flex items-center justify-between gap-4 bg-[#fbfbfd]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-5 w-5 text-[#1d1d1f]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-bold tracking-tight text-[#1d1d1f]",
							children: "Recent Onboarding Activity"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-[#86868b] mt-1",
						children: "Latest onboarding actions across all selected candidates."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/onboarding/queue",
						className: "flex items-center bg-transparent hover:bg-gray-100 text-[#1d1d1f] rounded-full px-5 py-2 text-xs font-bold transition-all",
						children: ["View All ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 ml-1.5" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-4 space-y-0",
						children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-6 px-8 py-6 border-b border-gray-50/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-10 rounded-full" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-60" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-24 rounded-full" })
							]
						}, i))
					}) : (() => {
						const recent = (onboardings ?? []).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()).slice(0, 8);
						if (recent.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "p-16 text-center text-sm font-medium text-[#86868b]",
							children: "No onboarding activity yet. Start onboarding for selected candidates."
						});
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: recent.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[auto_1fr_auto] gap-6 px-8 py-5 border-b border-gray-50/50 hover:bg-[#f5f5f7]/60 transition-colors items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-10 w-10 rounded-full bg-[#f5f5f7] grid place-items-center text-[#1d1d1f] font-bold text-xs",
									children: item.candidate_name.split(" ").map((n) => n[0]).join("")
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 pr-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-bold text-[#1d1d1f] truncate",
										children: item.candidate_name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
										children: [
											item.status.replace(/_/g, " "),
											" · ",
											new Date(item.created_at).toLocaleDateString()
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-end",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: "/onboarding/$candidateId",
										params: { candidateId: item.candidate_id },
										className: "flex items-center bg-transparent hover:bg-gray-100 border border-gray-200 text-[#1d1d1f] rounded-full px-5 py-2 text-xs font-bold transition-all shadow-sm active:scale-[0.98]",
										children: ["View ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 ml-1.5" })]
									})
								})
							]
						}, item.onboarding_id)) });
					})()
				})]
			})
		]
	});
}
//#endregion
export { OnboardingDashboard as component };
