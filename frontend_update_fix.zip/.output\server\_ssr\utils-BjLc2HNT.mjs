import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-BjLc2HNT.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
/**
* Return a valid Date or null — never produces an Invalid Date.
*/
function safeDate(value) {
	if (value == null) return null;
	const d = value instanceof Date ? value : new Date(value);
	return Number.isNaN(d.getTime()) ? null : d;
}
//#endregion
export { safeDate as n, cn as t };
