import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { V as FileCheck, Y as Clock, l as TrendingUp, r as Users, rt as CircleCheckBig, v as Send, yt as ArrowRight } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.offer.dashboard-BNzVWD5V.js
var import_jsx_runtime = require_jsx_runtime();
function OfferDashboard() {
	const { data: statsData, isLoading: statsLoading } = useQuery({
		queryKey: ["offers", "stats"],
		queryFn: () => api("/api/offers/stats")
	});
	const { data: offersData, isLoading: offersLoading } = useQuery({
		queryKey: ["offers", "list"],
		queryFn: () => api("/api/offers?limit=500")
	});
	const isLoading = statsLoading || offersLoading;
	const stats = statsData?.data;
	const offers = offersData?.data ?? [];
	const kpis = [
		{
			label: "Total Offers",
			value: stats?.total_offers ?? 0,
			icon: Users,
			tint: "text-green-600",
			bg: "bg-green-50"
		},
		{
			label: "Pending",
			value: stats?.pending_offers ?? 0,
			icon: Clock,
			tint: "text-amber-600",
			bg: "bg-amber-50"
		},
		{
			label: "Accepted",
			value: stats?.accepted_offers ?? 0,
			icon: CircleCheckBig,
			tint: "text-emerald-600",
			bg: "bg-emerald-50"
		},
		{
			label: "Declined",
			value: stats?.declined_offers ?? 0,
			icon: FileCheck,
			tint: "text-red-600",
			bg: "bg-red-50"
		},
		{
			label: "This Month",
			value: stats?.offers_this_month ?? 0,
			icon: Send,
			tint: "text-blue-600",
			bg: "bg-blue-50"
		},
		{
			label: "Avg Processing Days",
			value: stats?.avg_processing_days != null ? `${stats.avg_processing_days.toFixed(1)}d` : "—",
			icon: TrendingUp,
			tint: "text-violet-600",
			bg: "bg-violet-50"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "rounded-[2.5rem] bg-[#1d1d1f] p-8 lg:p-12 text-white relative overflow-hidden shadow-2xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -right-20 -top-20 h-96 w-96 rounded-full bg-blue-500/10 blur-[80px] pointer-events-none" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute -left-20 -bottom-20 h-80 w-80 rounded-full bg-emerald-500/10 blur-[80px] pointer-events-none" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-3xl lg:text-4xl font-bold tracking-tighter relative z-10",
						children: "Offer Management"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-white/70 mt-2 relative z-10 max-w-lg",
						children: "Track selected candidates, build offers, and manage offer lifecycle."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-8 mt-10 relative z-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-white/50 uppercase mb-1",
								children: "Total Offers"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-bold tracking-tighter text-white",
								children: stats?.total_offers ?? 0
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px bg-white/10" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-white/50 uppercase mb-1",
								children: "Pending Offers"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-bold tracking-tighter text-white",
								children: stats?.pending_offers ?? 0
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-px bg-white/10" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-white/50 uppercase mb-1",
								children: "Accepted"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-3xl font-bold tracking-tighter text-white",
								children: stats?.accepted_offers ?? 0
							})] })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/offer/queue",
					className: "flex items-center bg-white border border-gray-200 text-[#1d1d1f] hover:bg-[#f5f5f7] rounded-full px-6 py-2.5 text-sm font-bold shadow-sm transition-all active:scale-[0.98]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-4 w-4 mr-2" }), " Offer Queue"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/candidates",
					className: "flex items-center bg-white border border-gray-200 text-[#1d1d1f] hover:bg-[#f5f5f7] rounded-full px-6 py-2.5 text-sm font-bold shadow-sm transition-all active:scale-[0.98]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { className: "h-4 w-4 mr-2" }), " Candidate Directory"]
				})]
			}),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4",
				children: Array.from({ length: 6 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-16 mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-12" })]
				}, i))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4",
				children: kpis.map((k) => {
					const Icon = k.icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col h-full",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between mb-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-[10px] uppercase tracking-widest font-bold text-[#86868b] leading-tight",
									children: k.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-8 w-8 rounded-xl ${k.bg} flex-shrink-0 grid place-items-center ml-2`,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: `h-4 w-4 ${k.tint}` })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-auto text-2xl font-bold tracking-tighter text-[#1d1d1f]",
								children: k.value
							})]
						})
					}, k.label);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-[2.5rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-8 py-6 border-b border-gray-100 flex items-center justify-between gap-4 bg-[#fbfbfd]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheckBig, { className: "h-5 w-5 text-[#1d1d1f]" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-xl font-bold tracking-tight text-[#1d1d1f]",
								children: "Recent Offers"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "bg-[#f5f5f7] text-[#86868b] text-xs font-bold px-2 py-1 rounded-full",
								children: offers.length
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-[#86868b] mt-1",
						children: "Latest offer records and their current status."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/offer/queue",
						className: "flex items-center bg-transparent hover:bg-gray-100 text-[#1d1d1f] rounded-full px-5 py-2 text-xs font-bold transition-all",
						children: ["View All ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 ml-1.5" })]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-4 space-y-0",
						children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-6 px-8 py-6 border-b border-gray-50/50",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-10 rounded-full" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 space-y-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-60" })]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-24 rounded-full" })
							]
						}, i))
					}) : offers.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-16 text-center text-sm font-medium text-[#86868b]",
						children: "No offers created yet. Offers will appear here once candidates are moved to SELECTED status and offers are generated."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: offers.slice(0, 10).map((offer) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[auto_1fr_auto_auto] gap-6 px-8 py-5 border-b border-gray-50/50 hover:bg-[#f5f5f7]/60 transition-colors items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-full bg-[#f5f5f7] grid place-items-center text-[#1d1d1f] font-bold text-xs",
								children: offer.candidate_name.charAt(0).toUpperCase()
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 pr-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-bold text-[#1d1d1f] truncate",
									children: offer.candidate_name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
									children: [
										offer.application_number,
										" · ",
										offer.candidate_email,
										offer.offered_ctc ? ` · ₹${(offer.offered_ctc / 1e5).toFixed(1)}L CTC` : ""
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-semibold tracking-wide ${offer.status === "ACCEPTED" ? "bg-emerald-50 text-emerald-700" : offer.status === "SENT" ? "bg-blue-50 text-blue-700" : offer.status === "DECLINED" ? "bg-red-50 text-red-700" : "bg-amber-50 text-amber-700"}`,
								children: offer.status.charAt(0).toUpperCase() + offer.status.slice(1).toLowerCase()
							}) }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex items-center justify-end w-24",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: `/offer/preview/$candidateId`,
									params: { candidateId: offer.candidate_id },
									className: "flex items-center bg-transparent hover:bg-gray-100 border border-gray-200 text-[#1d1d1f] rounded-full px-5 py-2 text-xs font-bold transition-all shadow-sm active:scale-[0.98]",
									children: ["View ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 ml-1.5" })]
								})
							})
						]
					}, offer.offer_id)) })
				})]
			})
		]
	});
}
//#endregion
export { OfferDashboard as component };
