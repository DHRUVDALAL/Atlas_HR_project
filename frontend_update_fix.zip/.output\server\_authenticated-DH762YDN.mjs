import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { n as useAuth } from "./_ssr/auth-Ba-lKRMp.mjs";
import { t as cva } from "./_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./_ssr/utils-BjLc2HNT.mjs";
import { t as Button } from "./_ssr/button-B_S4Wnqd.mjs";
import { t as Badge } from "./_ssr/badge-2MwuhCYP.mjs";
import { _ as Navigate, f as Outlet, g as Link, l as useRouterState } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { a as DialogOverlay, c as DialogTrigger, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "./_libs/@radix-ui/react-dialog+[...].mjs";
import { B as FileText, E as Menu, M as LayoutDashboard, O as Mail, V as FileCheck, Z as ClipboardCheck, _ as Settings, a as UserPlus, f as Timer, gt as Bell, j as ListChecks, k as LogOut, lt as Check, n as X, o as UserCog, q as Crown, r as Users, ut as CheckCheck } from "./_libs/lucide-react.mjs";
import { a as Viewport, i as ScrollAreaThumb, n as Root, r as ScrollAreaScrollbar, t as Corner } from "./_libs/radix-ui__react-scroll-area.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated-DH762YDN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props,
	ref
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var sheetVariants = cva("fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out", {
	variants: { side: {
		top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
		bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
		left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
		right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
	} },
	defaultVariants: { side: "right" }
});
var SheetContent = import_react.forwardRef(({ side = "right", className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn(sheetVariants({ side }), className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-4 w-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	}), children]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col space-y-2 text-center sm:text-left", className),
	...props
});
SheetHeader.displayName = "SheetHeader";
var SheetFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
});
SheetFooter.displayName = "SheetFooter";
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("text-lg font-semibold text-foreground", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
var ScrollArea = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Root, {
	ref,
	className: cn("relative overflow-hidden", className),
	...props,
	children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Viewport, {
			className: "h-full w-full rounded-[inherit]",
			children
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollBar, {}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Corner, {})
	]
}));
ScrollArea.displayName = Root.displayName;
var ScrollBar = import_react.forwardRef(({ className, orientation = "vertical", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaScrollbar, {
	ref,
	orientation,
	className: cn("flex touch-none select-none transition-colors", orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent p-[1px]", orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent p-[1px]", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollAreaThumb, { className: "relative flex-1 rounded-full bg-border" })
}));
ScrollBar.displayName = ScrollAreaScrollbar.displayName;
function NotificationBell() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const qc = useQueryClient();
	const { data: unreadData } = useQuery({
		queryKey: ["notifications", "unread-count"],
		queryFn: () => api("/api/notifications/unread-count"),
		refetchInterval: 3e4,
		retry: false
	});
	const { data: notificationsData, isLoading } = useQuery({
		queryKey: ["notifications", "list"],
		queryFn: () => api("/api/notifications?limit=50"),
		enabled: open
	});
	const markRead = useMutation({
		mutationFn: (id) => api(`/api/notifications/${id}/read`, { method: "PUT" }),
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["notifications"] });
		}
	});
	const markAllRead = useMutation({
		mutationFn: () => api("/api/notifications/read-all", { method: "PUT" }),
		onSuccess: () => {
			qc.invalidateQueries({ queryKey: ["notifications"] });
			toast.success("All notifications marked as read");
		}
	});
	const unreadCount = unreadData?.count ?? 0;
	const notifications = notificationsData?.items ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				variant: "ghost",
				size: "icon",
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "h-5 w-5" }), unreadCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					className: "absolute -top-1 -right-1 h-5 min-w-5 text-[10px] font-bold",
					variant: "destructive",
					children: unreadCount > 99 ? "99+" : unreadCount
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
			className: "w-full sm:w-96 p-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, {
				className: "p-4 border-b",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Notifications" }), unreadCount > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => markAllRead.mutate(),
						disabled: markAllRead.isPending,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckCheck, { className: "h-4 w-4 mr-1" }), " Mark all read"]
					})]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScrollArea, {
				className: "h-[calc(100vh-8rem)]",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-4 space-y-3",
					children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "p-3 rounded-lg border animate-pulse",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-3/4 bg-muted rounded mb-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-full bg-muted rounded" })]
					}, i))
				}) : notifications.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "p-8 text-center text-sm text-muted-foreground",
					children: "No notifications"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "divide-y",
					children: notifications.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `p-4 hover:bg-muted/50 transition-colors ${!n.is_read ? "bg-blue-50/50" : ""}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-medium truncate",
											children: n.title
										}), !n.is_read && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-blue-500 shrink-0" })]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted-foreground mt-1 line-clamp-2",
										children: n.message
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-[10px] text-muted-foreground mt-2",
										children: new Date(n.created_at).toLocaleString()
									})
								]
							}), !n.is_read && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "icon",
								className: "h-7 w-7 shrink-0",
								onClick: () => markRead.mutate(n.id),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "h-3.5 w-3.5" })
							})]
						})
					}, n.id))
				})
			})]
		})]
	});
}
var NAV = [
	{
		to: "/dashboard",
		label: "Dashboard",
		icon: LayoutDashboard
	},
	{
		to: "/candidates",
		label: "Candidates",
		icon: Users,
		permissions: ["candidate.list", "workflow.reception_forward"]
	},
	{
		to: "/hr/queue",
		label: "HR Review Queue",
		icon: ClipboardCheck,
		permissions: ["workflow.hr_review"]
	},
	{
		to: "/interviewer/queue",
		label: "Interview Queue",
		icon: ListChecks,
		permissions: ["evaluation.view_assigned"]
	},
	{
		to: "/ceo/queue",
		label: "CEO Review Queue",
		icon: Crown,
		permissions: ["workflow.ceo_evaluate", "decision.final"]
	},
	{
		to: "/offer/dashboard",
		label: "Offer Management",
		icon: FileCheck,
		permissions: ["decision.final"]
	},
	{
		to: "/onboarding/dashboard",
		label: "Onboarding",
		icon: UserPlus,
		permissions: ["decision.final"]
	},
	{
		to: "/users",
		label: "Employee Management",
		icon: UserCog,
		permissions: ["user.manage"]
	},
	{
		to: "/reports",
		label: "Reports",
		icon: FileText,
		permissions: ["report.export"]
	},
	{
		to: "/email-management",
		label: "Email Queue",
		icon: Mail,
		permissions: ["email.admin"]
	},
	{
		to: "/scheduler",
		label: "Scheduler",
		icon: Timer,
		permissions: ["scheduler.admin"]
	},
	{
		to: "/settings",
		label: "Settings",
		icon: Settings
	}
];
function AuthenticatedLayout() {
	const { user, loading, logout, hasAnyRole, hasAnyPermission } = useAuth();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [mobileOpen, setMobileOpen] = (0, import_react.useState)(false);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen grid place-items-center text-muted-foreground text-sm",
		children: "Loading…"
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/login" });
	const visibleNav = NAV.filter((n) => {
		if (n.roles && !hasAnyRole(n.roles)) return false;
		if (n.permissions && !hasAnyPermission(n.permissions)) return false;
		return true;
	});
	const isActive = (to) => pathname === to || pathname.startsWith(to + "/");
	const sidebarContent = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "p-6 border-b border-gray-100 bg-white",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/dashboard",
				className: "flex items-center gap-3 p-2 hover:bg-black/5 rounded-xl transition-colors",
				onClick: () => setMobileOpen(false),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/logo.png",
					alt: "Atlas Logo",
					className: "h-8 w-auto"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "font-bold tracking-tight text-[#1d1d1f]",
					children: "Atlas HR"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "text-[11px] text-[#86868b] font-medium tracking-wide uppercase",
					children: "Recruitment Console"
				})] })]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
			className: "flex-1 p-4 space-y-1 overflow-y-auto bg-white",
			children: visibleNav.map((item) => {
				const Icon = item.icon;
				const active = isActive(item.to);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: item.to,
					onClick: () => setMobileOpen(false),
					className: "flex items-center gap-3 px-4 py-2.5 rounded-2xl text-sm transition-all duration-200 " + (active ? "bg-[#f5f5f7] text-[#1d1d1f] font-semibold" : "text-[#86868b] hover:bg-gray-50 hover:text-[#1d1d1f]"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }), item.label]
				}, item.to);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-4 border-t border-gray-100 bg-white",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex items-center gap-2 mb-3 px-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationBell, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "px-3 py-2 mb-3 bg-[#f5f5f7] rounded-2xl",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm font-semibold text-[#1d1d1f] truncate",
						children: [
							user.first_name,
							" ",
							user.last_name
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
						children: user.roles.join(", ")
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					className: "w-full flex items-center justify-center gap-2 bg-transparent border border-gray-200 hover:bg-gray-50 text-[#1d1d1f] rounded-full px-6 py-2.5 text-sm font-semibold transition-all active:scale-[0.98]",
					onClick: () => {
						logout();
						window.location.href = "/login";
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogOut, { className: "h-4 w-4" }), "Sign out"]
				})
			]
		})
	] });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen flex bg-[#fbfbfd]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "hidden lg:flex w-72 shrink-0 bg-white text-[#1d1d1f] flex-col border-r border-gray-100 shadow-[4px_0_24px_rgba(0,0,0,0.01)] z-40",
			children: sidebarContent
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex-1 flex flex-col min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "lg:hidden flex items-center gap-3 p-4 bg-white/70 backdrop-blur-xl border-b border-gray-100 sticky top-0 z-50",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
						open: mobileOpen,
						onOpenChange: setMobileOpen,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								size: "sm",
								className: "px-2 text-[#1d1d1f] hover:bg-[#f5f5f7]",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetContent, {
							side: "left",
							className: "w-72 p-0 bg-white border-r border-gray-100",
							children: sidebarContent
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/dashboard",
						className: "flex items-center gap-3 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/logo.png",
							alt: "Atlas Logo",
							className: "h-6 w-auto"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold tracking-tight text-[#1d1d1f]",
							children: "Atlas HR"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotificationBell, {})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1 min-w-0 overflow-x-hidden relative",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			})]
		})]
	});
}
//#endregion
export { AuthenticatedLayout as component };
