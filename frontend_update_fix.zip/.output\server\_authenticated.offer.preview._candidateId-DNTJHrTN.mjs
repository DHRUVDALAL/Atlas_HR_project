import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.offer.preview._candidateId-DNTJHrTN.js
var $$splitComponentImporter = () => import("./_authenticated.offer.preview._candidateId-DQsO_d-q.mjs");
var Route = createFileRoute("/_authenticated/offer/preview/$candidateId")({
	head: () => ({ meta: [{ title: "Offer Preview — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
