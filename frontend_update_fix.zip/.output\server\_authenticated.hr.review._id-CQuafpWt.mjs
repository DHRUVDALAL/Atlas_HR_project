import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.hr.review._id-CQuafpWt.js
var $$splitComponentImporter = () => import("./_authenticated.hr.review._id-htSj7v6K.mjs");
var Route = createFileRoute("/_authenticated/hr/review/$id")({
	head: () => ({ meta: [{ title: "HR Review — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
