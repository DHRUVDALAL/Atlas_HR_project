import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { n as safeDate } from "./_ssr/utils-BjLc2HNT.mjs";
import { g as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { R as Funnel, Y as Clock, j as ListChecks, s as UserCheck, vt as ArrowUpDown, y as Search, yt as ArrowRight } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { i as statusMeta } from "./_ssr/scorecard-YpVMHDsm.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-CAzbakW8.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.interviewer.queue-lve7EVDB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function InterviewQueue() {
	const [search, setSearch] = (0, import_react.useState)("");
	const [statusFilter, setStatusFilter] = (0, import_react.useState)("all");
	const [sortOrder, setSortOrder] = (0, import_react.useState)("asc");
	const { data, isLoading } = useQuery({
		queryKey: [
			"assignments",
			"my",
			search,
			statusFilter,
			sortOrder
		],
		queryFn: () => api(`/api/workflow/my-assignments?only_pending=true`).then((r) => {
			let list = r.assignments ?? [];
			if (search) {
				const q = search.toLowerCase();
				list = list.filter((a) => a.candidate_name.toLowerCase().includes(q) || a.position?.toLowerCase().includes(q) || a.domain?.toLowerCase().includes(q));
			}
			if (statusFilter !== "all") list = list.filter((a) => a.status === statusFilter);
			list.sort((a, b) => {
				const da = safeDate(a.assigned_at)?.getTime() ?? 0;
				const db = safeDate(b.assigned_at)?.getTime() ?? 0;
				return sortOrder === "asc" ? da - db : db - da;
			});
			return list;
		})
	});
	const assignments = data ?? [];
	const totalPending = assignments.filter((a) => a.status === "PENDING").length;
	const totalInProgress = assignments.filter((a) => a.status === "IN_PROGRESS").length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
				children: "Interview Queue"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-[#86868b] mt-1",
				children: "Your assigned interviews — evaluate candidates after each round."
			})] }),
			isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 sm:grid-cols-3 gap-4",
				children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-20 mb-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-12 mb-2" })]
				}, i))
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 sm:grid-cols-3 gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "Total Assigned"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: assignments.length
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-blue-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListChecks, { className: "h-5 w-5 text-blue-600" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "Pending"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: totalPending
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-amber-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-5 w-5 text-amber-600" })
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-6 md:p-8 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col justify-between hover:shadow-[0_8px_30px_rgb(0,0,0,0.06)] transition-shadow duration-300",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-[11px] font-bold tracking-widest text-[#86868b] uppercase",
								children: "In Progress"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-4xl font-bold tracking-tighter text-[#1d1d1f] mt-4",
								children: totalInProgress
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-10 w-10 rounded-2xl bg-emerald-50 grid place-items-center",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserCheck, { className: "h-5 w-5 text-emerald-600" })
							})]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-4 md:p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] flex flex-col sm:flex-row gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-[#86868b]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						placeholder: "Search by name, position, or domain…",
						className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl pl-11 pr-5 py-3 text-sm text-[#1d1d1f] placeholder:text-[#86868b] transition-all outline-none",
						value: search,
						onChange: (e) => setSearch(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: statusFilter,
						onValueChange: setStatusFilter,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
							className: "w-full sm:w-40 bg-[#f5f5f7] border-transparent rounded-2xl h-11 px-4 text-sm font-medium",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Funnel, { className: "h-4 w-4 mr-2 opacity-50" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, { placeholder: "Status" })]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
							className: "rounded-2xl border-gray-100 shadow-xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "all",
									className: "rounded-xl cursor-pointer",
									children: "All statuses"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "PENDING",
									className: "rounded-xl cursor-pointer",
									children: "Pending"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "IN_PROGRESS",
									className: "rounded-xl cursor-pointer",
									children: "In Progress"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "COMPLETED",
									className: "rounded-xl cursor-pointer",
									children: "Completed"
								})
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "h-11 px-5 flex items-center justify-center bg-transparent hover:bg-gray-50 text-[#86868b] border border-gray-200 rounded-2xl text-sm font-medium transition-colors whitespace-nowrap",
						onClick: () => setSortOrder(sortOrder === "asc" ? "desc" : "asc"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpDown, { className: "h-4 w-4 mr-2" }), sortOrder === "asc" ? "Oldest first" : "Newest first"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-white rounded-[2rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-6 px-8 py-6 border-b border-gray-50/50",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-10 rounded-full" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex-1 space-y-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-3 w-60" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-24 rounded-full" })
						]
					}, i))
				}) : assignments.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-16 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-lg font-bold text-[#1d1d1f]",
						children: "No interviews assigned"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-[#86868b] mt-1",
						children: "You don't have any pending interview assignments."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: assignments.map((a) => {
						const s = statusMeta(a.status);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[auto_1fr_auto_auto] gap-6 px-6 md:px-8 py-5 border-b border-gray-50/50 hover:bg-[#f5f5f7]/60 transition-colors items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-10 w-10 rounded-full bg-[#f5f5f7] grid place-items-center text-[#1d1d1f] font-bold text-xs",
									children: a.candidate_name.split(" ").map((n) => n[0]).join("").slice(0, 2).toUpperCase()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 pr-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-bold text-[#1d1d1f] truncate",
										children: a.candidate_name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
										children: [
											a.position ?? "—",
											" · ",
											a.domain ?? "—",
											" · Round ",
											a.round_number,
											" · Assigned",
											" ",
											a.assigned_at ? new Date(a.assigned_at).toLocaleDateString() : "—"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-semibold tracking-wide ${s.className}`,
									children: s.label
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "flex items-center justify-end w-28",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
										to: `/interviewer/evaluate/${a.candidate_id}`,
										className: "flex items-center bg-[#0066cc] hover:bg-[#005bb5] text-white rounded-full px-5 py-2 text-xs font-bold transition-all shadow-sm active:scale-[0.98]",
										children: ["Evaluate ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "h-3.5 w-3.5 ml-1.5" })]
									})
								})
							]
						}, a.assignment_id);
					})
				})
			})
		]
	});
}
//#endregion
export { InterviewQueue as component };
