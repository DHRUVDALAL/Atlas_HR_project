import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { Y as Clock, et as CirclePlay, nt as CircleCheck } from "./_libs/lucide-react.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.scheduler-CllNqKHi.js
var import_jsx_runtime = require_jsx_runtime();
function SchedulerPage() {
	const { data: status, refetch } = useQuery({
		queryKey: ["scheduler-status"],
		queryFn: () => api("/api/scheduler/status")
	});
	const runDailyMut = useMutation({
		mutationFn: () => api("/api/scheduler/run-daily", { method: "POST" }),
		onSuccess: () => {
			toast.success("Daily scheduler job executed");
			refetch();
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-5xl mx-auto space-y-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mb-10 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-3xl lg:text-4xl font-bold tracking-tighter text-[#1d1d1f]",
				children: "System Scheduler"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-[#86868b] mt-2",
				children: "Manage background tasks and daily reminders."
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "bg-white rounded-[2.5rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "p-8 md:p-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col md:flex-row items-start md:items-center justify-between gap-6 mb-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-12 w-12 rounded-2xl bg-indigo-50 flex items-center justify-center shrink-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "h-6 w-6 text-indigo-600" })
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-bold tracking-tight text-[#1d1d1f]",
							children: "Daily Reminders"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-[#86868b] mt-1 max-w-md leading-relaxed",
							children: "Manually trigger the daily reminder job. This job sends interview reminder emails and updates overdue task statuses."
						})] })]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						onClick: () => runDailyMut.mutate(),
						disabled: runDailyMut.isPending,
						className: "flex items-center bg-[#1d1d1f] hover:bg-black text-white rounded-full px-8 py-3.5 text-sm font-bold shadow-sm transition-all active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100 shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePlay, { className: "mr-2 h-5 w-5" }), runDailyMut.isPending ? "Running..." : "Run Daily Reminders"]
					})]
				}), status && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 rounded-2xl bg-[#1d1d1f] overflow-hidden shadow-inner",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "px-6 py-3 border-b border-white/10 flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4 text-emerald-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-bold text-white/70 tracking-widest uppercase",
							children: "Scheduler Status"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "p-6 overflow-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
							className: "text-[13px] leading-relaxed text-[#f5f5f7] font-mono",
							children: JSON.stringify(status, null, 2)
						})
					})]
				})]
			})
		})]
	});
}
//#endregion
export { SchedulerPage as component };
