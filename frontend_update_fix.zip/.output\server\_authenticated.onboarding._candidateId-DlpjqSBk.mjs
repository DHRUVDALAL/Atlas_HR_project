import { m as createFileRoute, p as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.onboarding._candidateId-DlpjqSBk.js
var $$splitComponentImporter = () => import("./_authenticated.onboarding._candidateId-BnD1hDCg.mjs");
var Route = createFileRoute("/_authenticated/onboarding/$candidateId")({
	head: () => ({ meta: [{ title: "Employee Profile — Atlas HR" }] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
