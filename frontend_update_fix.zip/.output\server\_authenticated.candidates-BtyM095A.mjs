import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { t as Button } from "./_ssr/button-B_S4Wnqd.mjs";
import { f as Outlet, g as Link, l as useRouterState } from "./_libs/@tanstack/react-router+[...].mjs";
import { n as useQuery } from "./_libs/tanstack__react-query.mjs";
import { _t as ArrowUp, ot as ChevronRight, st as ChevronLeft, vt as ArrowUpDown, xt as ArrowDown, y as Search } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { i as statusMeta, r as STATUS_META } from "./_ssr/scorecard-YpVMHDsm.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./_ssr/select-CAzbakW8.mjs";
import { t as motion } from "./_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.candidates-BtyM095A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CandidatesPage() {
	const segments = useRouterState({ select: (s) => s.location.pathname }).split("/").filter(Boolean);
	if (segments.length > 1 && segments[0] === "candidates") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CandidatesList, {});
}
var PAGE_SIZE = 10;
function CandidatesList() {
	const [status, setStatus] = (0, import_react.useState)("ALL");
	const [search, setSearch] = (0, import_react.useState)("");
	const [debouncedSearch, setDebouncedSearch] = (0, import_react.useState)("");
	const [page, setPage] = (0, import_react.useState)(1);
	const [sortBy, setSortBy] = (0, import_react.useState)("created_at");
	const [sortOrder, setSortOrder] = (0, import_react.useState)("desc");
	const [debounceTimer, setDebounceTimer] = (0, import_react.useState)(null);
	const handleSearchChange = (value) => {
		setSearch(value);
		if (debounceTimer) clearTimeout(debounceTimer);
		const timer = setTimeout(() => {
			setDebouncedSearch(value);
			setPage(1);
		}, 300);
		setDebounceTimer(timer);
	};
	const skip = (page - 1) * PAGE_SIZE;
	const params = new URLSearchParams();
	params.set("limit", String(PAGE_SIZE));
	params.set("skip", String(skip));
	if (status !== "ALL") params.set("status", status);
	if (debouncedSearch) params.set("search", debouncedSearch);
	params.set("sort_by", sortBy);
	params.set("sort_order", sortOrder);
	const { data, isLoading } = useQuery({
		queryKey: [
			"applicants",
			status,
			debouncedSearch,
			page,
			sortBy,
			sortOrder
		],
		queryFn: () => api(`/api/applicants?${params.toString()}`)
	});
	const rows = data?.applicants ?? [];
	const total = data?.total ?? 0;
	const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
	const toggleSort = (field) => {
		if (sortBy === field) setSortOrder((o) => o === "asc" ? "desc" : "asc");
		else {
			setSortBy(field);
			setSortOrder("desc");
		}
		setPage(1);
	};
	const SortIcon = ({ field }) => {
		if (sortBy !== field) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpDown, { className: "h-3 w-3 ml-1 opacity-40" });
		return sortOrder === "asc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "h-3 w-3 ml-1 text-primary" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "h-3 w-3 ml-1 text-primary" });
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex flex-wrap items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-3xl font-bold tracking-tighter text-[#1d1d1f]",
					children: "Candidates"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium text-[#86868b] mt-1",
					children: "Full applicant roster across every workflow stage."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/register-candidate",
					className: "flex items-center bg-[#1d1d1f] text-white hover:bg-black rounded-full px-6 py-2.5 text-sm font-medium shadow-sm transition-all active:scale-[0.98]",
					children: "New registration"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white p-4 md:p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative flex-1 min-w-[240px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-[#86868b]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: search,
							onChange: (e) => handleSearchChange(e.target.value),
							placeholder: "Search name, email, application #",
							className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl pl-11 pr-5 py-3 text-sm text-[#1d1d1f] placeholder:text-[#86868b] transition-all outline-none"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: status,
								onValueChange: (v) => {
									setStatus(v);
									setPage(1);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "w-[180px] bg-[#f5f5f7] border-transparent rounded-2xl h-11 px-4 text-sm font-medium",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
									className: "rounded-2xl border-gray-100 shadow-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "ALL",
										className: "rounded-xl cursor-pointer",
										children: "All statuses"
									}), Object.keys(STATUS_META).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: s,
										className: "rounded-xl cursor-pointer",
										children: STATUS_META[s].label
									}, s))]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: sortBy,
								onValueChange: (v) => {
									setSortBy(v);
									setPage(1);
								},
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, {
									className: "w-[180px] bg-[#f5f5f7] border-transparent rounded-2xl h-11 px-4 text-sm font-medium",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, {
									className: "rounded-2xl border-gray-100 shadow-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "created_at",
										className: "rounded-xl cursor-pointer",
										children: "Sort by Date"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
										value: "experience",
										className: "rounded-xl cursor-pointer",
										children: "Sort by Experience"
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "h-11 w-11 flex items-center justify-center bg-[#f5f5f7] hover:bg-gray-200 text-[#1d1d1f] rounded-2xl transition-colors",
								onClick: () => {
									setSortOrder((o) => o === "asc" ? "desc" : "asc");
									setPage(1);
								},
								children: sortOrder === "asc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "h-4 w-4" })
							}),
							(status !== "ALL" || debouncedSearch) && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "h-11 px-5 flex items-center justify-center bg-transparent hover:bg-gray-50 text-[#86868b] border border-gray-200 rounded-2xl text-sm font-medium transition-colors",
								onClick: () => {
									setStatus("ALL");
									setSearch("");
									setDebouncedSearch("");
									setPage(1);
								},
								children: "Clear filters"
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-xs font-medium text-[#86868b] px-2",
					children: [
						total,
						" candidate",
						total !== 1 ? "s" : "",
						" found",
						totalPages > 1 && ` · Page ${page} of ${totalPages}`
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "bg-white rounded-[2rem] border border-gray-100 overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[2fr_1.5fr_2fr_1fr_1.5fr_auto] gap-4 bg-[#fbfbfd] px-8 py-5 border-b border-gray-100 items-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b]",
							children: "Applicant"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b]",
							children: "Application #"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b]",
							children: "Position"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b]",
							children: "Status"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b] flex items-center cursor-pointer hover:text-[#1d1d1f] transition-colors",
							onClick: () => toggleSort("created_at"),
							children: ["Applied ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortIcon, { field: "created_at" })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-[11px] font-bold uppercase tracking-widest text-[#86868b] text-right w-32",
							children: "Actions"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-col",
					children: isLoading ? Array.from({ length: PAGE_SIZE }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[2fr_1.5fr_2fr_1fr_1.5fr_auto] gap-4 px-8 py-6 border-b border-gray-50/50 items-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-32" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-20" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-24" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-20 rounded-full" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-24" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-16 ml-auto" })
						]
					}, i)) : rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "py-16 text-center text-sm font-medium text-[#86868b]",
						children: "No candidates found."
					}) : rows.map((c) => {
						const s = statusMeta(c.status);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[2fr_1.5fr_2fr_1fr_1.5fr_auto] gap-4 px-8 py-5 border-b border-gray-50/50 hover:bg-[#f5f5f7]/60 transition-colors items-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0 pr-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-sm font-bold text-[#1d1d1f] truncate",
										children: [
											c.first_name,
											" ",
											c.last_name
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-xs font-medium text-[#86868b] truncate mt-0.5",
										children: c.email
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xs font-semibold text-[#1d1d1f] truncate",
									children: c.application_number
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-sm font-medium text-[#1d1d1f] truncate pr-4",
									children: c.position_applied_for ?? "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-xs font-semibold tracking-wide ${s.className}`,
									children: s.label
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs font-medium text-[#86868b]",
									children: new Date(c.created_at).toLocaleDateString()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-end gap-2 w-32",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: `/candidates/${c.candidate_id}`,
										className: "bg-transparent hover:bg-gray-100 text-[#1d1d1f] rounded-full px-4 py-1.5 text-xs font-bold transition-all",
										children: "Open"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ContextAction, {
										status: c.status,
										id: c.candidate_id
									})]
								})
							]
						}, c.candidate_id);
					})
				})]
			}),
			totalPages > 1 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-sm text-muted-foreground",
					children: [
						"Showing ",
						(page - 1) * PAGE_SIZE + 1,
						"–",
						Math.min(page * PAGE_SIZE, total),
						" of ",
						total
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							disabled: page <= 1,
							onClick: () => setPage((p) => p - 1),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "h-4 w-4" }), " Previous"]
						}),
						Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
							const pageNum = Math.max(1, Math.min(page - 2, totalPages - 4)) + i;
							if (pageNum > totalPages) return null;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: pageNum === page ? "default" : "outline",
								size: "sm",
								className: "w-9",
								onClick: () => setPage(pageNum),
								children: pageNum
							}, pageNum);
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							size: "sm",
							disabled: page >= totalPages,
							onClick: () => setPage((p) => p + 1),
							children: ["Next ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "h-4 w-4" })]
						})
					]
				})]
			})
		]
	});
}
function ContextAction({ status, id }) {
	if (status.startsWith("TECHNICAL_")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: `/interviewer/evaluate/${id}`,
		className: "bg-[#0066cc] hover:bg-[#005bb5] text-white rounded-full px-4 py-1.5 text-xs font-bold transition-all shadow-sm active:scale-[0.98]",
		children: "Evaluate"
	});
	switch (status) {
		case "RECEPTION_FORWARDED": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: `/hr/review/${id}`,
			className: "bg-[#0066cc] hover:bg-[#005bb5] text-white rounded-full px-4 py-1.5 text-xs font-bold transition-all shadow-sm active:scale-[0.98]",
			children: "Review"
		});
		case "CEO_ROUND": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: `/ceo/evaluate/${id}`,
			className: "bg-[#0066cc] hover:bg-[#005bb5] text-white rounded-full px-4 py-1.5 text-xs font-bold transition-all shadow-sm active:scale-[0.98]",
			children: "CEO Review"
		});
		case "FINAL_DISCUSSION_PENDING": return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: `/final-decision/${id}`,
			className: "bg-[#1d1d1f] hover:bg-black text-white rounded-full px-4 py-1.5 text-xs font-bold transition-all shadow-sm active:scale-[0.98]",
			children: "Decide"
		});
		default: return null;
	}
}
//#endregion
export { CandidatesPage as component };
