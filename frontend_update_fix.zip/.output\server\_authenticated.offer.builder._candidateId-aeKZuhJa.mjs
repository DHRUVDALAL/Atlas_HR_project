import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { t as cn } from "./_ssr/utils-BjLc2HNT.mjs";
import { t as Button } from "./_ssr/button-B_S4Wnqd.mjs";
import { t as Badge } from "./_ssr/badge-2MwuhCYP.mjs";
import { g as Link, v as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { I as GraduationCap, O as Mail, V as FileCheck, b as Save, bt as ArrowLeft, ht as Briefcase, v as Send, w as Phone } from "./_libs/lucide-react.mjs";
import { t as Skeleton } from "./_ssr/skeleton-CV0KcoPv.mjs";
import { t as Card } from "./_ssr/card-CIRKiXmB.mjs";
import { t as Route } from "./_authenticated.offer.builder._candidateId-Bu_sxfKN.mjs";
import { t as Root } from "./_libs/radix-ui__react-separator.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.offer.builder._candidateId-aeKZuhJa.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Separator = import_react.forwardRef(({ className, orientation = "horizontal", decorative = true, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	decorative,
	orientation,
	className: cn("shrink-0 bg-border", orientation === "horizontal" ? "h-[1px] w-full" : "h-full w-[1px]", className),
	...props
}));
Separator.displayName = Root.displayName;
function OfferBuilder() {
	const { candidateId } = Route.useParams();
	const navigate = useNavigate();
	const queryClient = useQueryClient();
	const { data: candidate, isLoading: candidateLoading } = useQuery({
		queryKey: ["candidate", candidateId],
		queryFn: () => api(`/api/applicants/${candidateId}`)
	});
	const { data: existingOffer } = useQuery({
		queryKey: ["offer", candidateId],
		queryFn: () => api(`/api/offers/candidate/${candidateId}`).then((r) => r.success ? r.data : null),
		retry: false
	});
	const { data: interviewAssignment } = useQuery({
		queryKey: [
			"interview",
			"assignment",
			candidateId
		],
		queryFn: () => api(`/api/interview/assignment/${candidateId}`).then((r) => r.assignment),
		retry: false
	});
	const { data: interviewScore } = useQuery({
		queryKey: [
			"interview",
			"result",
			candidateId
		],
		queryFn: () => api(`/api/interview/result/${candidateId}`).then((r) => r.score),
		retry: false
	});
	const [offeredCtc, setOfferedCtc] = (0, import_react.useState)("");
	const [joiningDate, setJoiningDate] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [errors, setErrors] = (0, import_react.useState)({});
	(0, import_react.useEffect)(() => {
		if (existingOffer) {
			setOfferedCtc(existingOffer.offered_ctc?.toString() || "");
			setJoiningDate(existingOffer.joining_date || "");
			setNotes(existingOffer.notes || "");
		}
	}, [existingOffer]);
	const createMutation = useMutation({
		mutationFn: async () => {
			const payload = { candidate_id: candidateId };
			if (offeredCtc) payload.offered_ctc = parseFloat(offeredCtc);
			if (joiningDate) payload.joining_date = joiningDate;
			if (notes) payload.notes = notes;
			return api("/api/offers", {
				method: "POST",
				body: payload
			});
		},
		onSuccess: () => {
			toast.success("Offer created successfully");
			queryClient.invalidateQueries({ queryKey: ["offer", candidateId] });
			queryClient.invalidateQueries({ queryKey: ["offers"] });
		},
		onError: (err) => {
			toast.error(err.message || "Failed to create offer");
		}
	});
	const updateMutation = useMutation({
		mutationFn: async () => {
			const payload = {};
			if (offeredCtc) payload.offered_ctc = parseFloat(offeredCtc);
			if (joiningDate) payload.joining_date = joiningDate;
			if (notes) payload.notes = notes;
			return api(`/api/offers/${existingOffer?.offer_id}`, {
				method: "PUT",
				body: payload
			});
		},
		onSuccess: () => {
			toast.success("Offer updated successfully");
			queryClient.invalidateQueries({ queryKey: ["offer", candidateId] });
			queryClient.invalidateQueries({ queryKey: ["offers"] });
		},
		onError: (err) => {
			toast.error(err.message || "Failed to update offer");
		}
	});
	const sendMutation = useMutation({
		mutationFn: async () => {
			return api(`/api/offers/${existingOffer?.offer_id}/send`, {
				method: "POST",
				body: { notes: "Offer letter sent to candidate" }
			});
		},
		onSuccess: () => {
			toast.success("Offer sent successfully");
			queryClient.invalidateQueries({ queryKey: ["offer", candidateId] });
			queryClient.invalidateQueries({ queryKey: ["offers"] });
			navigate({
				to: `/offer/preview/$candidateId`,
				params: { candidateId }
			});
		},
		onError: (err) => {
			toast.error(err.message || "Failed to send offer");
		}
	});
	const validate = () => {
		const newErrors = {};
		if (!offeredCtc || parseFloat(offeredCtc) <= 0) newErrors.offeredCtc = "Offered CTC must be provided and greater than 0";
		if (!joiningDate) newErrors.joiningDate = "Joining date is required";
		setErrors(newErrors);
		return Object.keys(newErrors).length === 0;
	};
	const handleSubmit = () => {
		if (!validate()) return;
		if (existingOffer) updateMutation.mutate();
		else createMutation.mutate();
	};
	const handleSaveDraft = () => {
		if (existingOffer) updateMutation.mutate();
		else createMutation.mutate();
	};
	const handleSendOffer = () => {
		if (!validate()) return;
		if (existingOffer && existingOffer.status === "DRAFT") sendMutation.mutate();
	};
	const isPending = createMutation.isPending || updateMutation.isPending || sendMutation.isPending;
	if (candidateLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-8 max-w-4xl mx-auto space-y-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-8 w-48" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-6 space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-6 w-32" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-full" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-full" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-4 w-3/4" })
			]
		})]
	});
	if (!candidate) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "p-6 lg:p-8 max-w-4xl mx-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
			className: "p-12 text-center",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-lg font-semibold",
				children: "Candidate not found"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				variant: "outline",
				className: "mt-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/offer/queue",
					children: "Back to Queue"
				})
			})]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-8 max-w-4xl mx-auto space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "ghost",
					size: "sm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/offer/queue",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-4 w-4 mr-1" }), " Back"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-2xl font-bold tracking-tight",
					children: "Build Offer"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground mt-1",
					children: [
						"Create an offer letter for ",
						candidate.first_name,
						" ",
						candidate.last_name
					]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-5 bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-12 w-12 rounded-full bg-emerald-100 text-emerald-700 grid place-items-center font-bold text-lg",
						children: [candidate.first_name?.[0] || "", candidate.last_name?.[0] || ""]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex-1 min-w-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "font-semibold text-lg",
								children: [
									candidate.first_name,
									" ",
									candidate.last_name
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-3 mt-1 text-sm text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { className: "h-3.5 w-3.5" }),
											" ",
											candidate.email
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { className: "h-3.5 w-3.5" }),
											" ",
											candidate.phone
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "flex items-center gap-1",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-3.5 w-3.5" }),
											" ",
											candidate.position_applied_for ?? "—"
										]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2 mt-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "secondary",
										children: candidate.application_number
									}),
									candidate.professional_details?.current_company && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
										variant: "outline",
										children: candidate.professional_details.current_company
									}),
									candidate.professional_details?.current_ctc && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
										variant: "outline",
										children: [
											"Current CTC: ₹",
											candidate.professional_details.current_ctc,
											" LPA"
										]
									}),
									candidate.professional_details?.expected_ctc && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
										variant: "outline",
										children: [
											"Expected: ₹",
											candidate.professional_details.expected_ctc,
											" LPA"
										]
									})
								]
							})
						]
					})]
				})
			}),
			(interviewAssignment || interviewScore) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GraduationCap, { className: "h-5 w-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "Technical Interview Details"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid sm:grid-cols-2 lg:grid-cols-4 gap-4 text-sm",
						children: interviewAssignment && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-wide text-muted-foreground",
								children: "Domain"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 font-medium",
								children: interviewAssignment.domain_code
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-wide text-muted-foreground",
								children: "Experience Bracket"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 font-medium",
								children: interviewAssignment.experience_bracket_label ?? interviewAssignment.experience_bracket_code
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-wide text-muted-foreground",
								children: "Interviewer"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 font-medium",
								children: interviewAssignment.assigned_interviewer
							})] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "text-xs uppercase tracking-wide text-muted-foreground",
								children: "Interview Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-1 font-medium",
								children: interviewAssignment.created_at ? new Date(interviewAssignment.created_at).toLocaleDateString() : "—"
							})] })
						] })
					}),
					interviewScore && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator, { className: "my-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid sm:grid-cols-3 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-3 bg-muted/50 rounded-lg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-2xl font-bold text-primary",
									children: [interviewScore.overall_percentage?.toFixed(1) ?? 0, "%"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground mt-1",
									children: "Technical Score"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-3 bg-muted/50 rounded-lg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: interviewScore.recommendation === "Excellent" || interviewScore.recommendation === "Very Strong" ? "default" : interviewScore.recommendation === "Needs Improvement" ? "destructive" : "secondary",
									className: "text-sm font-semibold",
									children: interviewScore.recommendation ?? "N/A"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground mt-1",
									children: "Recommendation"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-center p-3 bg-muted/50 rounded-lg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-2xl font-bold",
									children: [
										interviewScore.answered_questions ?? 0,
										"/",
										interviewScore.total_questions ?? 0
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-muted-foreground mt-1",
									children: "Questions Rated"
								})]
							})
						]
					})] })
				]
			}),
			existingOffer && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, {
				className: "p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-medium",
							children: "Offer Status:"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: existingOffer.status === "ACCEPTED" ? "default" : existingOffer.status === "DECLINED" ? "destructive" : "secondary",
							children: existingOffer.status
						}),
						existingOffer.status === "DRAFT" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground ml-2",
							children: "— You can edit and send this offer"
						}),
						existingOffer.status === "SENT" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted-foreground ml-2",
							children: "— Waiting for candidate response"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 mb-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileCheck, { className: "h-5 w-5 text-primary" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold",
							children: "Offer Details"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-2 gap-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-sm font-medium",
										children: ["Offered CTC (Annual LPA) ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-destructive",
											children: "*"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "number",
										step: "0.1",
										min: "0",
										value: offeredCtc,
										onChange: (e) => setOfferedCtc(e.target.value),
										placeholder: "e.g. 12.5",
										disabled: existingOffer?.status !== "DRAFT" && !!existingOffer,
										className: "w-full px-3 py-2 text-sm border rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring " + (errors.offeredCtc ? "border-destructive" : "") + (existingOffer?.status !== "DRAFT" && !!existingOffer ? " opacity-50 cursor-not-allowed" : "")
									}),
									errors.offeredCtc && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-destructive",
										children: errors.offeredCtc
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-sm font-medium",
										children: ["Joining Date ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-destructive",
											children: "*"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "date",
										value: joiningDate,
										onChange: (e) => setJoiningDate(e.target.value),
										disabled: existingOffer?.status !== "DRAFT" && !!existingOffer,
										className: "w-full px-3 py-2 text-sm border rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring " + (errors.joiningDate ? "border-destructive" : "") + (existingOffer?.status !== "DRAFT" && !!existingOffer ? " opacity-50 cursor-not-allowed" : "")
									}),
									errors.joiningDate && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-destructive",
										children: errors.joiningDate
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 md:col-span-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-sm font-medium",
									children: "Notes"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: notes,
									onChange: (e) => setNotes(e.target.value),
									placeholder: "Additional notes for the offer...",
									rows: 3,
									disabled: existingOffer?.status !== "DRAFT" && !!existingOffer,
									className: "w-full px-3 py-2 text-sm border rounded-md bg-background focus:outline-none focus:ring-2 focus:ring-ring resize-none" + (existingOffer?.status !== "DRAFT" && !!existingOffer ? " opacity-50 cursor-not-allowed" : "")
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-3 mt-6 pt-6 border-t",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: handleSaveDraft,
							disabled: isPending,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4 mr-2" }), isPending ? "Saving..." : existingOffer ? "Update Draft" : "Save Draft"]
						}), (!existingOffer || existingOffer.status === "DRAFT") && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: handleSubmit,
							disabled: isPending,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4 mr-2" }), isPending ? "Saving..." : existingOffer ? "Update & Send" : "Create & Send"]
						}), existingOffer && existingOffer.status === "DRAFT" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: handleSendOffer,
							disabled: isPending,
							variant: "default",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4 mr-2" }), isPending ? "Sending..." : "Send Offer"]
						})] })]
					})
				]
			})
		]
	});
}
//#endregion
export { OfferBuilder as component };
