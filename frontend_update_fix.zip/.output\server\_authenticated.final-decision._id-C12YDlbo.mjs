import { o as __toESM } from "./_runtime.mjs";
import { n as api } from "./_ssr/api-85Rra_o2.mjs";
import { u as require_react } from "./_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "./_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link, v as useNavigate } from "./_libs/@tanstack/react-router+[...].mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "./_libs/tanstack__react-query.mjs";
import { n as toast } from "./_libs/sonner.mjs";
import { $ as CircleX, B as FileText, D as MapPin, K as DollarSign, L as Gavel, Y as Clock, b as Save, bt as ArrowLeft, ht as Briefcase, i as User, m as Star, mt as Building, nt as CircleCheck, pt as Calendar, tt as CirclePause, v as Send } from "./_libs/lucide-react.mjs";
import { n as AnimatePresence, t as motion } from "./_libs/framer-motion+[...].mjs";
import { t as Route } from "./_authenticated.final-decision._id-BrrAJ0vB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_authenticated.final-decision._id-C12YDlbo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FinalDecision() {
	const { id } = Route.useParams();
	const nav = useNavigate();
	const qc = useQueryClient();
	const { data: candidate, isLoading: candidateLoading } = useQuery({
		queryKey: ["candidate", id],
		queryFn: () => api(`/api/applicants/${id}`).then((r) => r.data)
	});
	const rounds = candidate?.interview_rounds ?? [];
	const techRounds = rounds.filter((r) => r.round_type === "TECHNICAL");
	const ceoRounds = rounds.filter((r) => r.round_type === "CEO_ROUND");
	const [finalStatus, setFinalStatus] = (0, import_react.useState)("SELECTED");
	const [offeredCtc, setOfferedCtc] = (0, import_react.useState)("");
	const [joiningDate, setJoiningDate] = (0, import_react.useState)("");
	const [approvedBy, setApprovedBy] = (0, import_react.useState)("");
	const [finalRemarks, setFinalRemarks] = (0, import_react.useState)("");
	const [hrDiscussionNotes, setHrDiscussionNotes] = (0, import_react.useState)("");
	const [hrDiscussion, setHrDiscussion] = (0, import_react.useState)("");
	const [ceoDiscussion, setCeoDiscussion] = (0, import_react.useState)("");
	const [activeTab, setActiveTab] = (0, import_react.useState)(techRounds.length > 0 ? "technical" : "ceo");
	const submit = useMutation({
		mutationFn: (saveDraft) => api(`/api/workflow/final-decision/${id}`, {
			method: "POST",
			body: {
				final_status: saveDraft ? void 0 : finalStatus,
				offered_ctc: !saveDraft && finalStatus === "SELECTED" && offeredCtc ? Number(offeredCtc) : void 0,
				joining_date: !saveDraft && finalStatus === "SELECTED" && joiningDate ? joiningDate : void 0,
				approved_by: approvedBy || void 0,
				final_remarks: finalRemarks || void 0,
				hr_discussion_notes: hrDiscussionNotes || void 0,
				hr_discussion: hrDiscussion || void 0,
				ceo_discussion: ceoDiscussion || void 0,
				save_draft: saveDraft
			}
		}),
		onSuccess: (_, saveDraft) => {
			toast.success(saveDraft ? "Draft saved" : "Final decision recorded");
			qc.invalidateQueries();
			nav({ to: saveDraft ? `/ceo/queue` : `/candidates/${id}` });
		},
		onError: (e) => toast.error(e instanceof Error ? e.message : "Failed")
	});
	if (candidateLoading) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-40 bg-gray-100 rounded-full animate-pulse" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-64 bg-gray-100 rounded-full animate-pulse" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-5 gap-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-3 space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-96 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
						children: Array.from({ length: 3 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-24 w-full bg-gray-100 rounded-2xl animate-pulse" }, i))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-2 space-y-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-32 bg-gray-100 rounded-full animate-pulse" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 space-y-4 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
						children: Array.from({ length: 5 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-full bg-gray-100 rounded-xl animate-pulse" }, i))
					})]
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
		initial: {
			opacity: 0,
			y: 15
		},
		animate: {
			opacity: 1,
			y: 0
		},
		transition: {
			duration: .5,
			ease: [
				.16,
				1,
				.3,
				1
			]
		},
		className: "p-6 lg:p-10 max-w-7xl mx-auto space-y-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center gap-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: `/candidates/${id}`,
					className: "flex items-center text-sm font-bold text-[#86868b] hover:text-[#1d1d1f] transition-colors bg-[#f5f5f7] px-4 py-1.5 rounded-full",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-6 w-6 rounded-full bg-white flex items-center justify-center mr-2 shadow-sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "h-3.5 w-3.5" })
					}), "Back to candidate"]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "text-3xl font-bold tracking-tighter text-[#1d1d1f] flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-12 w-12 rounded-2xl bg-amber-50 flex items-center justify-center shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Gavel, { className: "h-6 w-6 text-amber-600" })
				}), "Final Discussion & Decision"]
			}), candidate && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm font-medium text-[#86868b] mt-2 ml-[3.75rem]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-bold text-[#1d1d1f]",
						children: [
							candidate.first_name,
							" ",
							candidate.last_name
						]
					}),
					" · ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs px-2 py-0.5 rounded-md bg-[#f5f5f7]",
						children: candidate.application_number
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid lg:grid-cols-5 gap-8 items-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-3 space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl font-bold tracking-tight text-[#1d1d1f]",
							children: "Panel Feedback"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 p-1.5 bg-[#f5f5f7] rounded-full w-fit",
							children: [
								techRounds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setActiveTab("technical"),
									className: `flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-all ${activeTab === "technical" ? "bg-white text-[#1d1d1f] shadow-sm" : "text-[#86868b] hover:text-[#1d1d1f] hover:bg-gray-200/50"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "h-4 w-4" }),
										" Technical (",
										techRounds.length,
										")"
									]
								}),
								ceoRounds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setActiveTab("ceo"),
									className: `flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-all ${activeTab === "ceo" ? "bg-white text-[#1d1d1f] shadow-sm" : "text-[#86868b] hover:text-[#1d1d1f] hover:bg-gray-200/50"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-4 w-4" }),
										" CEO (",
										ceoRounds.length,
										")"
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => setActiveTab("profile"),
									className: `flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-all ${activeTab === "profile" ? "bg-white text-[#1d1d1f] shadow-sm" : "text-[#86868b] hover:text-[#1d1d1f] hover:bg-gray-200/50"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { className: "h-4 w-4" }), " Profile"]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AnimatePresence, {
							mode: "wait",
							children: [
								activeTab === "technical" && techRounds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									initial: {
										opacity: 0,
										y: 10
									},
									animate: {
										opacity: 1,
										y: 0
									},
									exit: {
										opacity: 0,
										y: -10
									},
									transition: { duration: .2 },
									className: "space-y-4",
									children: techRounds.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "text-lg font-bold tracking-tight text-[#1d1d1f]",
													children: ["Technical Round #", r.round_number]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${r.status === "COMPLETED" ? "bg-emerald-50 text-emerald-700" : "bg-gray-100 text-gray-700"}`,
													children: r.status
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 text-[11px] font-bold text-[#86868b] uppercase tracking-wider mb-6 pb-4 border-b border-gray-50",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.interviewer_email }), r.completed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1 h-1 rounded-full bg-gray-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: new Date(r.completed_at).toLocaleDateString(void 0, {
													year: "numeric",
													month: "short",
													day: "numeric"
												}) })] })]
											}),
											r.evaluation_data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "space-y-4 mb-6",
												children: Object.entries(r.evaluation_data).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between gap-4",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-sm font-medium text-[#1d1d1f]",
														children: k
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1.5 bg-[#fbfbfd] px-3 py-1 rounded-full border border-gray-100",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-3.5 w-3.5 text-[#0066cc] fill-[#0066cc]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-mono text-sm font-bold text-[#1d1d1f]",
															children: [v.rating, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[#86868b]",
																children: "/5"
															})]
														})]
													})]
												}, k))
											}),
											r.remarks && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#fbfbfd] p-4 rounded-2xl border border-gray-50",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[10px] font-bold text-[#86868b] uppercase tracking-widest mb-2",
													children: "Remarks"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-medium text-[#1d1d1f] leading-relaxed",
													children: r.remarks
												})]
											})
										]
									}, r.round_id))
								}, "technical"),
								activeTab === "ceo" && ceoRounds.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									initial: {
										opacity: 0,
										y: 10
									},
									animate: {
										opacity: 1,
										y: 0
									},
									exit: {
										opacity: 0,
										y: -10
									},
									transition: { duration: .2 },
									className: "space-y-4",
									children: ceoRounds.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-6 rounded-[2rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center justify-between mb-4",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-lg font-bold tracking-tight text-[#1d1d1f]",
													children: "CEO Evaluation"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: `inline-flex items-center justify-center rounded-full px-3 py-1 text-[10px] font-bold uppercase tracking-wider ${r.status === "COMPLETED" ? "bg-emerald-50 text-emerald-700" : "bg-gray-100 text-gray-700"}`,
													children: r.status
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "flex items-center gap-2 text-[11px] font-bold text-[#86868b] uppercase tracking-wider mb-6 pb-4 border-b border-gray-50",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: r.interviewer_email }), r.completed_at && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "w-1 h-1 rounded-full bg-gray-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: new Date(r.completed_at).toLocaleDateString(void 0, {
													year: "numeric",
													month: "short",
													day: "numeric"
												}) })] })]
											}),
											r.evaluation_data && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "space-y-4 mb-6",
												children: Object.entries(r.evaluation_data).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: "flex items-center justify-between gap-4",
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
														className: "text-sm font-medium text-[#1d1d1f]",
														children: k
													}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
														className: "flex items-center gap-1.5 bg-[#fbfbfd] px-3 py-1 rounded-full border border-gray-100",
														children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, { className: "h-3.5 w-3.5 text-[#0066cc] fill-[#0066cc]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
															className: "font-mono text-sm font-bold text-[#1d1d1f]",
															children: [v.rating, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
																className: "text-[#86868b]",
																children: "/5"
															})]
														})]
													})]
												}, k))
											}),
											r.remarks && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "bg-[#fbfbfd] p-4 rounded-2xl border border-gray-50",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-[10px] font-bold text-[#86868b] uppercase tracking-widest mb-2",
													children: "Executive Remarks"
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "text-sm font-medium text-[#1d1d1f] leading-relaxed",
													children: r.remarks
												})]
											})
										]
									}, r.round_id))
								}, "ceo"),
								activeTab === "profile" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
									initial: {
										opacity: 0,
										y: 10
									},
									animate: {
										opacity: 1,
										y: 0
									},
									exit: {
										opacity: 0,
										y: -10
									},
									transition: { duration: .2 },
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] grid sm:grid-cols-2 gap-x-8 gap-y-6",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-4 h-4" }),
												label: "Name",
												value: `${candidate?.first_name} ${candidate?.last_name}`
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { className: "w-4 h-4" }),
												label: "Position",
												value: candidate?.position_applied_for
											}),
											candidate?.applied_from && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "w-4 h-4" }),
												label: "Applied From",
												value: candidate.applied_from
											}),
											candidate?.applied_from === "REFERRAL" && candidate?.source_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(User, { className: "w-4 h-4" }),
												label: "Referred By",
												value: candidate.source_name
											}),
											candidate?.applied_from === "VENDOR" && candidate?.source_name && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "w-4 h-4" }),
												label: "Vendor Name",
												value: candidate.source_name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { className: "w-4 h-4" }),
												label: "Domain",
												value: candidate?.domain
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock, { className: "w-4 h-4" }),
												label: "Experience",
												value: candidate?.professional_details?.total_experience ? `${candidate.professional_details.total_experience} yrs` : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "w-4 h-4" }),
												label: "Current CTC",
												value: candidate?.professional_details?.current_ctc ? `₹${candidate.professional_details.current_ctc} LPA` : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "w-4 h-4" }),
												label: "Expected CTC",
												value: candidate?.professional_details?.expected_ctc ? `₹${candidate.professional_details.expected_ctc} LPA` : "—"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calendar, { className: "w-4 h-4" }),
												label: "Notice Period",
												value: candidate?.professional_details?.notice_period
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
												icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "w-4 h-4" }),
												label: "Preferred Location",
												value: candidate?.professional_details?.preferred_location
											})
										]
									})
								}, "profile")
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "lg:col-span-2 space-y-6 lg:sticky lg:top-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xl font-bold tracking-tight text-[#1d1d1f]",
						children: "Decision Formulation"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "bg-white p-8 rounded-[2.5rem] border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)] space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
									children: "HR Discussion Notes"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: hrDiscussionNotes,
									onChange: (e) => setHrDiscussionNotes(e.target.value),
									placeholder: "Notes from HR discussion…",
									rows: 2,
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl p-4 text-sm font-medium text-[#1d1d1f] transition-all outline-none resize-none placeholder:text-gray-400"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
									children: "HR Discussion Summary"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: hrDiscussion,
									onChange: (e) => setHrDiscussion(e.target.value),
									placeholder: "Salary negotiation, benefits…",
									rows: 2,
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl p-4 text-sm font-medium text-[#1d1d1f] transition-all outline-none resize-none placeholder:text-gray-400"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
									className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
									children: "CEO Discussion Notes"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
									value: ceoDiscussion,
									onChange: (e) => setCeoDiscussion(e.target.value),
									placeholder: "CEO feedback…",
									rows: 2,
									className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl p-4 text-sm font-medium text-[#1d1d1f] transition-all outline-none resize-none placeholder:text-gray-400"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "border-t border-gray-100 pt-6 space-y-6",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-3",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
											children: "Final Outcome"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "grid grid-cols-3 gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: () => setFinalStatus("SELECTED"),
													className: `flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all ${finalStatus === "SELECTED" ? "border-emerald-500 bg-emerald-50 text-emerald-700 shadow-sm" : "border-transparent bg-[#f5f5f7] text-[#86868b] hover:bg-gray-200"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: `w-5 h-5 mb-1.5 ${finalStatus === "SELECTED" ? "text-emerald-500" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold uppercase tracking-wide",
														children: "Select"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: () => setFinalStatus("HOLD"),
													className: `flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all ${finalStatus === "HOLD" ? "border-amber-500 bg-amber-50 text-amber-700 shadow-sm" : "border-transparent bg-[#f5f5f7] text-[#86868b] hover:bg-gray-200"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CirclePause, { className: `w-5 h-5 mb-1.5 ${finalStatus === "HOLD" ? "text-amber-500" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold uppercase tracking-wide",
														children: "Hold"
													})]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													onClick: () => setFinalStatus("REJECTED"),
													className: `flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all ${finalStatus === "REJECTED" ? "border-red-500 bg-red-50 text-red-700 shadow-sm" : "border-transparent bg-[#f5f5f7] text-[#86868b] hover:bg-gray-200"}`,
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleX, { className: `w-5 h-5 mb-1.5 ${finalStatus === "REJECTED" ? "text-red-500" : ""}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "text-[10px] font-bold uppercase tracking-wide",
														children: "Reject"
													})]
												})
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AnimatePresence, { children: finalStatus === "SELECTED" && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
										initial: {
											opacity: 0,
											height: 0
										},
										animate: {
											opacity: 1,
											height: "auto"
										},
										exit: {
											opacity: 0,
											height: 0
										},
										className: "space-y-6 overflow-hidden",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
												children: "Offered CTC (LPA)"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "relative",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DollarSign, { className: "absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													type: "number",
													step: "0.1",
													value: offeredCtc,
													onChange: (e) => setOfferedCtc(e.target.value),
													placeholder: "e.g. 12.5",
													className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl py-3.5 pl-11 pr-4 text-sm font-bold text-[#1d1d1f] transition-all outline-none placeholder:font-medium placeholder:text-gray-400"
												})]
											})]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "space-y-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
												className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
												children: "Joining Date"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												type: "date",
												value: joiningDate,
												onChange: (e) => setJoiningDate(e.target.value),
												className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl py-3.5 px-4 text-sm font-bold text-[#1d1d1f] transition-all outline-none"
											})]
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
											children: "Approved By"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											type: "text",
											value: approvedBy,
											onChange: (e) => setApprovedBy(e.target.value),
											placeholder: "Approver name or email",
											className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl py-3.5 px-4 text-sm font-medium text-[#1d1d1f] transition-all outline-none placeholder:text-gray-400"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
											className: "text-[11px] font-bold text-[#86868b] uppercase tracking-wider ml-1",
											children: "Final Remarks"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
											value: finalRemarks,
											onChange: (e) => setFinalRemarks(e.target.value),
											placeholder: "Decision rationale…",
											rows: 3,
											className: "w-full bg-[#f5f5f7] border-transparent focus:border-[#0066cc] focus:ring-4 focus:ring-[#0066cc]/10 rounded-2xl p-4 text-sm font-medium text-[#1d1d1f] transition-all outline-none resize-none placeholder:text-gray-400"
										})]
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col sm:flex-row gap-3 pt-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => submit.mutate(true),
									disabled: submit.isPending,
									className: "flex-1 inline-flex items-center justify-center px-6 py-3.5 rounded-full bg-white border border-gray-200 text-[#1d1d1f] text-sm font-bold shadow-sm hover:bg-gray-50 transition-colors disabled:opacity-50",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Save, { className: "h-4 w-4 mr-2" }), " Draft"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									onClick: () => submit.mutate(false),
									disabled: finalStatus === "SELECTED" && (!offeredCtc || !joiningDate) ? true : submit.isPending,
									className: "flex-[2] inline-flex items-center justify-center px-6 py-3.5 rounded-full bg-[#1d1d1f] text-white text-sm font-bold shadow-sm hover:bg-black transition-all active:scale-[0.98] disabled:opacity-50 disabled:active:scale-100",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, { className: "h-4 w-4 mr-2" }), " Confirm Decision"]
								})]
							})
						]
					})]
				})]
			})
		]
	});
}
function Field({ label, value, icon }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3",
		children: [icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-0.5 text-gray-400 shrink-0",
			children: icon
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-[10px] font-bold text-[#86868b] uppercase tracking-widest",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm font-medium text-[#1d1d1f] mt-1",
			children: value ?? "—"
		})] })]
	});
}
//#endregion
export { FinalDecision as component };
