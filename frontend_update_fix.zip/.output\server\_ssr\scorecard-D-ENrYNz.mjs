import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { t as cn } from "./utils-BjLc2HNT.mjs";
import { t as Card } from "./card-CIRKiXmB.mjs";
import { t as Label } from "./label-BgXw8JJ9.mjs";
import { t as Textarea } from "./textarea-DrnUOz5f.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/scorecard-D-ENrYNz.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useScorecard(dimensions) {
	const [state, setState] = (0, import_react.useState)(() => Object.fromEntries(dimensions.map((d) => [d, {
		rating: 0,
		remarks: ""
	}])));
	const update = (dim, patch) => setState((prev) => ({
		...prev,
		[dim]: {
			...prev[dim],
			...patch
		}
	}));
	return {
		state,
		update,
		isComplete: dimensions.every((d) => (state[d]?.rating ?? 0) > 0)
	};
}
function ScorecardEditor({ dimensions, scorecard, onUpdate }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: dimensions.map((dim) => {
			const v = scorecard[dim] ?? {
				rating: 0,
				remarks: ""
			};
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, {
				className: "p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start justify-between gap-4 flex-wrap",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
						className: "text-sm font-medium",
						children: dim
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex gap-1",
						children: [
							1,
							2,
							3,
							4,
							5
						].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => onUpdate(dim, { rating: n }),
							className: cn("h-9 w-9 rounded-md border text-sm font-medium transition-colors", v.rating >= n ? "bg-primary text-primary-foreground border-primary" : "bg-background hover:bg-accent"),
							"aria-label": `${n} out of 5`,
							children: n
						}, n))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					placeholder: "Remarks (optional)",
					value: v.remarks,
					onChange: (e) => onUpdate(dim, { remarks: e.target.value }),
					className: "mt-3 min-h-[70px]"
				})]
			}, dim);
		})
	});
}
//#endregion
export { useScorecard as n, ScorecardEditor as t };
