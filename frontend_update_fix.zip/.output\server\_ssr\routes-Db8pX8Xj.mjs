import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { D as MapPin, O as Mail, h as Shield, ht as Briefcase, mt as Building, nt as CircleCheck, r as Users, t as Zap, w as Phone, yt as ArrowRight } from "../_libs/lucide-react.mjs";
import { t as motion } from "../_libs/framer-motion+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Db8pX8Xj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LandingPage() {
	const containerRef = (0, import_react.useRef)(null);
	const smoothEase = [
		.16,
		1,
		.3,
		1
	];
	const fadeInUp = {
		hidden: {
			opacity: 0,
			y: 40
		},
		visible: {
			opacity: 1,
			y: 0,
			transition: {
				duration: .8,
				ease: smoothEase
			}
		}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-[#fbfbfd] text-[#1d1d1f] font-sans overflow-x-hidden selection:bg-[#0066cc] selection:text-white",
		ref: containerRef,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed top-0 left-0 right-0 z-50 bg-white/70 backdrop-blur-md border-b border-gray-200/50",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-7xl mx-auto px-6 h-16 flex items-center justify-between",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/logo.png",
									alt: "Atlas Logo",
									className: "h-6 w-auto"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-bold text-xl tracking-tight",
									children: "ATLAS"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs px-2 py-1 bg-gray-100 text-gray-500 rounded-full font-medium",
									children: "by Abhiyanta"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden md:flex items-center gap-8 text-sm font-medium text-gray-500",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#features",
									className: "hover:text-black transition-colors",
									children: "Features"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#workflow",
									className: "hover:text-black transition-colors",
									children: "Workflow"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#about",
									className: "hover:text-black transition-colors",
									children: "About Us"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: "#contact",
									className: "hover:text-black transition-colors",
									children: "Contact"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								className: "text-sm font-medium hover:text-black transition-colors hidden md:block",
								children: "Staff Login"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/register-candidate",
								className: "bg-black text-white px-5 py-2 rounded-full text-sm font-medium hover:scale-105 hover:bg-gray-800 transition-all",
								children: "Apply Now"
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative pt-32 pb-20 md:pt-48 md:pb-32 px-6 flex flex-col items-center justify-center min-h-[90vh] overflow-hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-100/40 rounded-full blur-3xl -z-10" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: "hidden",
						animate: "visible",
						variants: {
							hidden: { opacity: 0 },
							visible: {
								opacity: 1,
								transition: {
									staggerChildren: .1,
									delayChildren: .2
								}
							}
						},
						className: "text-center max-w-4xl mx-auto z-10",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								variants: fadeInUp,
								className: "mb-6 inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white border border-gray-200 shadow-sm text-sm font-medium text-gray-600",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, { className: "w-4 h-4 text-[#0066cc]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Introducing ATLAS for SAP Partners" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.h1, {
								variants: fadeInUp,
								className: "text-6xl md:text-8xl font-bold tracking-tighter leading-tight mb-8 text-black",
								children: [
									"Hiring.",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
									"Perfected."
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.p, {
								variants: fadeInUp,
								className: "text-xl md:text-2xl text-[#86868b] max-w-2xl mx-auto mb-10 leading-relaxed font-medium",
								children: "The ultimate Interview Management System engineered exclusively for Abhiyanta India Solutions. Precision, speed, and intelligence in every hire."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								variants: fadeInUp,
								className: "flex flex-col sm:flex-row items-center justify-center gap-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/register-candidate",
									className: "w-full sm:w-auto bg-[#0066cc] text-white px-8 py-4 rounded-full text-lg font-medium hover:bg-[#0055b3] hover:scale-105 transition-all shadow-lg shadow-blue-500/25",
									children: "Start Application"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: "#features",
									className: "w-full sm:w-auto group flex items-center justify-center gap-2 px-8 py-4 text-lg font-medium text-gray-900 hover:text-[#0066cc] transition-colors",
									children: ["Explore the platform", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-5 h-5 group-hover:translate-x-1 transition-transform" })]
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 100,
							scale: .95
						},
						animate: {
							opacity: 1,
							y: 0,
							scale: 1
						},
						transition: {
							duration: 1,
							delay: .4,
							ease: smoothEase
						},
						className: "mt-20 w-full max-w-6xl mx-auto bg-white rounded-2xl md:rounded-[2.5rem] shadow-2xl shadow-gray-200/50 border border-gray-100 overflow-hidden relative z-10 flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-12 bg-gray-50 border-b border-gray-100 flex items-center px-6 gap-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-3 h-3 rounded-full bg-gray-300 hover:bg-red-400 transition-colors" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-3 h-3 rounded-full bg-gray-300 hover:bg-amber-400 transition-colors" }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-3 h-3 rounded-full bg-gray-300 hover:bg-green-400 transition-colors" })
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "aspect-[16/9] bg-gradient-to-br from-gray-50 to-white flex items-center justify-center p-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "w-full h-full flex gap-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "w-1/4 h-full bg-white rounded-xl shadow-sm border border-gray-100 p-4 hidden md:block",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 w-24 bg-gray-200 rounded mb-8" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "space-y-4",
										children: [
											1,
											2,
											3,
											4,
											5
										].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-full bg-gray-50 rounded-lg border border-gray-100" }, i))
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex-1 flex flex-col gap-6",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "h-24 w-full bg-white rounded-xl shadow-sm border border-gray-100 p-6 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center text-[#0066cc]",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { size: 20 })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-5 w-48 bg-gray-200 rounded mb-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-32 bg-gray-100 rounded" })] })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-24 bg-[#0066cc]/10 rounded-full" })]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex-1 w-full bg-white rounded-xl shadow-sm border border-gray-100 p-6",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex justify-between items-center mb-6",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-6 w-32 bg-gray-200 rounded" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-8 w-8 bg-gray-100 rounded-full" })]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "space-y-3",
											children: [
												1,
												2,
												3,
												4
											].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-16 w-full bg-gray-50 rounded-lg border border-gray-100" }, i))
										})]
									})]
								})]
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "features",
				className: "py-32 px-6 bg-white border-t border-gray-100",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-7xl mx-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: "hidden",
						whileInView: "visible",
						viewport: {
							once: true,
							margin: "-100px"
						},
						variants: fadeInUp,
						className: "text-center mb-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
							className: "text-5xl md:text-7xl font-bold tracking-tighter mb-6",
							children: [
								"Everything you need.",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"Nothing you don't."
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl text-[#86868b] max-w-2xl mx-auto",
							children: "A seamless orchestration of tools designed specifically for SAP consulting pipelines."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-1 md:grid-cols-3 gap-6 auto-rows-[400px]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									y: 30
								},
								whileInView: {
									opacity: 1,
									y: 0
								},
								viewport: { once: true },
								transition: {
									duration: .8,
									ease: smoothEase
								},
								className: "md:col-span-2 bg-[#fbfbfd] rounded-[2rem] p-10 overflow-hidden relative group border border-gray-100 shadow-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative z-10",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-12 h-12 bg-white rounded-2xl flex items-center justify-center mb-6 shadow-sm border border-gray-100 text-[#0066cc]",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { size: 24 })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "text-3xl font-bold tracking-tight mb-4 text-black",
											children: "The 8-Step Wizard."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-lg text-[#86868b] max-w-md leading-relaxed",
											children: "Candidate registration, reimagined. A seamless, client-side 8-step wizard from personal details to situational judgment."
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "absolute right-0 bottom-0 w-[60%] h-[70%] bg-white rounded-tl-[2rem] shadow-[0_-10px_40px_rgba(0,0,0,0.05)] border-t border-l border-gray-100 translate-y-8 translate-x-8 group-hover:translate-y-6 group-hover:translate-x-6 transition-transform duration-500 p-6 flex flex-col gap-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-[#0066cc]" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-32 bg-gray-200 rounded" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-4",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "w-6 h-6 rounded-full bg-blue-50 flex items-center justify-center",
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "w-4 h-4 text-[#0066cc]" })
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-40 bg-gray-200 rounded" })]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-center gap-4 opacity-50",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-6 h-6 rounded-full border border-gray-300" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-3 w-28 bg-gray-200 rounded" })]
										})
									]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									y: 30
								},
								whileInView: {
									opacity: 1,
									y: 0
								},
								viewport: { once: true },
								transition: {
									duration: .8,
									delay: .1,
									ease: smoothEase
								},
								className: "md:col-span-1 bg-[#fbfbfd] rounded-[2rem] p-10 overflow-hidden relative border border-gray-100 shadow-sm hover:shadow-md transition-shadow",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-12 h-12 bg-white rounded-2xl flex items-center justify-center mb-6 shadow-sm border border-gray-100 text-amber-500",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Briefcase, { size: 24 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-3xl font-bold tracking-tight mb-4 text-black",
										children: "SAP Scorecards."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-lg text-[#86868b] leading-relaxed",
										children: "Built for SAP. Dedicated scorecards for FI, CO, MM, SD, and 6 other core domains."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									y: 30
								},
								whileInView: {
									opacity: 1,
									y: 0
								},
								viewport: { once: true },
								transition: {
									duration: .8,
									delay: .2,
									ease: smoothEase
								},
								className: "md:col-span-1 bg-[#fbfbfd] rounded-[2rem] p-10 overflow-hidden relative border border-gray-100 shadow-sm hover:shadow-md transition-shadow",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-12 h-12 bg-white rounded-2xl flex items-center justify-center mb-6 shadow-sm border border-gray-100 text-emerald-500",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shield, { size: 24 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-3xl font-bold tracking-tight mb-4 text-black",
										children: "Granular RBAC."
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-lg text-[#86868b] leading-relaxed",
										children: "Total Control. 15 permission nodes. 7 distinct roles. Uncompromising security for enterprise data."
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
								initial: {
									opacity: 0,
									y: 30
								},
								whileInView: {
									opacity: 1,
									y: 0
								},
								viewport: { once: true },
								transition: {
									duration: .8,
									delay: .3,
									ease: smoothEase
								},
								className: "md:col-span-2 bg-[#fbfbfd] rounded-[2rem] p-10 overflow-hidden flex flex-col justify-between border border-gray-100 shadow-sm hover:shadow-md transition-shadow",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "max-w-xl",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-3xl font-bold tracking-tight mb-4 text-black",
										children: "Multi-Round Engine."
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-lg text-[#86868b] leading-relaxed",
										children: "From HR to CEO. A state-machine driven workflow that tracks technical rounds with surgical precision. Complete lock-safe concurrency prevents data collisions."
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center gap-4 mt-8",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex-1 h-2 bg-gray-200 rounded-full overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-full h-full bg-[#0066cc] rounded-full" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-5 h-5 text-gray-400" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "flex-1 h-2 bg-gray-200 rounded-full overflow-hidden",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "w-1/2 h-full bg-[#0066cc] rounded-full" })
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "w-5 h-5 text-gray-400" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1 h-2 bg-gray-200 rounded-full" })
									]
								})]
							})
						]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "workflow",
				className: "py-32 px-6 bg-[#fbfbfd] border-t border-gray-100",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-7xl mx-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-center mb-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-5xl md:text-7xl font-bold tracking-tighter mb-6 text-black",
							children: "The Pipeline."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl text-[#86868b] max-w-2xl mx-auto",
							children: "A seamless flow from initial registration to the final CEO offer."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid grid-cols-1 md:grid-cols-3 gap-12",
						children: [
							{
								num: "01",
								title: "Application Submitted",
								desc: "Candidates enter the portal. Resumes parsed. Initial data captured atomically."
							},
							{
								num: "02",
								title: "HR & Tech Review",
								desc: "Assigned interviewers evaluate SAP competencies in real-time. Lock-safe concurrency."
							},
							{
								num: "03",
								title: "The CEO Round",
								desc: "Final review. Offer generated. The pipeline concludes with absolute clarity."
							}
						].map((step, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
							initial: {
								opacity: 0,
								y: 40
							},
							whileInView: {
								opacity: 1,
								y: 0
							},
							viewport: {
								once: true,
								margin: "-100px"
							},
							transition: {
								duration: .8,
								delay: idx * .2,
								ease: smoothEase
							},
							className: "flex flex-col items-center text-center group",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-20 h-20 bg-white rounded-full flex items-center justify-center text-2xl font-bold text-gray-300 shadow-sm border border-gray-100 mb-8 group-hover:border-[#0066cc] group-hover:text-[#0066cc] transition-colors duration-500",
									children: step.num
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-2xl font-bold mb-4 text-black",
									children: step.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[#86868b] leading-relaxed max-w-sm",
									children: step.desc
								})
							]
						}, idx))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "about",
				className: "py-32 px-6 bg-white border-t border-gray-100",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-w-7xl mx-auto flex flex-col md:flex-row gap-16 items-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							x: -40
						},
						whileInView: {
							opacity: 1,
							x: 0
						},
						viewport: { once: true },
						transition: {
							duration: .8,
							ease: smoothEase
						},
						className: "flex-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "w-16 h-16 bg-blue-50 rounded-2xl flex items-center justify-center mb-8 text-[#0066cc] border border-blue-100",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Building, { size: 32 })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-4xl md:text-5xl font-bold tracking-tighter mb-6 text-black",
								children: "About Abhiyanta."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl text-[#86868b] leading-relaxed mb-6",
								children: "Abhiyanta India Solutions is a proud SAP Gold Partner, delivering enterprise-grade SAP implementations, migrations, and support worldwide."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-lg text-gray-600 leading-relaxed",
								children: "We built ATLAS to ensure our hiring process is as precise, structured, and advanced as the solutions we deliver to our clients. Talent is our greatest asset, and ATLAS ensures we identify the very best SAP professionals in the industry."
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.div, {
						initial: {
							opacity: 0,
							x: 40
						},
						whileInView: {
							opacity: 1,
							x: 0
						},
						viewport: { once: true },
						transition: {
							duration: .8,
							ease: smoothEase
						},
						className: "flex-1 w-full rounded-3xl overflow-hidden shadow-2xl shadow-blue-900/10 border border-gray-100 bg-white",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/abhiyanta_about.png",
							alt: "Abhiyanta India Solutions",
							className: "w-full h-full object-contain"
						})
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				id: "contact",
				className: "py-32 px-6 bg-[#fbfbfd] border-t border-gray-100",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "max-w-4xl mx-auto text-center",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 40
						},
						whileInView: {
							opacity: 1,
							y: 0
						},
						viewport: { once: true },
						transition: {
							duration: .8,
							ease: smoothEase
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-4xl md:text-5xl font-bold tracking-tighter mb-6 text-black",
								children: "Get in Touch."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xl text-[#86868b] mb-16 max-w-2xl mx-auto",
								children: "Have questions about the platform or our SAP consulting services? We're here to help."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-1 md:grid-cols-3 gap-8 mb-16",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col items-center gap-4 p-8 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-12 h-12 bg-[#fbfbfd] rounded-full border border-gray-100 flex items-center justify-center text-gray-700",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mail, { size: 20 })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium text-black",
											children: "contact@abhiyanta.com"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col items-center gap-4 p-8 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-12 h-12 bg-[#fbfbfd] rounded-full border border-gray-100 flex items-center justify-center text-gray-700",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Phone, { size: 20 })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium text-black",
											children: "+91 123 456 7890"
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "flex flex-col items-center gap-4 p-8 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "w-12 h-12 bg-[#fbfbfd] rounded-full border border-gray-100 flex items-center justify-center text-gray-700",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { size: 20 })
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium text-black",
											children: "Pune, India"
										})]
									})
								]
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "py-40 px-6 bg-white border-t border-gray-100 flex flex-col items-center justify-center text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						scale: .95
					},
					whileInView: {
						opacity: 1,
						scale: 1
					},
					viewport: { once: true },
					transition: {
						duration: .8,
						ease: smoothEase
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-5xl md:text-7xl font-bold tracking-tighter mb-10 text-black",
						children: "Ready to scale your talent?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/register-candidate",
						className: "inline-block bg-black text-white px-10 py-4 rounded-full text-lg font-medium hover:scale-105 hover:bg-gray-800 transition-all shadow-xl shadow-black/10",
						children: "Apply to Abhiyanta"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-40 pt-10 border-t border-gray-100 w-full max-w-7xl text-sm text-[#86868b] flex flex-col md:flex-row items-center justify-between gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" Abhiyanta India Solutions. System engineered by ATLAS."
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#",
							className: "hover:text-black transition-colors",
							children: "Privacy Policy"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#",
							className: "hover:text-black transition-colors",
							children: "Terms of Service"
						})]
					})]
				})]
			})
		]
	});
}
//#endregion
export { LandingPage as component };
