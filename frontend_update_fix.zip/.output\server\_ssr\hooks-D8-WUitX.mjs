import { n as api } from "./api-85Rra_o2.mjs";
import { i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hooks-D8-WUitX.js
function useOffer(candidateId) {
	return useQuery({
		queryKey: [
			"offer",
			"candidate",
			candidateId
		],
		queryFn: () => api(`/api/offers/candidate/${candidateId}`).then((r) => r.offer ?? null),
		enabled: !!candidateId,
		staleTime: 3e4
	});
}
function useSendOffer() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: ({ offerId }) => api(`/api/offers/${offerId}/send`, { method: "POST" }),
		onSuccess: (_data, variables) => {
			qc.invalidateQueries({ queryKey: ["offer", "candidate"] });
			qc.invalidateQueries({ queryKey: ["offers"] });
		}
	});
}
function useAcceptOffer() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: ({ offerId }) => api(`/api/offers/${offerId}/accept`, { method: "POST" }),
		onSuccess: (_data, variables) => {
			qc.invalidateQueries({ queryKey: ["offer", "candidate"] });
			qc.invalidateQueries({ queryKey: ["offers"] });
		}
	});
}
function useDeclineOffer() {
	const qc = useQueryClient();
	return useMutation({
		mutationFn: ({ offerId }) => api(`/api/offers/${offerId}/decline`, { method: "POST" }),
		onSuccess: (_data, variables) => {
			qc.invalidateQueries({ queryKey: ["offer", "candidate"] });
			qc.invalidateQueries({ queryKey: ["offers"] });
		}
	});
}
//#endregion
export { useSendOffer as i, useDeclineOffer as n, useOffer as r, useAcceptOffer as t };
