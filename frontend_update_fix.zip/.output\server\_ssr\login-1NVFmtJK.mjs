import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-arrow+[...].mjs";
import { n as useAuth } from "./auth-Ba-lKRMp.mjs";
import { t as Button } from "./button-B_S4Wnqd.mjs";
import { g as Link, v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { A as LoaderCircle, B as FileText, H as Eye, U as EyeOff, dt as ChartLine, g as ShieldCheck, r as Users } from "../_libs/lucide-react.mjs";
import { t as motion } from "../_libs/framer-motion+[...].mjs";
import { t as Label } from "./label-BgXw8JJ9.mjs";
import { t as Input } from "./input-yj8bgoN5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-1NVFmtJK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LoginPage() {
	const { login, isAuthenticated, loading } = useAuth();
	const navigate = useNavigate();
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [showPassword, setShowPassword] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!loading && isAuthenticated) navigate({ to: "/dashboard" });
	}, [
		isAuthenticated,
		loading,
		navigate
	]);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "min-h-screen bg-white flex items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "h-8 w-8 animate-spin text-[#86868b]" })
	});
	if (isAuthenticated) return null;
	async function onSubmit(e) {
		e.preventDefault();
		setBusy(true);
		try {
			await login(email, password);
			toast.success("Signed in");
			navigate({ to: "/dashboard" });
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Sign in failed");
		} finally {
			setBusy(false);
		}
	}
	const smoothEase = [
		.16,
		1,
		.3,
		1
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen grid lg:grid-cols-2 bg-white font-sans text-[#1d1d1f] selection:bg-[#0066cc] selection:text-white",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hidden lg:flex flex-col justify-between bg-[#fbfbfd] p-12 relative overflow-hidden border-r border-gray-100",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: {
						opacity: 0,
						y: -20
					},
					animate: {
						opacity: 1,
						y: 0
					},
					transition: {
						duration: .8,
						ease: smoothEase
					},
					className: "flex items-center gap-4 z-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: "/logo.png",
						alt: "Atlas Logo",
						className: "h-10 w-auto"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "font-bold tracking-tight text-xl text-[#1d1d1f]",
						children: "Atlas HR"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "text-sm font-medium text-[#86868b]",
						children: "Recruitment Console"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-16 z-10 max-w-lg mt-20",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(motion.h1, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: .8,
							delay: .1,
							ease: smoothEase
						},
						className: "text-[3.5rem] font-bold tracking-tighter leading-[1.05] text-[#1d1d1f]",
						children: "Move candidates through every stage with confidence."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
						initial: {
							opacity: 0,
							y: 20
						},
						animate: {
							opacity: 1,
							y: 0
						},
						transition: {
							duration: .8,
							delay: .2,
							ease: smoothEase
						},
						className: "grid grid-cols-2 gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white rounded-[2rem] p-6 border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-12 h-12 rounded-full bg-[#f5f5f7] text-[#1d1d1f] flex items-center justify-center mb-5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Users, { size: 20 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-[#1d1d1f] mb-1",
										children: "7 Dimensions"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium text-[#86868b]",
										children: "SAP Screening"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white rounded-[2rem] p-6 border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-12 h-12 rounded-full bg-[#f5f5f7] text-[#1d1d1f] flex items-center justify-center mb-5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChartLine, { size: 20 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-[#1d1d1f] mb-1",
										children: "L1 / L2 Panels"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium text-[#86868b]",
										children: "Technical Rounds"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white rounded-[2rem] p-6 border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-12 h-12 rounded-full bg-[#f5f5f7] text-[#1d1d1f] flex items-center justify-center mb-5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { size: 20 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-[#1d1d1f] mb-1",
										children: "CEO Review"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium text-[#86868b]",
										children: "Executive Offer"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-white rounded-[2rem] p-6 border border-gray-100 shadow-[0_8px_30px_rgb(0,0,0,0.02)]",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "w-12 h-12 rounded-full bg-[#f5f5f7] text-[#1d1d1f] flex items-center justify-center mb-5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileText, { size: 20 })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "font-bold text-[#1d1d1f] mb-1",
										children: "Full Audit"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "text-sm font-medium text-[#86868b]",
										children: "Activity Logs"
									})
								]
							})
						]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
					initial: { opacity: 0 },
					animate: { opacity: 1 },
					transition: {
						duration: 1,
						delay: .5
					},
					className: "text-xs font-bold text-[#86868b] mt-20 z-10",
					children: [
						"© ",
						(/* @__PURE__ */ new Date()).getFullYear(),
						" Abhiyanta India Solutions. All rights reserved."
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col items-center justify-center p-6 sm:p-12 relative bg-white",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(motion.div, {
				initial: {
					opacity: 0,
					scale: .95
				},
				animate: {
					opacity: 1,
					scale: 1
				},
				transition: {
					duration: .6,
					ease: smoothEase
				},
				className: "w-full max-w-md",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 lg:hidden mb-12",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/logo.png",
							alt: "Atlas Logo",
							className: "h-8 w-auto"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-bold text-xl tracking-tight text-[#1d1d1f]",
							children: "Atlas HR"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-[2.5rem] font-bold tracking-tight mb-3 text-[#1d1d1f] leading-none",
						children: "Sign in"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-base font-medium text-[#86868b] mb-10",
						children: "Use your Atlas HR staff credentials to access the portal."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit,
						className: "space-y-6",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "email",
									className: "text-sm font-bold text-[#1d1d1f]",
									children: "Email Address"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "email",
									type: "email",
									autoComplete: "username",
									required: true,
									value: email,
									onChange: (e) => setEmail(e.target.value),
									placeholder: "you@abhiyanta.com",
									className: "rounded-2xl bg-[#f5f5f7] border-transparent focus:bg-white focus:ring-4 focus:ring-[#0066cc]/10 focus:border-[#0066cc] transition-all h-[3.5rem] px-5 shadow-none text-base font-medium placeholder:text-[#86868b]"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "space-y-2 relative",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
									htmlFor: "password",
									className: "text-sm font-bold text-[#1d1d1f]",
									children: "Password"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "password",
										type: showPassword ? "text" : "password",
										autoComplete: "current-password",
										required: true,
										value: password,
										onChange: (e) => setPassword(e.target.value),
										placeholder: "••••••••",
										className: "rounded-2xl bg-[#f5f5f7] border-transparent focus:bg-white focus:ring-4 focus:ring-[#0066cc]/10 focus:border-[#0066cc] transition-all h-[3.5rem] px-5 pr-12 shadow-none text-base font-medium placeholder:text-[#86868b]"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										onClick: () => setShowPassword(!showPassword),
										className: "absolute right-4 top-1/2 -translate-y-1/2 text-[#86868b] hover:text-[#1d1d1f] transition-colors p-1",
										children: showPassword ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { size: 20 }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { size: 20 })
									})]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "w-full rounded-full bg-[#1d1d1f] text-white hover:bg-black h-[3.5rem] text-base font-bold shadow-sm transition-all active:scale-[0.98] mt-8",
								disabled: busy,
								children: busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "mr-2 h-5 w-5 animate-spin" }) : "Sign in"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-12 pt-8 border-t border-gray-100 text-center text-sm font-medium text-[#86868b]",
						children: [
							"Are you a candidate?",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/register-candidate",
								className: "text-[#1d1d1f] font-bold hover:underline transition-all",
								children: "Start your application"
							})
						]
					})
				]
			})
		})]
	});
}
//#endregion
export { LoginPage as component };
